"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  Plus,
  Edit,
  Trash2,
  Search,
  Save,
  User,
  Pill,
  CheckSquare,
  Phone,
  Target,
  FileText,
  Calendar,
} from "lucide-react"

interface CarePlan {
  id: number
  client: {
    name: string
    age: number
    email: string
    phone: string
    address: string
    emergencyContact: string
  }
  caregiver: {
    name: string
    email: string
    phone: string
    specialties: string[]
  }
  healthDetails: {
    conditions: string[]
    allergies: string[]
    mobility: string
    cognitiveStatus: string
    dietaryRestrictions: string[]
  }
  medications: Array<{
    id: number
    name: string
    dosage: string
    frequency: string
    time: string[]
    instructions: string
    active: boolean
  }>
  dailyTasks: Array<{
    id: number
    task: string
    frequency: string
    time: string
    priority: "low" | "medium" | "high"
    completed: boolean
    notes: string
  }>
  emergencyContacts: Array<{
    id: number
    name: string
    relationship: string
    phone: string
    isPrimary: boolean
  }>
  goals: Array<{
    id: number
    title: string
    description: string
    targetDate: string
    progress: number
    status: "active" | "completed" | "paused"
    category: string
  }>
  notes: Array<{
    id: number
    date: string
    author: string
    category: "general" | "medical" | "behavioral" | "family"
    content: string
  }>
  status: "active" | "inactive" | "review"
  lastUpdated: string
  createdDate: string
}

export default function CarePlansPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterBy, setFilterBy] = useState("all")
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<CarePlan | null>(null)
  const [activeTab, setActiveTab] = useState("overview")

  // Mock care plans data
  const [carePlans, setCarePlans] = useState<CarePlan[]>([
    {
      id: 1,
      client: {
        name: "Margaret Johnson",
        age: 78,
        email: "margaret.j@email.com",
        phone: "555-0124",
        address: "123 Oak Street, Springfield",
        emergencyContact: "John Johnson - 555-0156",
      },
      caregiver: {
        name: "Sarah Wilson",
        email: "sarah.wilson@warmheaven.com",
        phone: "555-0123",
        specialties: ["Personal Care", "Elderly Care"],
      },
      healthDetails: {
        conditions: ["Diabetes Type 2", "Hypertension", "Arthritis"],
        allergies: ["Penicillin", "Shellfish"],
        mobility: "Limited - Uses walker",
        cognitiveStatus: "Mild cognitive impairment",
        dietaryRestrictions: ["Low sodium", "Diabetic diet"],
      },
      medications: [
        {
          id: 1,
          name: "Metformin",
          dosage: "500mg",
          frequency: "Twice daily",
          time: ["08:00", "20:00"],
          instructions: "Take with meals",
          active: true,
        },
        {
          id: 2,
          name: "Lisinopril",
          dosage: "10mg",
          frequency: "Once daily",
          time: ["08:00"],
          instructions: "Take in morning",
          active: true,
        },
      ],
      dailyTasks: [
        {
          id: 1,
          task: "Blood glucose monitoring",
          frequency: "Twice daily",
          time: "08:00, 18:00",
          priority: "high",
          completed: true,
          notes: "Record readings in log",
        },
        {
          id: 2,
          task: "Physical therapy exercises",
          frequency: "Daily",
          time: "10:00",
          priority: "medium",
          completed: false,
          notes: "Focus on leg strengthening",
        },
      ],
      emergencyContacts: [
        {
          id: 1,
          name: "John Johnson",
          relationship: "Son",
          phone: "555-0156",
          isPrimary: true,
        },
        {
          id: 2,
          name: "Dr. Smith",
          relationship: "Primary Physician",
          phone: "555-0200",
          isPrimary: false,
        },
      ],
      goals: [
        {
          id: 1,
          title: "Improve Mobility",
          description: "Increase walking distance to 100 yards",
          targetDate: "2024-03-01",
          progress: 65,
          status: "active",
          category: "Physical",
        },
        {
          id: 2,
          title: "Blood Sugar Control",
          description: "Maintain HbA1c below 7%",
          targetDate: "2024-06-01",
          progress: 80,
          status: "active",
          category: "Medical",
        },
      ],
      notes: [
        {
          id: 1,
          date: "2024-01-15",
          author: "Sarah Wilson",
          category: "general",
          content: "Client is responding well to new exercise routine. Mood has improved significantly.",
        },
        {
          id: 2,
          date: "2024-01-10",
          author: "Dr. Smith",
          category: "medical",
          content: "Blood pressure readings have stabilized. Continue current medication regimen.",
        },
      ],
      status: "active",
      lastUpdated: "2024-01-15",
      createdDate: "2023-06-15",
    },
    {
      id: 2,
      client: {
        name: "Robert Miller",
        age: 82,
        email: "robert.m@email.com",
        phone: "555-0127",
        address: "456 Pine Avenue, Springfield",
        emergencyContact: "Susan Miller - 555-0158",
      },
      caregiver: {
        name: "Mike Davis",
        email: "mike.davis@warmheaven.com",
        phone: "555-0125",
        specialties: ["Physical Therapy", "Post-Surgery Care"],
      },
      healthDetails: {
        conditions: ["Post-hip replacement", "Osteoporosis"],
        allergies: ["None known"],
        mobility: "Recovering - Physical therapy",
        cognitiveStatus: "Normal",
        dietaryRestrictions: ["High calcium diet"],
      },
      medications: [
        {
          id: 3,
          name: "Calcium Carbonate",
          dosage: "1000mg",
          frequency: "Twice daily",
          time: ["09:00", "21:00"],
          instructions: "Take with food",
          active: true,
        },
      ],
      dailyTasks: [
        {
          id: 3,
          task: "Physical therapy session",
          frequency: "3 times weekly",
          time: "14:00",
          priority: "high",
          completed: true,
          notes: "Focus on hip mobility and strength",
        },
      ],
      emergencyContacts: [
        {
          id: 3,
          name: "Susan Miller",
          relationship: "Wife",
          phone: "555-0158",
          isPrimary: true,
        },
      ],
      goals: [
        {
          id: 3,
          title: "Full Recovery",
          description: "Return to independent walking",
          targetDate: "2024-04-01",
          progress: 45,
          status: "active",
          category: "Physical",
        },
      ],
      notes: [
        {
          id: 3,
          date: "2024-01-12",
          author: "Mike Davis",
          category: "medical",
          content: "Great progress in PT sessions. Client is motivated and following instructions well.",
        },
      ],
      status: "active",
      lastUpdated: "2024-01-12",
      createdDate: "2023-11-05",
    },
  ])

  const [newCarePlan, setNewCarePlan] = useState<Partial<CarePlan>>({
    client: {
      name: "",
      age: 0,
      email: "",
      phone: "",
      address: "",
      emergencyContact: "",
    },
    caregiver: {
      name: "",
      email: "",
      phone: "",
      specialties: [],
    },
    healthDetails: {
      conditions: [],
      allergies: [],
      mobility: "",
      cognitiveStatus: "",
      dietaryRestrictions: [],
    },
    medications: [],
    dailyTasks: [],
    emergencyContacts: [],
    goals: [],
    notes: [],
    status: "active",
  })

  const filteredPlans = carePlans.filter((plan) => {
    const matchesFilter = filterBy === "all" || plan.status === filterBy
    const matchesSearch =
      plan.client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      plan.caregiver.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      plan.healthDetails.conditions.some((condition) => condition.toLowerCase().includes(searchTerm.toLowerCase()))
    return matchesFilter && matchesSearch
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "inactive":
        return "bg-gray-100 text-gray-800"
      case "review":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const handleSaveCarePlan = () => {
    if (!newCarePlan.client?.name || !newCarePlan.caregiver?.name) {
      alert("Please fill in all required fields")
      return
    }

    if (selectedPlan) {
      // Edit existing plan
      setCarePlans(
        carePlans.map((plan) =>
          plan.id === selectedPlan.id
            ? {
                ...plan,
                ...newCarePlan,
                id: selectedPlan.id,
                lastUpdated: new Date().toISOString().split("T")[0],
              }
            : plan,
        ),
      )
      setShowEditDialog(false)
    } else {
      // Add new plan
      const newPlan: CarePlan = {
        ...newCarePlan,
        id: Math.max(...carePlans.map((p) => p.id)) + 1,
        lastUpdated: new Date().toISOString().split("T")[0],
        createdDate: new Date().toISOString().split("T")[0],
      } as CarePlan

      setCarePlans([...carePlans, newPlan])
      setShowAddDialog(false)
    }

    // Reset form
    setNewCarePlan({
      client: { name: "", age: 0, email: "", phone: "", address: "", emergencyContact: "" },
      caregiver: { name: "", email: "", phone: "", specialties: [] },
      healthDetails: { conditions: [], allergies: [], mobility: "", cognitiveStatus: "", dietaryRestrictions: [] },
      medications: [],
      dailyTasks: [],
      emergencyContacts: [],
      goals: [],
      notes: [],
      status: "active",
    })
    setSelectedPlan(null)
  }

  const handleEditPlan = (plan: CarePlan) => {
    setSelectedPlan(plan)
    setNewCarePlan(plan)
    setShowEditDialog(true)
  }

  const handleDeletePlan = (planId: number) => {
    setCarePlans(carePlans.filter((plan) => plan.id !== planId))
  }

  const stats = {
    total: carePlans.length,
    active: carePlans.filter((p) => p.status === "active").length,
    review: carePlans.filter((p) => p.status === "review").length,
    totalGoals: carePlans.reduce((sum, plan) => sum + plan.goals.length, 0),
    completedGoals: carePlans.reduce((sum, plan) => sum + plan.goals.filter((g) => g.status === "completed").length, 0),
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Care Plans Management</h1>
              <p className="text-sm text-gray-500">Create and manage comprehensive care plans for clients</p>
            </div>
            <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
              <DialogTrigger asChild>
                <Button className="bg-blue-500 hover:bg-blue-600">
                  <Plus className="h-4 w-4 mr-2" />
                  Create Care Plan
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Create New Care Plan</DialogTitle>
                  <DialogDescription>
                    Create a comprehensive care plan by filling out all the necessary details.
                  </DialogDescription>
                </DialogHeader>
                <CarePlanForm
                  carePlan={newCarePlan}
                  setCarePlan={setNewCarePlan}
                  onSave={handleSaveCarePlan}
                  onCancel={() => setShowAddDialog(false)}
                />
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
              <div className="text-sm text-gray-600">Total Plans</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{stats.active}</div>
              <div className="text-sm text-gray-600">Active</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-yellow-600">{stats.review}</div>
              <div className="text-sm text-gray-600">Under Review</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.totalGoals}</div>
              <div className="text-sm text-gray-600">Total Goals</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">
                {stats.totalGoals > 0 ? Math.round((stats.completedGoals / stats.totalGoals) * 100) : 0}%
              </div>
              <div className="text-sm text-gray-600">Goals Completed</div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search care plans by client, caregiver, or condition..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Select value={filterBy} onValueChange={setFilterBy}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Plans</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="review">Under Review</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Care Plans Grid */}
        <div className="grid gap-6">
          {filteredPlans.map((plan) => (
            <Card key={plan.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4 flex-1">
                    <Avatar className="h-16 w-16">
                      <AvatarFallback className="bg-blue-100 text-blue-600 text-lg">
                        {plan.client.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <h3 className="font-semibold text-xl">{plan.client.name}</h3>
                        <Badge className={getStatusColor(plan.status)}>{plan.status}</Badge>
                        <span className="text-sm text-gray-500">Age: {plan.client.age}</span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {/* Client Info */}
                        <div className="space-y-3">
                          <div className="flex items-center gap-2 text-sm">
                            <User className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">Caregiver:</span>
                            <span>{plan.caregiver.name}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Phone className="h-4 w-4 text-gray-500" />
                            <span>{plan.client.phone}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Calendar className="h-4 w-4 text-gray-500" />
                            <span>Updated: {plan.lastUpdated}</span>
                          </div>
                        </div>

                        {/* Health Summary */}
                        <div className="space-y-3">
                          <div>
                            <span className="font-medium text-sm">Conditions:</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {plan.healthDetails.conditions.slice(0, 3).map((condition, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {condition}
                                </Badge>
                              ))}
                              {plan.healthDetails.conditions.length > 3 && (
                                <Badge variant="outline" className="text-xs">
                                  +{plan.healthDetails.conditions.length - 3} more
                                </Badge>
                              )}
                            </div>
                          </div>
                          <div className="text-sm">
                            <span className="font-medium">Mobility:</span> {plan.healthDetails.mobility}
                          </div>
                        </div>

                        {/* Quick Stats */}
                        <div className="space-y-3">
                          <div className="flex items-center gap-4 text-sm">
                            <div className="flex items-center gap-1">
                              <Pill className="h-4 w-4 text-blue-500" />
                              <span>{plan.medications.filter((m) => m.active).length} Medications</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <CheckSquare className="h-4 w-4 text-green-500" />
                              <span>{plan.dailyTasks.length} Tasks</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-4 text-sm">
                            <div className="flex items-center gap-1">
                              <Target className="h-4 w-4 text-purple-500" />
                              <span>{plan.goals.filter((g) => g.status === "active").length} Active Goals</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <FileText className="h-4 w-4 text-orange-500" />
                              <span>{plan.notes.length} Notes</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Goals Progress */}
                      {plan.goals.length > 0 && (
                        <div className="mt-4 space-y-2">
                          <span className="font-medium text-sm">Recent Goals Progress:</span>
                          {plan.goals.slice(0, 2).map((goal) => (
                            <div key={goal.id} className="space-y-1">
                              <div className="flex justify-between text-sm">
                                <span>{goal.title}</span>
                                <span>{goal.progress}%</span>
                              </div>
                              <Progress value={goal.progress} className="h-2" />
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col gap-2 ml-4">
                    <Button variant="outline" size="sm" onClick={() => handleEditPlan(plan)}>
                      <Edit className="h-4 w-4 mr-2" />
                      Edit Plan
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700">
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Care Plan</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete the care plan for {plan.client.name}? This action cannot be
                            undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleDeletePlan(plan.id)}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            Delete Plan
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Edit Care Plan Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Care Plan</DialogTitle>
            <DialogDescription>Update the care plan details and settings.</DialogDescription>
          </DialogHeader>
          <CarePlanForm
            carePlan={newCarePlan}
            setCarePlan={setNewCarePlan}
            onSave={handleSaveCarePlan}
            onCancel={() => {
              setShowEditDialog(false)
              setSelectedPlan(null)
            }}
          />
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Care Plan Form Component
function CarePlanForm({
  carePlan,
  setCarePlan,
  onSave,
  onCancel,
}: {
  carePlan: Partial<CarePlan>
  setCarePlan: (plan: Partial<CarePlan>) => void
  onSave: () => void
  onCancel: () => void
}) {
  const [activeSection, setActiveSection] = useState("client")

  const addMedication = () => {
    const newMedication = {
      id: Date.now(),
      name: "",
      dosage: "",
      frequency: "",
      time: [],
      instructions: "",
      active: true,
    }
    setCarePlan({
      ...carePlan,
      medications: [...(carePlan.medications || []), newMedication],
    })
  }

  const updateMedication = (id: number, field: string, value: any) => {
    setCarePlan({
      ...carePlan,
      medications: carePlan.medications?.map((med) => (med.id === id ? { ...med, [field]: value } : med)),
    })
  }

  const removeMedication = (id: number) => {
    setCarePlan({
      ...carePlan,
      medications: carePlan.medications?.filter((med) => med.id !== id),
    })
  }

  const addTask = () => {
    const newTask = {
      id: Date.now(),
      task: "",
      frequency: "",
      time: "",
      priority: "medium" as const,
      completed: false,
      notes: "",
    }
    setCarePlan({
      ...carePlan,
      dailyTasks: [...(carePlan.dailyTasks || []), newTask],
    })
  }

  const updateTask = (id: number, field: string, value: any) => {
    setCarePlan({
      ...carePlan,
      dailyTasks: carePlan.dailyTasks?.map((task) => (task.id === id ? { ...task, [field]: value } : task)),
    })
  }

  const removeTask = (id: number) => {
    setCarePlan({
      ...carePlan,
      dailyTasks: carePlan.dailyTasks?.filter((task) => task.id !== id),
    })
  }

  const addEmergencyContact = () => {
    const newContact = {
      id: Date.now(),
      name: "",
      relationship: "",
      phone: "",
      isPrimary: false,
    }
    setCarePlan({
      ...carePlan,
      emergencyContacts: [...(carePlan.emergencyContacts || []), newContact],
    })
  }

  const updateEmergencyContact = (id: number, field: string, value: any) => {
    setCarePlan({
      ...carePlan,
      emergencyContacts: carePlan.emergencyContacts?.map((contact) =>
        contact.id === id ? { ...contact, [field]: value } : contact,
      ),
    })
  }

  const removeEmergencyContact = (id: number) => {
    setCarePlan({
      ...carePlan,
      emergencyContacts: carePlan.emergencyContacts?.filter((contact) => contact.id !== id),
    })
  }

  const addGoal = () => {
    const newGoal = {
      id: Date.now(),
      title: "",
      description: "",
      targetDate: "",
      progress: 0,
      status: "active" as const,
      category: "",
    }
    setCarePlan({
      ...carePlan,
      goals: [...(carePlan.goals || []), newGoal],
    })
  }

  const updateGoal = (id: number, field: string, value: any) => {
    setCarePlan({
      ...carePlan,
      goals: carePlan.goals?.map((goal) => (goal.id === id ? { ...goal, [field]: value } : goal)),
    })
  }

  const removeGoal = (id: number) => {
    setCarePlan({
      ...carePlan,
      goals: carePlan.goals?.filter((goal) => goal.id !== id),
    })
  }

  return (
    <div className="space-y-6 max-h-[70vh] overflow-y-auto pr-2">
      <Tabs value={activeSection} onValueChange={setActiveSection}>
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="client">Client</TabsTrigger>
          <TabsTrigger value="health">Health</TabsTrigger>
          <TabsTrigger value="medications">Medications</TabsTrigger>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="contacts">Contacts</TabsTrigger>
          <TabsTrigger value="goals">Goals</TabsTrigger>
        </TabsList>

        <TabsContent value="client" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Client Name</Label>
              <Input
                value={carePlan.client?.name || ""}
                onChange={(e) =>
                  setCarePlan({
                    ...carePlan,
                    client: { ...carePlan.client!, name: e.target.value },
                  })
                }
                required
              />
            </div>
            <div className="space-y-2">
              <Label>Age</Label>
              <Input
                type="number"
                value={carePlan.client?.age || ""}
                onChange={(e) =>
                  setCarePlan({
                    ...carePlan,
                    client: { ...carePlan.client!, age: Number.parseInt(e.target.value) },
                  })
                }
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Email</Label>
              <Input
                type="email"
                value={carePlan.client?.email || ""}
                onChange={(e) =>
                  setCarePlan({
                    ...carePlan,
                    client: { ...carePlan.client!, email: e.target.value },
                  })
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Phone</Label>
              <Input
                value={carePlan.client?.phone || ""}
                onChange={(e) =>
                  setCarePlan({
                    ...carePlan,
                    client: { ...carePlan.client!, phone: e.target.value },
                  })
                }
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Address</Label>
            <Textarea
              value={carePlan.client?.address || ""}
              onChange={(e) =>
                setCarePlan({
                  ...carePlan,
                  client: { ...carePlan.client!, address: e.target.value },
                })
              }
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label>Primary Caregiver</Label>
            <Input
              value={carePlan.caregiver?.name || ""}
              onChange={(e) =>
                setCarePlan({
                  ...carePlan,
                  caregiver: { ...carePlan.caregiver!, name: e.target.value },
                })
              }
              placeholder="Assigned caregiver name"
            />
          </div>
        </TabsContent>

        <TabsContent value="health" className="space-y-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Medical Conditions</Label>
              <Textarea
                value={carePlan.healthDetails?.conditions?.join(", ") || ""}
                onChange={(e) =>
                  setCarePlan({
                    ...carePlan,
                    healthDetails: {
                      ...carePlan.healthDetails!,
                      conditions: e.target.value.split(", ").filter((c) => c.trim()),
                    },
                  })
                }
                placeholder="Diabetes, Hypertension, etc. (comma-separated)"
                rows={2}
              />
            </div>

            <div className="space-y-2">
              <Label>Allergies</Label>
              <Textarea
                value={carePlan.healthDetails?.allergies?.join(", ") || ""}
                onChange={(e) =>
                  setCarePlan({
                    ...carePlan,
                    healthDetails: {
                      ...carePlan.healthDetails!,
                      allergies: e.target.value.split(", ").filter((a) => a.trim()),
                    },
                  })
                }
                placeholder="Penicillin, Shellfish, etc. (comma-separated)"
                rows={2}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Mobility Status</Label>
                <Select
                  value={carePlan.healthDetails?.mobility || ""}
                  onValueChange={(value) =>
                    setCarePlan({
                      ...carePlan,
                      healthDetails: { ...carePlan.healthDetails!, mobility: value },
                    })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select mobility status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Independent">Independent</SelectItem>
                    <SelectItem value="Limited - Uses walker">Limited - Uses walker</SelectItem>
                    <SelectItem value="Limited - Uses wheelchair">Limited - Uses wheelchair</SelectItem>
                    <SelectItem value="Bedridden">Bedridden</SelectItem>
                    <SelectItem value="Requires assistance">Requires assistance</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Cognitive Status</Label>
                <Select
                  value={carePlan.healthDetails?.cognitiveStatus || ""}
                  onValueChange={(value) =>
                    setCarePlan({
                      ...carePlan,
                      healthDetails: { ...carePlan.healthDetails!, cognitiveStatus: value },
                    })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select cognitive status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Normal">Normal</SelectItem>
                    <SelectItem value="Mild cognitive impairment">Mild cognitive impairment</SelectItem>
                    <SelectItem value="Moderate cognitive impairment">Moderate cognitive impairment</SelectItem>
                    <SelectItem value="Severe cognitive impairment">Severe cognitive impairment</SelectItem>
                    <SelectItem value="Dementia">Dementia</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Dietary Restrictions</Label>
              <Textarea
                value={carePlan.healthDetails?.dietaryRestrictions?.join(", ") || ""}
                onChange={(e) =>
                  setCarePlan({
                    ...carePlan,
                    healthDetails: {
                      ...carePlan.healthDetails!,
                      dietaryRestrictions: e.target.value.split(", ").filter((d) => d.trim()),
                    },
                  })
                }
                placeholder="Low sodium, Diabetic diet, etc. (comma-separated)"
                rows={2}
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="medications" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Medications</h3>
            <Button onClick={addMedication} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Medication
            </Button>
          </div>

          <div className="space-y-4">
            {carePlan.medications?.map((medication) => (
              <Card key={medication.id}>
                <CardContent className="p-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label>Medication Name</Label>
                      <Input
                        value={medication.name}
                        onChange={(e) => updateMedication(medication.id, "name", e.target.value)}
                        placeholder="e.g., Metformin"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Dosage</Label>
                      <Input
                        value={medication.dosage}
                        onChange={(e) => updateMedication(medication.id, "dosage", e.target.value)}
                        placeholder="e.g., 500mg"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Frequency</Label>
                      <Input
                        value={medication.frequency}
                        onChange={(e) => updateMedication(medication.id, "frequency", e.target.value)}
                        placeholder="e.g., Twice daily"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                    <div className="space-y-2">
                      <Label>Instructions</Label>
                      <Textarea
                        value={medication.instructions}
                        onChange={(e) => updateMedication(medication.id, "instructions", e.target.value)}
                        placeholder="Special instructions..."
                        rows={2}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Status</Label>
                      <div className="flex items-center gap-4">
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={medication.active}
                            onChange={(e) => updateMedication(medication.id, "active", e.target.checked)}
                          />
                          Active
                        </label>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeMedication(medication.id)}
                          className="text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="tasks" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Daily Tasks</h3>
            <Button onClick={addTask} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Task
            </Button>
          </div>

          <div className="space-y-4">
            {carePlan.dailyTasks?.map((task) => (
              <Card key={task.id}>
                <CardContent className="p-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label>Task</Label>
                      <Input
                        value={task.task}
                        onChange={(e) => updateTask(task.id, "task", e.target.value)}
                        placeholder="e.g., Blood glucose monitoring"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Frequency</Label>
                      <Input
                        value={task.frequency}
                        onChange={(e) => updateTask(task.id, "frequency", e.target.value)}
                        placeholder="e.g., Twice daily"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Time</Label>
                      <Input
                        value={task.time}
                        onChange={(e) => updateTask(task.id, "time", e.target.value)}
                        placeholder="e.g., 08:00, 18:00"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                    <div className="space-y-2">
                      <Label>Priority</Label>
                      <Select value={task.priority} onChange={(e) => updateTask(task.id, "priority", e.target.value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Actions</Label>
                      <div className="flex items-center gap-4">
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={task.completed}
                            onChange={(e) => updateTask(task.id, "completed", e.target.checked)}
                          />
                          Completed
                        </label>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeTask(task.id)}
                          className="text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 space-y-2">
                    <Label>Notes</Label>
                    <Textarea
                      value={task.notes}
                      onChange={(e) => updateTask(task.id, "notes", e.target.value)}
                      placeholder="Additional notes..."
                      rows={2}
                    />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="contacts" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Emergency Contacts</h3>
            <Button onClick={addEmergencyContact} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Contact
            </Button>
          </div>

          <div className="space-y-4">
            {carePlan.emergencyContacts?.map((contact) => (
              <Card key={contact.id}>
                <CardContent className="p-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label>Name</Label>
                      <Input
                        value={contact.name}
                        onChange={(e) => updateEmergencyContact(contact.id, "name", e.target.value)}
                        placeholder="Contact name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Relationship</Label>
                      <Input
                        value={contact.relationship}
                        onChange={(e) => updateEmergencyContact(contact.id, "relationship", e.target.value)}
                        placeholder="e.g., Son, Daughter, Doctor"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Phone</Label>
                      <Input
                        value={contact.phone}
                        onChange={(e) => updateEmergencyContact(contact.id, "phone", e.target.value)}
                        placeholder="Phone number"
                      />
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-4">
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={contact.isPrimary}
                        onChange={(e) => updateEmergencyContact(contact.id, "isPrimary", e.target.checked)}
                      />
                      Primary Contact
                    </label>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeEmergencyContact(contact.id)}
                      className="text-red-600"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="goals" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Care Goals</h3>
            <Button onClick={addGoal} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Goal
            </Button>
          </div>

          <div className="space-y-4">
            {carePlan.goals?.map((goal) => (
              <Card key={goal.id}>
                <CardContent className="p-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Goal Title</Label>
                      <Input
                        value={goal.title}
                        onChange={(e) => updateGoal(goal.id, "title", e.target.value)}
                        placeholder="e.g., Improve Mobility"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Category</Label>
                      <Input
                        value={goal.category}
                        onChange={(e) => updateGoal(goal.id, "category", e.target.value)}
                        placeholder="e.g., Physical, Medical, Social"
                      />
                    </div>
                  </div>
                  <div className="space-y-2 mt-4">
                    <Label>Description</Label>
                    <Textarea
                      value={goal.description}
                      onChange={(e) => updateGoal(goal.id, "description", e.target.value)}
                      placeholder="Detailed description of the goal..."
                      rows={2}
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                    <div className="space-y-2">
                      <Label>Target Date</Label>
                      <Input
                        type="date"
                        value={goal.targetDate}
                        onChange={(e) => updateGoal(goal.id, "targetDate", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Progress (%)</Label>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        value={goal.progress}
                        onChange={(e) => updateGoal(goal.id, "progress", Number.parseInt(e.target.value))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Status</Label>
                      <Select value={goal.status} onChange={(e) => updateGoal(goal.id, "status", e.target.value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                          <SelectItem value="paused">Paused</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="flex justify-between items-center mt-4">
                    <div className="flex-1">
                      <Progress value={goal.progress} className="h-2" />
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeGoal(goal.id)}
                      className="text-red-600 ml-4"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Sticky Action Buttons */}
      <div className="sticky bottom-0 bg-white pt-4 border-t flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button onClick={onSave} className="bg-blue-500 hover:bg-blue-600">
          <Save className="h-4 w-4 mr-2" />
          Save Care Plan
        </Button>
      </div>
    </div>
  )
}
