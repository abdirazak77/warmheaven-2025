"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"
import { MessageSquare, Send, Search, Paperclip, Phone, Video, MoreVertical, Users, Heart, Shield } from "lucide-react"

export default function MessagingPage() {
  const [selectedConversation, setSelectedConversation] = useState(1)
  const [newMessage, setNewMessage] = useState("")
  const [searchTerm, setSearchTerm] = useState("")
  const [filterRole, setFilterRole] = useState("all")

  // Mock conversations data
  const conversations = [
    {
      id: 1,
      name: "Margaret Johnson",
      role: "client",
      lastMessage: "Thank you for the wonderful care yesterday. Mom really enjoyed your visit!",
      timestamp: "2 hours ago",
      unread: 2,
      avatar: "MJ",
      online: true,
    },
    {
      id: 2,
      name: "Sarah Wilson",
      role: "caregiver",
      lastMessage: "I'll be arriving 15 minutes early today to prepare for the session.",
      timestamp: "4 hours ago",
      unread: 0,
      avatar: "SW",
      online: true,
    },
    {
      id: 3,
      name: "Administration",
      role: "admin",
      lastMessage: "Please remember to submit your weekly timesheet by Friday.",
      timestamp: "1 day ago",
      unread: 1,
      avatar: "AD",
      online: false,
    },
    {
      id: 4,
      name: "Robert Miller",
      role: "client",
      lastMessage: "Could we reschedule tomorrow's appointment to 2 PM instead?",
      timestamp: "2 days ago",
      unread: 0,
      avatar: "RM",
      online: false,
    },
    {
      id: 5,
      name: "Mike Davis",
      role: "caregiver",
      lastMessage: "The physical therapy session went very well today.",
      timestamp: "3 days ago",
      unread: 0,
      avatar: "MD",
      online: true,
    },
  ]

  // Mock messages for selected conversation
  const messages = [
    {
      id: 1,
      sender: "Margaret Johnson",
      content: "Hello! I wanted to thank you for the excellent care you provided yesterday.",
      timestamp: "10:30 AM",
      isOwn: false,
    },
    {
      id: 2,
      sender: "You",
      content: "Thank you so much for the kind words! It was my pleasure to help. How is your mother feeling today?",
      timestamp: "10:35 AM",
      isOwn: true,
    },
    {
      id: 3,
      sender: "Margaret Johnson",
      content: "She's doing much better. She keeps talking about how nice and professional you were.",
      timestamp: "10:40 AM",
      isOwn: false,
    },
    {
      id: 4,
      sender: "You",
      content: "That's wonderful to hear! I'm looking forward to our next session tomorrow at 9 AM.",
      timestamp: "10:45 AM",
      isOwn: true,
    },
    {
      id: 5,
      sender: "Margaret Johnson",
      content: "Thank you for the wonderful care yesterday. Mom really enjoyed your visit!",
      timestamp: "2 hours ago",
      isOwn: false,
    },
  ]

  const selectedConv = conversations.find((c) => c.id === selectedConversation)

  const filteredConversations = conversations.filter((conv) => {
    const matchesSearch = conv.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFilter = filterRole === "all" || conv.role === filterRole
    return matchesSearch && matchesFilter
  })

  const getRoleIcon = (role: string) => {
    switch (role) {
      case "admin":
        return <Shield className="h-4 w-4 text-blue-600" />
      case "caregiver":
        return <Heart className="h-4 w-4 text-orange-600" />
      case "client":
        return <Users className="h-4 w-4 text-green-600" />
      default:
        return <MessageSquare className="h-4 w-4 text-gray-600" />
    }
  }

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "admin":
        return "bg-blue-100 text-blue-800"
      case "caregiver":
        return "bg-orange-100 text-orange-800"
      case "client":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      // In a real app, this would send the message to the backend
      console.log("Sending message:", newMessage)
      setNewMessage("")
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Messaging Center</h1>
              <p className="text-sm text-gray-500">Communicate with your care network</p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-green-50 text-green-700">
                {conversations.filter((c) => c.online).length} Online
              </Badge>
              <Badge variant="outline" className="bg-blue-50 text-blue-700">
                {conversations.reduce((sum, c) => sum + c.unread, 0)} Unread
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
          {/* Conversations List */}
          <Card className="lg:col-span-1">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Conversations
              </CardTitle>
              <div className="space-y-3">
                {/* Search */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search conversations..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                {/* Filter */}
                <Select value={filterRole} onValueChange={setFilterRole}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    <SelectItem value="admin">Administrators</SelectItem>
                    <SelectItem value="caregiver">Caregivers</SelectItem>
                    <SelectItem value="client">Clients</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[500px]">
                <div className="space-y-1 p-4">
                  {filteredConversations.map((conversation) => (
                    <div
                      key={conversation.id}
                      onClick={() => setSelectedConversation(conversation.id)}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        selectedConversation === conversation.id
                          ? "bg-blue-50 border-blue-200 border"
                          : "hover:bg-gray-50"
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className="relative">
                          <Avatar className="h-10 w-10">
                            <AvatarFallback className="bg-gray-200 text-gray-700">{conversation.avatar}</AvatarFallback>
                          </Avatar>
                          {conversation.online && (
                            <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <div className="flex items-center gap-2">
                              <h3 className="font-medium text-sm truncate">{conversation.name}</h3>
                              {getRoleIcon(conversation.role)}
                            </div>
                            <div className="flex items-center gap-1">
                              {conversation.unread > 0 && (
                                <Badge className="bg-blue-500 text-white text-xs h-5 w-5 p-0 flex items-center justify-center">
                                  {conversation.unread}
                                </Badge>
                              )}
                            </div>
                          </div>
                          <p className="text-xs text-gray-600 truncate mb-1">{conversation.lastMessage}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-gray-500">{conversation.timestamp}</span>
                            <Badge variant="outline" className={`text-xs ${getRoleBadgeColor(conversation.role)}`}>
                              {conversation.role}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Chat Interface */}
          <Card className="lg:col-span-2 flex flex-col">
            {selectedConv ? (
              <>
                {/* Chat Header */}
                <CardHeader className="border-b">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className="bg-gray-200 text-gray-700">{selectedConv.avatar}</AvatarFallback>
                        </Avatar>
                        {selectedConv.online && (
                          <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                        )}
                      </div>
                      <div>
                        <h3 className="font-semibold">{selectedConv.name}</h3>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className={getRoleBadgeColor(selectedConv.role)}>
                            {selectedConv.role}
                          </Badge>
                          <span className="text-xs text-gray-500">{selectedConv.online ? "Online" : "Offline"}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm">
                        <Phone className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Video className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>

                {/* Messages */}
                <CardContent className="flex-1 p-0">
                  <ScrollArea className="h-[400px] p-4">
                    <div className="space-y-4">
                      {messages.map((message) => (
                        <div key={message.id} className={`flex ${message.isOwn ? "justify-end" : "justify-start"}`}>
                          <div
                            className={`max-w-[70%] p-3 rounded-lg ${
                              message.isOwn ? "bg-blue-500 text-white" : "bg-gray-100 text-gray-900"
                            }`}
                          >
                            <p className="text-sm">{message.content}</p>
                            <p className={`text-xs mt-1 ${message.isOwn ? "text-blue-100" : "text-gray-500"}`}>
                              {message.timestamp}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>

                {/* Message Input */}
                <div className="border-t p-4">
                  <div className="flex items-end gap-2">
                    <Button variant="outline" size="sm">
                      <Paperclip className="h-4 w-4" />
                    </Button>
                    <div className="flex-1">
                      <Textarea
                        placeholder="Type your message..."
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        rows={2}
                        className="resize-none"
                        onKeyPress={(e) => {
                          if (e.key === "Enter" && !e.shiftKey) {
                            e.preventDefault()
                            handleSendMessage()
                          }
                        }}
                      />
                    </div>
                    <Button
                      onClick={handleSendMessage}
                      disabled={!newMessage.trim()}
                      className="bg-blue-500 hover:bg-blue-600"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </>
            ) : (
              <CardContent className="flex-1 flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <MessageSquare className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>Select a conversation to start messaging</p>
                </div>
              </CardContent>
            )}
          </Card>
        </div>
      </div>
    </div>
  )
}
