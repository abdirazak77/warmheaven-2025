"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { AdminSidebar } from "@/components/admin-sidebar"
import { AdminTopBar } from "@/components/admin-top-bar"
import { Bell, Send, AlertTriangle, CheckCircle, Clock, Plus, Eye, Trash2 } from "lucide-react"

export default function NotificationsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [userInfo, setUserInfo] = useState({ name: "Administrator", email: "admin@warmheaven.com" })
  const [showSendDialog, setShowSendDialog] = useState(false)

  // Add this after the existing state declarations
  const [selectedTemplate, setSelectedTemplate] = useState(null)
  const [showTemplateDialog, setShowTemplateDialog] = useState(false)

  // Add notification templates data
  const notificationTemplates = [
    {
      id: 1,
      name: "Appointment Reminder",
      title: "Upcoming Appointment Reminder",
      message:
        "This is a friendly reminder that you have an appointment scheduled for [DATE] at [TIME] with [CAREGIVER]. Please ensure you are available and have any necessary items ready. If you need to reschedule, please contact us at least 24 hours in advance.",
      type: "reminder",
      priority: "medium",
      recipients: "clients",
      category: "appointments",
      variables: ["DATE", "TIME", "CAREGIVER"],
      description: "Template for appointment reminders sent to clients",
    },
    {
      id: 2,
      name: "System Maintenance",
      title: "Scheduled System Maintenance",
      message:
        "We will be performing scheduled maintenance on our systems on [DATE] from [START_TIME] to [END_TIME]. During this time, some services may be temporarily unavailable. We apologize for any inconvenience and appreciate your patience.",
      type: "system",
      priority: "medium",
      recipients: "all",
      category: "system",
      variables: ["DATE", "START_TIME", "END_TIME"],
      description: "Template for system maintenance notifications",
    },
    {
      id: 3,
      name: "Emergency Alert",
      title: "Emergency Notification",
      message:
        "URGENT: [EMERGENCY_TYPE] - [DETAILS]. Please follow emergency procedures and contact emergency services if necessary. For immediate assistance, call our emergency hotline at 888-404-9276.",
      type: "emergency",
      priority: "urgent",
      recipients: "all",
      category: "emergency",
      variables: ["EMERGENCY_TYPE", "DETAILS"],
      description: "Template for emergency notifications",
    },
    {
      id: 4,
      name: "Training Announcement",
      title: "Training Session Announcement",
      message:
        "You are required to attend a training session on [TOPIC] scheduled for [DATE] at [TIME] at [LOCATION]. This training is [MANDATORY/OPTIONAL] and will cover [DESCRIPTION]. Please confirm your attendance by [DEADLINE].",
      type: "training",
      priority: "high",
      recipients: "caregivers",
      category: "training",
      variables: ["TOPIC", "DATE", "TIME", "LOCATION", "MANDATORY/OPTIONAL", "DESCRIPTION", "DEADLINE"],
      description: "Template for training session announcements",
    },
    {
      id: 5,
      name: "Welcome New Client",
      title: "Welcome to Warm Heaven Enterprise",
      message:
        "Welcome to our care family! We are excited to begin providing you with compassionate, professional care. Your assigned caregiver is [CAREGIVER] and your first appointment is scheduled for [DATE] at [TIME]. If you have any questions, please don't hesitate to contact us.",
      type: "welcome",
      priority: "medium",
      recipients: "clients",
      category: "onboarding",
      variables: ["CAREGIVER", "DATE", "TIME"],
      description: "Template for welcoming new clients",
    },
    {
      id: 6,
      name: "Payment Reminder",
      title: "Payment Due Reminder",
      message:
        "This is a friendly reminder that your payment of [AMOUNT] for services rendered in [PERIOD] is due on [DUE_DATE]. You can make your payment online through our portal or contact our billing department at [PHONE].",
      type: "billing",
      priority: "medium",
      recipients: "clients",
      category: "billing",
      variables: ["AMOUNT", "PERIOD", "DUE_DATE", "PHONE"],
      description: "Template for payment reminders",
    },
  ]

  const handleUseTemplate = (template: any) => {
    setSelectedTemplate(template)
    setShowSendDialog(true)
  }

  const handleCreateTemplate = () => {
    setShowTemplateDialog(true)
  }

  // Mock notifications data
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      title: "System Maintenance Scheduled",
      message: "Scheduled maintenance will occur on Sunday, January 21st from 2:00 AM to 4:00 AM CST.",
      type: "system",
      priority: "medium",
      recipients: "all",
      sentDate: "2024-01-15",
      sentBy: "System Administrator",
      status: "sent",
      readCount: 45,
      totalRecipients: 89,
    },
    {
      id: 2,
      title: "New Caregiver Training Session",
      message: "Mandatory training session for all new caregivers scheduled for January 25th at 10:00 AM.",
      type: "training",
      priority: "high",
      recipients: "caregivers",
      sentDate: "2024-01-14",
      sentBy: "HR Department",
      status: "sent",
      readCount: 12,
      totalRecipients: 15,
    },
    {
      id: 3,
      title: "Emergency Contact Update Reminder",
      message: "Please ensure all emergency contact information is up to date in your profile.",
      type: "reminder",
      priority: "medium",
      recipients: "clients",
      sentDate: "2024-01-13",
      sentBy: "Administrator",
      status: "sent",
      readCount: 78,
      totalRecipients: 156,
    },
    {
      id: 4,
      title: "Holiday Schedule Changes",
      message: "Updated holiday schedule for February. Please review your assignments.",
      type: "schedule",
      priority: "low",
      recipients: "caregivers",
      sentDate: "2024-01-12",
      sentBy: "Scheduling Department",
      status: "draft",
      readCount: 0,
      totalRecipients: 89,
    },
  ])

  const getTypeColor = (type: string) => {
    switch (type) {
      case "system":
        return "bg-blue-100 text-blue-800"
      case "emergency":
        return "bg-red-100 text-red-800"
      case "training":
        return "bg-purple-100 text-purple-800"
      case "reminder":
        return "bg-yellow-100 text-yellow-800"
      case "schedule":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent":
        return "bg-red-100 text-red-800"
      case "high":
        return "bg-orange-100 text-orange-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "sent":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "draft":
        return <Clock className="h-4 w-4 text-yellow-600" />
      case "failed":
        return <AlertTriangle className="h-4 w-4 text-red-600" />
      default:
        return <Clock className="h-4 w-4 text-gray-600" />
    }
  }

  const stats = {
    total: notifications.length,
    sent: notifications.filter((n) => n.status === "sent").length,
    draft: notifications.filter((n) => n.status === "draft").length,
    totalReads: notifications.reduce((sum, n) => sum + n.readCount, 0),
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <AdminSidebar open={sidebarOpen} onOpenChange={setSidebarOpen} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col lg:ml-64">
        {/* Top Bar */}
        <AdminTopBar userInfo={userInfo} onMenuClick={() => setSidebarOpen(!sidebarOpen)} />

        {/* Page Content */}
        <main className="flex-1 p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Header */}
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Notifications</h1>
                <p className="text-gray-600">Send and manage system-wide notifications</p>
              </div>
              {/* Send Notification Dialog */}
              <Dialog
                open={showSendDialog}
                onOpenChange={(open) => {
                  setShowSendDialog(open)
                  if (!open) setSelectedTemplate(null)
                }}
              >
                <DialogTrigger asChild>
                  <Button className="bg-blue-500 hover:bg-blue-600">
                    <Plus className="h-4 w-4 mr-2" />
                    Send Notification
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>
                      {selectedTemplate ? `Send Notification - ${selectedTemplate.name}` : "Send New Notification"}
                    </DialogTitle>
                    <DialogDescription>
                      {selectedTemplate
                        ? "Customize and send this template notification"
                        : "Create and send a notification to users"}
                    </DialogDescription>
                  </DialogHeader>
                  <NotificationForm
                    selectedTemplate={selectedTemplate}
                    onCancel={() => {
                      setShowSendDialog(false)
                      setSelectedTemplate(null)
                    }}
                  />
                </DialogContent>
              </Dialog>

              {/* Template Creation Dialog */}
              <Dialog open={showTemplateDialog} onOpenChange={setShowTemplateDialog}>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Create New Template</DialogTitle>
                    <DialogDescription>Create a reusable notification template</DialogDescription>
                  </DialogHeader>
                  <TemplateForm onCancel={() => setShowTemplateDialog(false)} />
                </DialogContent>
              </Dialog>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
                  <div className="text-sm text-gray-600">Total Notifications</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-green-600">{stats.sent}</div>
                  <div className="text-sm text-gray-600">Sent</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-yellow-600">{stats.draft}</div>
                  <div className="text-sm text-gray-600">Drafts</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-blue-600">{stats.totalReads}</div>
                  <div className="text-sm text-gray-600">Total Reads</div>
                </CardContent>
              </Card>
            </div>

            {/* Notifications Tabs */}
            <Tabs defaultValue="all" className="space-y-6">
              <TabsList>
                <TabsTrigger value="all">All Notifications</TabsTrigger>
                <TabsTrigger value="sent">Sent</TabsTrigger>
                <TabsTrigger value="drafts">Drafts</TabsTrigger>
                <TabsTrigger value="templates">Templates</TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Bell className="h-5 w-5" />
                      All Notifications
                    </CardTitle>
                    <CardDescription>Manage all system notifications</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {notifications.map((notification) => (
                        <div key={notification.id} className="p-4 border rounded-lg hover:shadow-md transition-shadow">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                {getStatusIcon(notification.status)}
                                <h3 className="font-semibold text-lg">{notification.title}</h3>
                                <Badge className={getTypeColor(notification.type)}>{notification.type}</Badge>
                                <Badge className={getPriorityColor(notification.priority)}>
                                  {notification.priority}
                                </Badge>
                              </div>

                              <p className="text-gray-700 mb-3">{notification.message}</p>

                              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-gray-600">
                                <div>
                                  <span className="font-medium">Recipients:</span> {notification.recipients}
                                </div>
                                <div>
                                  <span className="font-medium">Sent Date:</span> {notification.sentDate}
                                </div>
                                <div>
                                  <span className="font-medium">Sent By:</span> {notification.sentBy}
                                </div>
                                <div>
                                  <span className="font-medium">Read Rate:</span>{" "}
                                  {notification.status === "sent"
                                    ? `${notification.readCount}/${notification.totalRecipients}`
                                    : "N/A"}
                                </div>
                              </div>
                            </div>

                            <div className="flex flex-col gap-2 ml-4">
                              <Button variant="outline" size="sm">
                                <Eye className="h-4 w-4 mr-2" />
                                View
                              </Button>
                              {notification.status === "draft" && (
                                <Button size="sm" className="bg-blue-500 hover:bg-blue-600">
                                  <Send className="h-4 w-4 mr-2" />
                                  Send
                                </Button>
                              )}
                              <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700">
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="sent" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Sent Notifications</CardTitle>
                    <CardDescription>Previously sent notifications and their delivery status</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {notifications
                        .filter((n) => n.status === "sent")
                        .map((notification) => (
                          <div key={notification.id} className="p-4 border rounded-lg">
                            <h3 className="font-semibold">{notification.title}</h3>
                            <p className="text-gray-600 text-sm mt-1">{notification.message}</p>
                            <div className="flex justify-between items-center mt-3">
                              <span className="text-sm text-gray-500">Sent: {notification.sentDate}</span>
                              <span className="text-sm text-green-600">
                                Read: {notification.readCount}/{notification.totalRecipients}
                              </span>
                            </div>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="drafts" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Draft Notifications</CardTitle>
                    <CardDescription>Unsent notification drafts</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {notifications
                        .filter((n) => n.status === "draft")
                        .map((notification) => (
                          <div key={notification.id} className="p-4 border rounded-lg">
                            <h3 className="font-semibold">{notification.title}</h3>
                            <p className="text-gray-600 text-sm mt-1">{notification.message}</p>
                            <div className="flex justify-between items-center mt-3">
                              <span className="text-sm text-gray-500">Created: {notification.sentDate}</span>
                              <Button size="sm" className="bg-blue-500 hover:bg-blue-600">
                                <Send className="h-4 w-4 mr-2" />
                                Send Now
                              </Button>
                            </div>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="templates" className="space-y-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-lg font-semibold">Notification Templates</h3>
                    <p className="text-gray-600">Pre-defined notification templates for common messages</p>
                  </div>
                  <Button onClick={handleCreateTemplate} variant="outline">
                    <Plus className="h-4 w-4 mr-2" />
                    Create Template
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {notificationTemplates.map((template) => (
                    <Card key={template.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <h4 className="font-semibold text-lg">{template.name}</h4>
                            <p className="text-gray-600 text-sm mt-1">{template.description}</p>
                          </div>
                          <Badge className={getTypeColor(template.type)}>{template.type}</Badge>
                        </div>

                        <div className="space-y-2 text-sm text-gray-600 mb-4">
                          <div className="flex justify-between">
                            <span>Priority:</span>
                            <Badge className={getPriorityColor(template.priority)} variant="outline">
                              {template.priority}
                            </Badge>
                          </div>
                          <div className="flex justify-between">
                            <span>Recipients:</span>
                            <span className="capitalize">{template.recipients}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Variables:</span>
                            <span>{template.variables.length}</span>
                          </div>
                        </div>

                        <div className="bg-gray-50 p-3 rounded text-xs text-gray-700 mb-4 max-h-20 overflow-y-auto">
                          <strong>Preview:</strong> {template.message.substring(0, 100)}...
                        </div>

                        <div className="flex gap-2">
                          <Button
                            onClick={() => handleUseTemplate(template)}
                            size="sm"
                            className="flex-1 bg-blue-500 hover:bg-blue-600"
                          >
                            Use Template
                          </Button>
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  )
}

// Update the NotificationForm component to accept templates
function NotificationForm({ onCancel, selectedTemplate = null }: { onCancel: () => void; selectedTemplate?: any }) {
  const [formData, setFormData] = useState({
    title: selectedTemplate?.title || "",
    message: selectedTemplate?.message || "",
    type: selectedTemplate?.type || "",
    priority: selectedTemplate?.priority || "medium",
    recipients: selectedTemplate?.recipients || "all",
    sendNow: true,
    scheduleDate: "",
    scheduleTime: "",
  })

  // Rest of the component remains the same
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Sending notification:", formData)
    onCancel()
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {selectedTemplate && (
        <div className="p-3 bg-blue-50 rounded-lg mb-4">
          <p className="text-sm text-blue-700">
            <strong>Using template:</strong> {selectedTemplate.name}
          </p>
        </div>
      )}

      <div className="space-y-2">
        <Label htmlFor="title">Notification Title</Label>
        <Input
          id="title"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          placeholder="Enter notification title"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="message">Message</Label>
        <Textarea
          id="message"
          value={formData.message}
          onChange={(e) => setFormData({ ...formData, message: e.target.value })}
          placeholder="Enter your message"
          rows={4}
          required
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="type">Type</Label>
          <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="system">System</SelectItem>
              <SelectItem value="emergency">Emergency</SelectItem>
              <SelectItem value="training">Training</SelectItem>
              <SelectItem value="reminder">Reminder</SelectItem>
              <SelectItem value="schedule">Schedule</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="priority">Priority</Label>
          <Select value={formData.priority} onValueChange={(value) => setFormData({ ...formData, priority: value })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="urgent">Urgent</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="recipients">Recipients</Label>
        <Select value={formData.recipients} onValueChange={(value) => setFormData({ ...formData, recipients: value })}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Users</SelectItem>
            <SelectItem value="caregivers">Caregivers Only</SelectItem>
            <SelectItem value="clients">Clients Only</SelectItem>
            <SelectItem value="admins">Administrators Only</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="send-now"
          checked={formData.sendNow}
          onCheckedChange={(checked) => setFormData({ ...formData, sendNow: checked })}
        />
        <Label htmlFor="send-now">Send immediately</Label>
      </div>

      {!formData.sendNow && (
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="schedule-date">Schedule Date</Label>
            <Input
              id="schedule-date"
              type="date"
              value={formData.scheduleDate}
              onChange={(e) => setFormData({ ...formData, scheduleDate: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="schedule-time">Schedule Time</Label>
            <Input
              id="schedule-time"
              type="time"
              value={formData.scheduleTime}
              onChange={(e) => setFormData({ ...formData, scheduleTime: e.target.value })}
            />
          </div>
        </div>
      )}

      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" className="bg-blue-500 hover:bg-blue-600">
          <Send className="h-4 w-4 mr-2" />
          {formData.sendNow ? "Send Now" : "Schedule"}
        </Button>
      </div>
    </form>
  )
}

// Template Form Component
function TemplateForm({ onCancel }: { onCancel: () => void }) {
  const [formData, setFormData] = useState({
    name: "",
    title: "",
    message: "",
    type: "",
    priority: "medium",
    recipients: "all",
    description: "",
    variables: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Creating template:", formData)
    onCancel()
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="template-name">Template Name</Label>
        <Input
          id="template-name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="Enter template name"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="template-description">Description</Label>
        <Input
          id="template-description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Brief description of when to use this template"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="template-title">Default Title</Label>
        <Input
          id="template-title"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          placeholder="Default notification title"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="template-message">Message Template</Label>
        <Textarea
          id="template-message"
          value={formData.message}
          onChange={(e) => setFormData({ ...formData, message: e.target.value })}
          placeholder="Enter message template (use [VARIABLE] for dynamic content)"
          rows={4}
          required
        />
        <p className="text-xs text-gray-500">Use square brackets for variables, e.g., [DATE], [NAME], [TIME]</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label htmlFor="template-type">Type</Label>
          <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="system">System</SelectItem>
              <SelectItem value="emergency">Emergency</SelectItem>
              <SelectItem value="training">Training</SelectItem>
              <SelectItem value="reminder">Reminder</SelectItem>
              <SelectItem value="schedule">Schedule</SelectItem>
              <SelectItem value="welcome">Welcome</SelectItem>
              <SelectItem value="billing">Billing</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="template-priority">Default Priority</Label>
          <Select value={formData.priority} onValueChange={(value) => setFormData({ ...formData, priority: value })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="urgent">Urgent</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="template-recipients">Default Recipients</Label>
          <Select
            value={formData.recipients}
            onValueChange={(value) => setFormData({ ...formData, recipients: value })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Users</SelectItem>
              <SelectItem value="caregivers">Caregivers Only</SelectItem>
              <SelectItem value="clients">Clients Only</SelectItem>
              <SelectItem value="admins">Administrators Only</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="template-variables">Variables (comma-separated)</Label>
        <Input
          id="template-variables"
          value={formData.variables}
          onChange={(e) => setFormData({ ...formData, variables: e.target.value })}
          placeholder="DATE, TIME, NAME, CAREGIVER"
        />
        <p className="text-xs text-gray-500">List the variables used in your template message</p>
      </div>

      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" className="bg-blue-500 hover:bg-blue-600">
          Create Template
        </Button>
      </div>
    </form>
  )
}
