"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { AdminSidebar } from "@/components/admin-sidebar"
import { AdminTopBar } from "@/components/admin-top-bar"
import {
  ClipboardList,
  Search,
  Clock,
  User,
  Phone,
  Mail,
  Calendar,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Eye,
  MessageSquare,
  Plus,
  FileText,
  Car,
} from "lucide-react"

export default function ServiceRequestsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [userInfo, setUserInfo] = useState({ name: "Administrator", email: "admin@warmheaven.com" })
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [priorityFilter, setPriorityFilter] = useState("all")
  const [selectedRequest, setSelectedRequest] = useState(null)
  const [showDetailsDialog, setShowDetailsDialog] = useState(false)
  const [showResponseDialog, setShowResponseDialog] = useState(false)

  // Mock service requests data
  const [requests, setRequests] = useState([
    {
      id: 1,
      type: "additional-hours",
      title: "Additional Evening Care",
      description: "Request for additional 2 hours of evening care on weekends for mobility assistance.",
      client: {
        name: "Margaret Johnson",
        email: "margaret.j@email.com",
        phone: "555-0124",
        caregiver: "Sarah Wilson",
      },
      priority: "medium",
      status: "pending",
      submittedDate: "2024-01-14",
      requestedDate: "2024-01-20",
      estimatedCost: "$240/week",
      notes: "Client has been experiencing increased difficulty with evening routines.",
      adminNotes: "",
      assignedTo: "Sarah Wilson",
    },
    {
      id: 2,
      type: "schedule-change",
      title: "Schedule Modification",
      description: "Change Tuesday appointment from 9:00 AM to 11:00 AM due to medical appointments.",
      client: {
        name: "Robert Miller",
        email: "robert.m@email.com",
        phone: "555-0127",
        caregiver: "Mike Davis",
      },
      priority: "low",
      status: "approved",
      submittedDate: "2024-01-12",
      requestedDate: "2024-01-16",
      estimatedCost: "No additional cost",
      notes: "Regular medical checkup scheduled at 9:30 AM on Tuesdays.",
      adminNotes: "Approved. Schedule updated in system.",
      assignedTo: "Mike Davis",
    },
    {
      id: 3,
      type: "service-addition",
      title: "Medication Management Service",
      description: "Add medication management and reminder service to existing care plan.",
      client: {
        name: "Eleanor Brown",
        email: "eleanor.b@email.com",
        phone: "555-0128",
        caregiver: "Lisa Chen",
      },
      priority: "high",
      status: "in-review",
      submittedDate: "2024-01-13",
      requestedDate: "2024-01-18",
      estimatedCost: "$150/month",
      notes: "Family concerned about medication compliance. Multiple prescriptions to manage.",
      adminNotes: "Reviewing caregiver qualifications for medication management.",
      assignedTo: "Lisa Chen",
    },
    {
      id: 4,
      type: "caregiver-change",
      title: "Caregiver Replacement Request",
      description: "Request for a different caregiver due to scheduling conflicts.",
      client: {
        name: "James Wilson",
        email: "james.w@email.com",
        phone: "555-0129",
        caregiver: "Tom Anderson",
      },
      priority: "urgent",
      status: "pending",
      submittedDate: "2024-01-15",
      requestedDate: "2024-01-17",
      estimatedCost: "No additional cost",
      notes: "Current caregiver has scheduling conflicts with client's preferred times.",
      adminNotes: "",
      assignedTo: "Unassigned",
    },
    {
      id: 5,
      type: "emergency-care",
      title: "Emergency Care Coverage",
      description: "Temporary increase in care hours due to recent fall and recovery needs.",
      client: {
        name: "Dorothy Smith",
        email: "dorothy.s@email.com",
        phone: "555-0130",
        caregiver: "Sarah Wilson",
      },
      priority: "urgent",
      status: "approved",
      submittedDate: "2024-01-15",
      requestedDate: "2024-01-16",
      estimatedCost: "$480/week",
      notes: "Client fell at home. Doctor recommends increased supervision during recovery.",
      adminNotes: "Emergency approval granted. Review in 2 weeks.",
      assignedTo: "Sarah Wilson",
    },
    {
      id: 6,
      type: "transportation",
      title: "Transportation Service",
      description: "Request for transportation assistance to medical appointments.",
      client: {
        name: "Frank Thompson",
        email: "frank.t@email.com",
        phone: "555-0131",
        caregiver: "Mike Davis",
      },
      priority: "medium",
      status: "approved",
      submittedDate: "2024-01-10",
      requestedDate: "2024-01-15",
      estimatedCost: "$50/trip",
      notes: "Client needs transportation to weekly physical therapy appointments.",
      adminNotes:
        "Transportation services approved. Assigned to Mike Davis. Service includes door-to-door assistance and appointment accompaniment.",
      assignedTo: "Mike Davis",
    },
    {
      id: 7,
      type: "transportation",
      title: "Weekly Grocery Shopping Transport",
      description: "Request for weekly transportation to grocery store and pharmacy.",
      client: {
        name: "Helen Martinez",
        email: "helen.m@email.com",
        phone: "555-0132",
        caregiver: "Sarah Wilson",
      },
      priority: "low",
      status: "pending",
      submittedDate: "2024-01-15",
      requestedDate: "2024-01-22",
      estimatedCost: "$40/trip",
      notes: "Client needs assistance with weekly shopping. Prefers Tuesday mornings.",
      adminNotes: "",
      assignedTo: "Sarah Wilson",
    },
  ])

  const filteredRequests = requests.filter((request) => {
    const matchesSearch =
      request.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || request.status === statusFilter
    const matchesPriority = priorityFilter === "all" || request.priority === priorityFilter
    return matchesSearch && matchesStatus && matchesPriority
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "in-review":
        return "bg-blue-100 text-blue-800"
      case "approved":
        return "bg-green-100 text-green-800"
      case "rejected":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent":
        return "bg-red-100 text-red-800"
      case "high":
        return "bg-orange-100 text-orange-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "additional-hours":
        return <Clock className="h-4 w-4" />
      case "schedule-change":
        return <Calendar className="h-4 w-4" />
      case "service-addition":
        return <Plus className="h-4 w-4" />
      case "caregiver-change":
        return <User className="h-4 w-4" />
      case "emergency-care":
        return <AlertTriangle className="h-4 w-4" />
      case "transportation":
        return <Car className="h-4 w-4" />
      default:
        return <FileText className="h-4 w-4" />
    }
  }

  const handleStatusChange = (requestId: number, newStatus: string, adminNotes = "") => {
    setRequests(
      requests.map((request) => (request.id === requestId ? { ...request, status: newStatus, adminNotes } : request)),
    )
  }

  const handleViewDetails = (request: any) => {
    setSelectedRequest(request)
    setShowDetailsDialog(true)
  }

  const handleRespond = (request: any) => {
    setSelectedRequest(request)
    setShowResponseDialog(true)
  }

  const stats = {
    total: requests.length,
    pending: requests.filter((r) => r.status === "pending").length,
    inReview: requests.filter((r) => r.status === "in-review").length,
    approved: requests.filter((r) => r.status === "approved").length,
    rejected: requests.filter((r) => r.status === "rejected").length,
    urgent: requests.filter((r) => r.priority === "urgent").length,
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <AdminSidebar open={sidebarOpen} onOpenChange={setSidebarOpen} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col lg:ml-64">
        {/* Top Bar */}
        <AdminTopBar userInfo={userInfo} onMenuClick={() => setSidebarOpen(!sidebarOpen)} />

        {/* Page Content */}
        <main className="flex-1 p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Header */}
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Service Requests</h1>
                <p className="text-gray-600">Manage client service requests and care modifications</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="bg-yellow-50 text-yellow-700">
                  {stats.pending} Pending
                </Badge>
                <Badge variant="outline" className="bg-red-50 text-red-700">
                  {stats.urgent} Urgent
                </Badge>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
                  <div className="text-sm text-gray-600">Total Requests</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
                  <div className="text-sm text-gray-600">Pending</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-blue-600">{stats.inReview}</div>
                  <div className="text-sm text-gray-600">In Review</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-green-600">{stats.approved}</div>
                  <div className="text-sm text-gray-600">Approved</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-red-600">{stats.rejected}</div>
                  <div className="text-sm text-gray-600">Rejected</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-red-600">{stats.urgent}</div>
                  <div className="text-sm text-gray-600">Urgent</div>
                </CardContent>
              </Card>
            </div>

            {/* Filters */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Search requests by title, client, or description..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="in-review">In Review</SelectItem>
                        <SelectItem value="approved">Approved</SelectItem>
                        <SelectItem value="rejected">Rejected</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Priority</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Requests List */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ClipboardList className="h-5 w-5" />
                  Service Requests ({filteredRequests.length})
                </CardTitle>
                <CardDescription>Review and manage client service requests</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredRequests.map((request) => (
                    <div key={request.id} className="p-4 border rounded-lg hover:shadow-md transition-shadow">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-4 flex-1">
                          <div className="mt-1">{getTypeIcon(request.type)}</div>
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="font-semibold text-lg">{request.title}</h3>
                              <Badge className={getStatusColor(request.status)}>{request.status}</Badge>
                              <Badge className={getPriorityColor(request.priority)}>{request.priority}</Badge>
                            </div>

                            <p className="text-gray-700 mb-3">{request.description}</p>

                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm text-gray-600">
                              <div className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <User className="h-4 w-4" />
                                  <span className="font-medium">{request.client.name}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <Mail className="h-4 w-4" />
                                  <span>{request.client.email}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <Phone className="h-4 w-4" />
                                  <span>{request.client.phone}</span>
                                </div>
                              </div>

                              <div className="space-y-1">
                                <div>
                                  <span className="font-medium">Caregiver:</span> {request.client.caregiver}
                                </div>
                                <div>
                                  <span className="font-medium">Submitted:</span> {request.submittedDate}
                                </div>
                                <div>
                                  <span className="font-medium">Requested Date:</span> {request.requestedDate}
                                </div>
                              </div>

                              <div className="space-y-1">
                                <div>
                                  <span className="font-medium">Estimated Cost:</span> {request.estimatedCost}
                                </div>
                                <div>
                                  <span className="font-medium">Assigned To:</span> {request.assignedTo}
                                </div>
                              </div>
                            </div>

                            {request.notes && (
                              <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                                <span className="font-medium text-sm">Client Notes: </span>
                                <span className="text-sm">{request.notes}</span>
                              </div>
                            )}

                            {request.adminNotes && (
                              <div className="mt-2 p-3 bg-blue-50 rounded-lg">
                                <span className="font-medium text-sm">Admin Notes: </span>
                                <span className="text-sm">{request.adminNotes}</span>
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="flex flex-col gap-2 ml-4">
                          <Button variant="outline" size="sm" onClick={() => handleViewDetails(request)}>
                            <Eye className="h-4 w-4 mr-2" />
                            View Details
                          </Button>

                          {request.status === "pending" && (
                            <>
                              <Button
                                size="sm"
                                onClick={() => handleStatusChange(request.id, "approved")}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Approve
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleStatusChange(request.id, "in-review")}
                                className="text-blue-600 hover:text-blue-700"
                              >
                                <Clock className="h-4 w-4 mr-2" />
                                Review
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleRespond(request)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <XCircle className="h-4 w-4 mr-2" />
                                Reject
                              </Button>
                            </>
                          )}

                          {request.status === "in-review" && (
                            <>
                              <Button
                                size="sm"
                                onClick={() => handleStatusChange(request.id, "approved")}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Approve
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleRespond(request)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <XCircle className="h-4 w-4 mr-2" />
                                Reject
                              </Button>
                            </>
                          )}

                          <Button variant="outline" size="sm">
                            <MessageSquare className="h-4 w-4 mr-2" />
                            Message
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>

      {/* Request Details Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Request Details</DialogTitle>
            <DialogDescription>Complete information about this service request</DialogDescription>
          </DialogHeader>
          {selectedRequest && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="font-medium">Request ID</Label>
                  <p className="text-sm text-gray-600">#{selectedRequest.id}</p>
                </div>
                <div>
                  <Label className="font-medium">Type</Label>
                  <p className="text-sm text-gray-600">{selectedRequest.type}</p>
                </div>
              </div>

              <div>
                <Label className="font-medium">Title</Label>
                <p className="text-sm text-gray-600">{selectedRequest.title}</p>
              </div>

              <div>
                <Label className="font-medium">Description</Label>
                <p className="text-sm text-gray-600">{selectedRequest.description}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="font-medium">Client</Label>
                  <p className="text-sm text-gray-600">{selectedRequest.client.name}</p>
                  <p className="text-sm text-gray-600">{selectedRequest.client.email}</p>
                  <p className="text-sm text-gray-600">{selectedRequest.client.phone}</p>
                </div>
                <div>
                  <Label className="font-medium">Caregiver</Label>
                  <p className="text-sm text-gray-600">{selectedRequest.client.caregiver}</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label className="font-medium">Priority</Label>
                  <Badge className={getPriorityColor(selectedRequest.priority)}>{selectedRequest.priority}</Badge>
                </div>
                <div>
                  <Label className="font-medium">Status</Label>
                  <Badge className={getStatusColor(selectedRequest.status)}>{selectedRequest.status}</Badge>
                </div>
                <div>
                  <Label className="font-medium">Estimated Cost</Label>
                  <p className="text-sm text-gray-600">{selectedRequest.estimatedCost}</p>
                </div>
              </div>

              {selectedRequest.notes && (
                <div>
                  <Label className="font-medium">Client Notes</Label>
                  <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded">{selectedRequest.notes}</p>
                </div>
              )}

              {selectedRequest.adminNotes && (
                <div>
                  <Label className="font-medium">Admin Notes</Label>
                  <p className="text-sm text-gray-600 bg-blue-50 p-3 rounded">{selectedRequest.adminNotes}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Response Dialog */}
      <Dialog open={showResponseDialog} onOpenChange={setShowResponseDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Respond to Request</DialogTitle>
            <DialogDescription>Provide a response and update the request status</DialogDescription>
          </DialogHeader>
          {selectedRequest && (
            <RequestResponseForm
              request={selectedRequest}
              onSubmit={(status, notes) => {
                handleStatusChange(selectedRequest.id, status, notes)
                setShowResponseDialog(false)
                setSelectedRequest(null)
              }}
              onCancel={() => {
                setShowResponseDialog(false)
                setSelectedRequest(null)
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Request Response Form Component
function RequestResponseForm({
  request,
  onSubmit,
  onCancel,
}: {
  request: any
  onSubmit: (status: string, notes: string) => void
  onCancel: () => void
}) {
  const [status, setStatus] = useState("rejected")
  const [notes, setNotes] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(status, notes)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="status">Decision</Label>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="approved">Approve Request</SelectItem>
            <SelectItem value="rejected">Reject Request</SelectItem>
            <SelectItem value="in-review">Needs More Review</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Response Notes</Label>
        <Textarea
          id="notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Provide details about your decision..."
          rows={4}
          required
        />
      </div>

      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button
          type="submit"
          className={status === "approved" ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"}
        >
          {status === "approved" ? "Approve Request" : status === "rejected" ? "Reject Request" : "Update Status"}
        </Button>
      </div>
    </form>
  )
}
