"use client"

import { useState, useCallback } from "react"
import { AdminSidebar } from "@/components/admin-sidebar"
import { AdminTopBar } from "@/components/admin-top-bar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  FileText,
  Download,
  Calendar,
  Users,
  DollarSign,
  Star,
  Activity,
  Heart,
  Filter,
  RefreshCw,
  BarChart3,
  TrendingUp,
  Eye,
  Clock,
  FileSpreadsheet,
  FileSpreadsheetIcon as FileCsv,
} from "lucide-react"
import {
  generateCSVContent,
  generateExcelContent,
  generatePDFContent,
  downloadFile,
  generateMockData,
  showNotification,
} from "@/lib/report-generator"

interface ReportData {
  id: string
  type: string
  title: string
  generatedDate: string
  generatedBy: string
  status: "completed" | "processing" | "failed"
  downloadUrl?: string
  data: any
}

interface AnalyticsData {
  totalUsers: number
  activeUsers: number
  totalAppointments: number
  completedAppointments: number
  totalRevenue: number
  avgRating: number
  caregiverUtilization: number
  clientSatisfaction: number
  monthlyGrowth: number
  weeklyHours: number
}

export default function AdminReports() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [userInfo, setUserInfo] = useState({ name: "Administrator", email: "admin@warmheaven.com" })
  const [selectedReport, setSelectedReport] = useState("")
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [selectedCaregiver, setSelectedCaregiver] = useState("")
  const [reportStatus, setReportStatus] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [activeTab, setActiveTab] = useState("analytics")
  const [showReportDialog, setShowReportDialog] = useState(false)
  const [selectedReportData, setSelectedReportData] = useState<ReportData | null>(null)
  const [generatingFormat, setGeneratingFormat] = useState<string | null>(null)

  // Mock analytics data
  const analyticsData: AnalyticsData = {
    totalUsers: 156,
    activeUsers: 142,
    totalAppointments: 1247,
    completedAppointments: 1189,
    totalRevenue: 125400,
    avgRating: 4.8,
    caregiverUtilization: 87,
    clientSatisfaction: 94,
    monthlyGrowth: 12,
    weeklyHours: 2840,
  }

  // Mock reports data
  const [reports, setReports] = useState<ReportData[]>([
    {
      id: "1",
      type: "user-activity",
      title: "User Activity Report - January 2024",
      generatedDate: "2024-01-15",
      generatedBy: "Administrator",
      status: "completed",
      downloadUrl: "/reports/user-activity-jan-2024.pdf",
      data: {
        totalLogins: 2847,
        avgSessionTime: "24 minutes",
        activeUsers: 142,
        newUsers: 23,
      },
    },
    {
      id: "2",
      type: "financial",
      title: "Financial Overview - Q4 2023",
      generatedDate: "2024-01-10",
      generatedBy: "Administrator",
      status: "completed",
      downloadUrl: "/reports/financial-q4-2023.pdf",
      data: {
        totalRevenue: 125400,
        expenses: 89200,
        profit: 36200,
        profitMargin: 28.9,
      },
    },
    {
      id: "3",
      type: "appointments",
      title: "Appointment Summary - December 2023",
      generatedDate: "2024-01-08",
      generatedBy: "Administrator",
      status: "completed",
      downloadUrl: "/reports/appointments-dec-2023.pdf",
      data: {
        totalAppointments: 387,
        completedAppointments: 371,
        cancelledAppointments: 16,
        completionRate: 95.9,
      },
    },
    {
      id: "4",
      type: "performance",
      title: "Caregiver Performance - January 2024",
      generatedDate: "2024-01-12",
      generatedBy: "Administrator",
      status: "completed",
      downloadUrl: "/reports/performance-jan-2024.pdf",
      data: {
        avgRating: 4.8,
        totalCaregivers: 28,
        topPerformer: "Sarah Wilson",
        improvementNeeded: 3,
      },
    },
  ])

  const reportTypes = [
    {
      id: "user-activity",
      name: "User Activity Report",
      description: "Login statistics, active sessions, and user engagement",
      icon: Users,
      color: "bg-blue-100 text-blue-600",
      fields: ["Login Times", "Session Duration", "Last Activity", "User Status"],
    },
    {
      id: "appointments",
      name: "Appointment Summary",
      description: "Comprehensive appointment data and scheduling analytics",
      icon: Calendar,
      color: "bg-green-100 text-green-600",
      fields: ["Appointment Count", "Completion Rate", "Cancellations", "Revenue"],
    },
    {
      id: "financial",
      name: "Financial Overview",
      description: "Revenue, expenses, and billing information",
      icon: DollarSign,
      color: "bg-yellow-100 text-yellow-600",
      fields: ["Total Revenue", "Outstanding Payments", "Expenses", "Profit Margin"],
    },
    {
      id: "performance",
      name: "Caregiver Performance",
      description: "Individual caregiver ratings and completion statistics",
      icon: Star,
      color: "bg-purple-100 text-purple-600",
      fields: ["Average Rating", "Completed Appointments", "Client Feedback", "Punctuality"],
    },
    {
      id: "services",
      name: "Service Utilization",
      description: "Usage patterns and revenue by service type",
      icon: Activity,
      color: "bg-orange-100 text-orange-600",
      fields: ["Service Types", "Usage Frequency", "Revenue per Service", "Popular Times"],
    },
    {
      id: "satisfaction",
      name: "Client Satisfaction",
      description: "Client feedback, ratings, and satisfaction metrics",
      icon: Heart,
      color: "bg-pink-100 text-pink-600",
      fields: ["Satisfaction Score", "Feedback Comments", "Improvement Areas", "Retention Rate"],
    },
  ]

  const caregivers = ["All Caregivers", "Sarah Wilson", "Mike Davis", "Lisa Chen", "John Smith", "Emily Johnson"]

  // Handle report generation with improved error handling
  const handleGenerateReport = useCallback(
    async (format: string) => {
      if (!selectedReport) {
        showNotification("Please select a report type first", "error")
        return
      }

      setIsGenerating(true)
      setGeneratingFormat(format)

      try {
        // Get report type and generate data
        const reportType = reportTypes.find((r) => r.id === selectedReport)
        const reportData = generateMockData(selectedReport, dateFrom, dateTo, selectedCaregiver)
        const timestamp = new Date().toISOString().split("T")[0]
        const filename = `${selectedReport}-report-${timestamp}`
        const reportTitle = `${reportType?.name} - ${new Date().toLocaleDateString()}`

        // Short delay to show loading state
        await new Promise((resolve) => setTimeout(resolve, 800))

        let content: string
        let contentType: string
        let fileExtension: string

        // Generate appropriate content based on format
        switch (format.toLowerCase()) {
          case "csv":
            content = generateCSVContent(selectedReport, reportData)
            contentType = "text/csv;charset=utf-8;"
            fileExtension = "csv"
            break

          case "excel":
            content = generateExcelContent(selectedReport, reportData)
            contentType = "application/vnd.ms-excel"
            fileExtension = "xls"
            break

          case "pdf":
          default:
            content = generatePDFContent(selectedReport, reportData, reportTitle)
            contentType = "text/html"
            fileExtension = "html" // Browser will convert to PDF when printing
            break
        }

        // Download the file
        downloadFile(content, `${filename}.${fileExtension}`, contentType)

        // Add to reports history
        const newReport: ReportData = {
          id: Date.now().toString(),
          type: selectedReport,
          title: reportTitle,
          generatedDate: new Date().toISOString().split("T")[0],
          generatedBy: "Administrator",
          status: "completed",
          downloadUrl: `${filename}.${fileExtension}`,
          data: reportData,
        }

        setReports((prev) => [newReport, ...prev])

        // Show success message
        showNotification(`${reportType?.name} generated successfully as ${format.toUpperCase()}!`, "success")

        // If PDF, show additional instructions
        if (format.toLowerCase() === "pdf") {
          setTimeout(() => {
            showNotification("Use your browser's print function to save as PDF", "info")
          }, 1000)
        }
      } catch (error) {
        console.error("Error generating report:", error)
        showNotification("Failed to generate report. Please try again.", "error")
      } finally {
        setIsGenerating(false)
        setGeneratingFormat(null)
      }
    },
    [selectedReport, dateFrom, dateTo, selectedCaregiver],
  )

  // Handle viewing a report
  const handleViewReport = useCallback((report: ReportData) => {
    setSelectedReportData(report)
    setShowReportDialog(true)
  }, [])

  // Handle downloading a report from history
  const handleDownloadReport = useCallback((report: ReportData) => {
    try {
      const reportData = report.data
      const reportTitle = report.title

      // Generate content based on file extension in downloadUrl
      let content: string
      let contentType: string
      let fileExtension: string

      if (report.downloadUrl?.endsWith(".csv")) {
        content = generateCSVContent(report.type, reportData)
        contentType = "text/csv;charset=utf-8;"
        fileExtension = "csv"
      } else if (report.downloadUrl?.endsWith(".xls") || report.downloadUrl?.endsWith(".xlsx")) {
        content = generateExcelContent(report.type, reportData)
        contentType = "application/vnd.ms-excel"
        fileExtension = "xls"
      } else {
        content = generatePDFContent(report.type, reportData, reportTitle)
        contentType = "text/html"
        fileExtension = "html"
      }

      // Download the file
      downloadFile(content, `${report.type}-${report.generatedDate}.${fileExtension}`, contentType)

      // Show success notification
      showNotification(`${report.title} downloaded successfully!`, "success")

      // If HTML (for PDF), show additional instructions
      if (fileExtension === "html") {
        setTimeout(() => {
          showNotification("Use your browser's print function to save as PDF", "info")
        }, 1000)
      }
    } catch (error) {
      console.error("Error downloading report:", error)
      showNotification("Failed to download report. Please try again.", "error")
    }
  }, [])

  const quickStats = [
    { label: "Reports Generated", value: reports.length.toString(), change: "+12%" },
    { label: "Data Points", value: "2.4K", change: "+8%" },
    { label: "Export Downloads", value: "89", change: "+15%" },
    { label: "Scheduled Reports", value: "12", change: "+3%" },
  ]

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <AdminSidebar open={sidebarOpen} onOpenChange={setSidebarOpen} />

      <div className="flex-1 flex flex-col lg:ml-64">
        <AdminTopBar userInfo={userInfo} onMenuClick={() => setSidebarOpen(!sidebarOpen)} />

        <main className="flex-1 p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Header */}
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Reports & Analytics</h1>
              <p className="text-gray-600">Generate comprehensive reports and analyze your care management data.</p>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="analytics">Analytics Dashboard</TabsTrigger>
                <TabsTrigger value="generate">Generate Reports</TabsTrigger>
                <TabsTrigger value="history">Report History</TabsTrigger>
              </TabsList>

              {/* Analytics Dashboard */}
              <TabsContent value="analytics" className="space-y-6">
                {/* Quick Stats */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  {quickStats.map((stat, index) => (
                    <Card key={index}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-gray-600">{stat.label}</p>
                            <p className="text-2xl font-bold">{stat.value}</p>
                            <p className="text-sm text-green-600">{stat.change}</p>
                          </div>
                          <BarChart3 className="h-8 w-8 text-gray-400" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Main Analytics Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Users className="h-5 w-5 text-blue-600" />
                        User Statistics
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Total Users</span>
                          <span className="font-semibold">{analyticsData.totalUsers}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Active Users</span>
                          <span className="font-semibold text-green-600">{analyticsData.activeUsers}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{ width: `${(analyticsData.activeUsers / analyticsData.totalUsers) * 100}%` }}
                          ></div>
                        </div>
                        <p className="text-sm text-gray-500">
                          {Math.round((analyticsData.activeUsers / analyticsData.totalUsers) * 100)}% active rate
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Calendar className="h-5 w-5 text-green-600" />
                        Appointments
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Total Appointments</span>
                          <span className="font-semibold">{analyticsData.totalAppointments}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Completed</span>
                          <span className="font-semibold text-green-600">{analyticsData.completedAppointments}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-green-600 h-2 rounded-full"
                            style={{
                              width: `${(analyticsData.completedAppointments / analyticsData.totalAppointments) * 100}%`,
                            }}
                          ></div>
                        </div>
                        <p className="text-sm text-gray-500">
                          {Math.round((analyticsData.completedAppointments / analyticsData.totalAppointments) * 100)}%
                          completion rate
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <DollarSign className="h-5 w-5 text-yellow-600" />
                        Revenue
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Total Revenue</span>
                          <span className="font-semibold">${analyticsData.totalRevenue.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Monthly Growth</span>
                          <span className="font-semibold text-green-600">+{analyticsData.monthlyGrowth}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div className="bg-yellow-600 h-2 rounded-full" style={{ width: "75%" }}></div>
                        </div>
                        <p className="text-sm text-gray-500">75% of monthly target</p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Star className="h-5 w-5 text-purple-600" />
                        Performance
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Average Rating</span>
                          <span className="font-semibold">{analyticsData.avgRating}/5.0</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Caregiver Utilization</span>
                          <span className="font-semibold text-blue-600">{analyticsData.caregiverUtilization}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-purple-600 h-2 rounded-full"
                            style={{ width: `${analyticsData.caregiverUtilization}%` }}
                          ></div>
                        </div>
                        <p className="text-sm text-gray-500">Excellent performance metrics</p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Heart className="h-5 w-5 text-pink-600" />
                        Client Satisfaction
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Satisfaction Score</span>
                          <span className="font-semibold">{analyticsData.clientSatisfaction}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Weekly Hours</span>
                          <span className="font-semibold text-orange-600">{analyticsData.weeklyHours}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-pink-600 h-2 rounded-full"
                            style={{ width: `${analyticsData.clientSatisfaction}%` }}
                          ></div>
                        </div>
                        <p className="text-sm text-gray-500">Outstanding client feedback</p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <TrendingUp className="h-5 w-5 text-green-600" />
                        Growth Metrics
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Monthly Growth</span>
                          <span className="font-semibold text-green-600">+{analyticsData.monthlyGrowth}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">New Clients</span>
                          <span className="font-semibold">23</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div className="bg-green-600 h-2 rounded-full" style={{ width: "68%" }}></div>
                        </div>
                        <p className="text-sm text-gray-500">Strong growth trajectory</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* Generate Reports */}
              <TabsContent value="generate" className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Report Selection */}
                  <div className="lg:col-span-2">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <FileText className="h-5 w-5" />
                          Select Report Type
                        </CardTitle>
                        <CardDescription>Choose the type of report you want to generate</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {reportTypes.map((report) => (
                            <div
                              key={report.id}
                              className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                                selectedReport === report.id
                                  ? "border-blue-500 bg-blue-50"
                                  : "border-gray-200 hover:border-gray-300"
                              }`}
                              onClick={() => setSelectedReport(report.id)}
                            >
                              <div className="flex items-start gap-3">
                                <div className={`p-2 rounded-lg ${report.color}`}>
                                  <report.icon className="h-5 w-5" />
                                </div>
                                <div className="flex-1">
                                  <h3 className="font-medium text-gray-900">{report.name}</h3>
                                  <p className="text-sm text-gray-600 mt-1">{report.description}</p>
                                  <div className="flex flex-wrap gap-1 mt-2">
                                    {report.fields.slice(0, 2).map((field, index) => (
                                      <Badge key={index} variant="secondary" className="text-xs">
                                        {field}
                                      </Badge>
                                    ))}
                                    {report.fields.length > 2 && (
                                      <Badge variant="outline" className="text-xs">
                                        +{report.fields.length - 2} more
                                      </Badge>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Filters */}
                    <Card className="mt-6">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Filter className="h-5 w-5" />
                          Report Filters
                        </CardTitle>
                        <CardDescription>Customize your report parameters</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="date-from">From Date</Label>
                            <Input
                              id="date-from"
                              type="date"
                              value={dateFrom}
                              onChange={(e) => setDateFrom(e.target.value)}
                            />
                          </div>
                          <div>
                            <Label htmlFor="date-to">To Date</Label>
                            <Input
                              id="date-to"
                              type="date"
                              value={dateTo}
                              onChange={(e) => setDateTo(e.target.value)}
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="caregiver">Caregiver</Label>
                            <Select value={selectedCaregiver} onValueChange={setSelectedCaregiver}>
                              <SelectTrigger>
                                <SelectValue placeholder="Select caregiver" />
                              </SelectTrigger>
                              <SelectContent>
                                {caregivers.map((caregiver) => (
                                  <SelectItem key={caregiver} value={caregiver}>
                                    {caregiver}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="status">Status</Label>
                            <Select value={reportStatus} onValueChange={setReportStatus}>
                              <SelectTrigger>
                                <SelectValue placeholder="Select status" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="all">All Status</SelectItem>
                                <SelectItem value="completed">Completed</SelectItem>
                                <SelectItem value="pending">Pending</SelectItem>
                                <SelectItem value="cancelled">Cancelled</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Generation Panel */}
                  <div>
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Download className="h-5 w-5" />
                          Generate Report
                        </CardTitle>
                        <CardDescription>Export your report in various formats</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {selectedReport && (
                          <div className="p-3 bg-blue-50 rounded-lg">
                            <p className="text-sm font-medium text-blue-900">Selected Report:</p>
                            <p className="text-sm text-blue-700">
                              {reportTypes.find((r) => r.id === selectedReport)?.name}
                            </p>
                          </div>
                        )}

                        <Separator />

                        <div className="space-y-3">
                          <Button
                            onClick={() => handleGenerateReport("PDF")}
                            disabled={!selectedReport || isGenerating}
                            className="w-full relative"
                          >
                            {isGenerating && generatingFormat === "PDF" ? (
                              <>
                                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                                Generating PDF...
                              </>
                            ) : (
                              <>
                                <FileText className="h-4 w-4 mr-2" />
                                Generate PDF Report
                              </>
                            )}
                          </Button>

                          <Button
                            variant="outline"
                            onClick={() => handleGenerateReport("Excel")}
                            disabled={!selectedReport || isGenerating}
                            className="w-full relative"
                          >
                            {isGenerating && generatingFormat === "Excel" ? (
                              <>
                                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                                Generating Excel...
                              </>
                            ) : (
                              <>
                                <FileSpreadsheet className="h-4 w-4 mr-2" />
                                Export to Excel
                              </>
                            )}
                          </Button>

                          <Button
                            variant="outline"
                            onClick={() => handleGenerateReport("CSV")}
                            disabled={!selectedReport || isGenerating}
                            className="w-full relative"
                          >
                            {isGenerating && generatingFormat === "CSV" ? (
                              <>
                                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                                Generating CSV...
                              </>
                            ) : (
                              <>
                                <FileCsv className="h-4 w-4 mr-2" />
                                Export to CSV
                              </>
                            )}
                          </Button>
                        </div>

                        <Separator />

                        <div className="text-sm text-gray-600">
                          <p className="font-medium mb-2">Report will include:</p>
                          {selectedReport && (
                            <ul className="space-y-1">
                              {reportTypes
                                .find((r) => r.id === selectedReport)
                                ?.fields.map((field, index) => (
                                  <li key={index} className="flex items-center gap-2">
                                    <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
                                    {field}
                                  </li>
                                ))}
                            </ul>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </TabsContent>

              {/* Report History */}
              <TabsContent value="history" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="h-5 w-5" />
                      Generated Reports
                    </CardTitle>
                    <CardDescription>View and download previously generated reports</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {reports.map((report) => (
                        <div key={report.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center gap-4">
                            <div className="p-2 rounded-full bg-gray-100">
                              <FileText className="h-5 w-5 text-gray-600" />
                            </div>
                            <div>
                              <h4 className="font-medium">{report.title}</h4>
                              <p className="text-sm text-gray-600">
                                Generated on {report.generatedDate} by {report.generatedBy}
                              </p>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge
                                  variant={
                                    report.status === "completed"
                                      ? "default"
                                      : report.status === "processing"
                                        ? "secondary"
                                        : "destructive"
                                  }
                                >
                                  {report.status === "completed" && "✅"}
                                  {report.status === "processing" && "⏳"}
                                  {report.status === "failed" && "❌"}
                                  {report.status}
                                </Badge>
                                <Badge variant="outline">{report.type}</Badge>
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" onClick={() => handleViewReport(report)}>
                              <Eye className="h-4 w-4 mr-2" />
                              View
                            </Button>
                            {report.status === "completed" && (
                              <Button size="sm" onClick={() => handleDownloadReport(report)}>
                                <Download className="h-4 w-4 mr-2" />
                                Download
                              </Button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>

      {/* Report Details Dialog */}
      <Dialog open={showReportDialog} onOpenChange={setShowReportDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Report Details</DialogTitle>
            <DialogDescription>Detailed information about this report</DialogDescription>
          </DialogHeader>
          {selectedReportData && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="font-medium">Report Title</Label>
                  <p className="text-sm text-gray-600">{selectedReportData.title}</p>
                </div>
                <div>
                  <Label className="font-medium">Type</Label>
                  <p className="text-sm text-gray-600">{selectedReportData.type}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="font-medium">Generated Date</Label>
                  <p className="text-sm text-gray-600">{selectedReportData.generatedDate}</p>
                </div>
                <div>
                  <Label className="font-medium">Generated By</Label>
                  <p className="text-sm text-gray-600">{selectedReportData.generatedBy}</p>
                </div>
              </div>

              <div>
                <Label className="font-medium">Status</Label>
                <Badge
                  variant={
                    selectedReportData.status === "completed"
                      ? "default"
                      : selectedReportData.status === "processing"
                        ? "secondary"
                        : "destructive"
                  }
                  className="ml-2"
                >
                  {selectedReportData.status}
                </Badge>
              </div>

              <Separator />

              <div>
                <Label className="font-medium">Report Data</Label>
                <div className="mt-2 p-4 bg-gray-50 rounded-lg">
                  <pre className="text-sm text-gray-700 whitespace-pre-wrap">
                    {JSON.stringify(selectedReportData.data, null, 2)}
                  </pre>
                </div>
              </div>

              {selectedReportData.status === "completed" && (
                <div className="flex gap-2 pt-4">
                  <Button onClick={() => handleDownloadReport(selectedReportData)} className="flex-1">
                    <Download className="h-4 w-4 mr-2" />
                    Download Report
                  </Button>
                  <Button variant="outline" onClick={() => setShowReportDialog(false)}>
                    Close
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
