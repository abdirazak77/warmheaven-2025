"use client"

import React from "react"

import type { ReactNode } from "react"

import { useState, useCallback, useMemo, useTransition, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ProfilePictureUpload } from "@/components/profile-picture-upload"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { AdminSidebar } from "@/components/admin-sidebar"
import { AdminTopBar } from "@/components/admin-top-bar"
import {
  Users,
  Heart,
  Shield,
  Plus,
  Edit,
  Trash2,
  Search,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Eye,
  UserCheck,
  UserX,
  Save,
  Loader2,
} from "lucide-react"

export default function UsersManagementPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [userInfo, setUserInfo] = useState({ name: "Administrator", email: "admin@warmheaven.com" })
  const [selectedTab, setSelectedTab] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const [showViewDialog, setShowViewDialog] = useState(false)
  const [selectedUser, setSelectedUser] = useState(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isPending, startTransition] = useTransition()

  // Mock users data with profile pictures
  const [users, setUsers] = useState(() => {
    if (typeof window !== "undefined") {
      const savedUsers = localStorage.getItem("allUsers")
      if (savedUsers) {
        try {
          return JSON.parse(savedUsers)
        } catch (error) {
          console.error("Failed to parse saved users:", error)
        }
      }
    }

    // Default users if no saved data
    return [
      {
        id: 1,
        name: "Sarah Johnson",
        username: "sarah.johnson",
        email: "sarah.johnson@warmheaven.com",
        phone: "555-0123",
        role: "caregiver",
        status: "active",
        joinDate: "2023-06-15",
        lastLogin: "2024-01-15 09:30 AM",
        address: "123 Main St, Springfield",
        specialties: ["Elderly Care", "Dementia Support"],
        certifications: ["CNA", "CPR"],
        assignedClients: 8,
        hoursWorked: 156,
        profilePicture: "/placeholder.svg?height=100&width=100",
      },
      {
        id: 2,
        name: "Margaret Johnson",
        username: "margaret.j",
        email: "margaret.j@email.com",
        phone: "555-0124",
        role: "client",
        status: "active",
        joinDate: "2023-08-20",
        lastLogin: "2024-01-14 02:15 PM",
        address: "456 Oak Ave, Springfield",
        emergencyContact: "John Johnson - 555-0156",
        caregiver: "Sarah Johnson",
        servicesPlan: "Personal Care, Meal Prep",
        profilePicture: "",
      },
      {
        id: 3,
        name: "Mike Davis",
        username: "mike.davis",
        email: "mike.davis@warmheaven.com",
        phone: "555-0125",
        role: "caregiver",
        status: "active",
        joinDate: "2023-09-10",
        lastLogin: "2024-01-15 08:45 AM",
        address: "789 Pine St, Springfield",
        specialties: ["Physical Therapy", "Post-Surgery Care"],
        certifications: ["PT Assistant", "CPR", "First Aid"],
        assignedClients: 6,
        hoursWorked: 124,
        profilePicture: "/placeholder.svg?height=100&width=100",
      },
      {
        id: 4,
        name: "Lisa Chen",
        username: "lisa.chen",
        email: "lisa.chen@warmheaven.com",
        phone: "555-0126",
        role: "caregiver",
        status: "pending",
        joinDate: "2024-01-10",
        lastLogin: "Never",
        address: "321 Elm St, Springfield",
        specialties: ["Dementia Care", "Specialized Care"],
        certifications: ["RN", "Dementia Care Specialist"],
        assignedClients: 0,
        hoursWorked: 0,
        profilePicture: "",
      },
      {
        id: 5,
        name: "Robert Miller",
        username: "robert.m",
        email: "robert.m@email.com",
        phone: "555-0127",
        role: "client",
        status: "active",
        joinDate: "2023-11-05",
        lastLogin: "2024-01-13 11:20 AM",
        address: "654 Maple Dr, Springfield",
        emergencyContact: "Susan Miller - 555-0158",
        caregiver: "Mike Davis",
        servicesPlan: "Physical Therapy, Companionship",
        profilePicture: "",
      },
      {
        id: 6,
        name: "Dr. Admin",
        username: "dr.admin",
        email: "admin@warmheaven.com",
        phone: "555-0100",
        role: "admin",
        status: "active",
        joinDate: "2023-01-01",
        lastLogin: "2024-01-15 10:00 AM",
        address: "Warm Heaven Enterprise HQ",
        permissions: ["Full Access", "User Management", "System Settings"],
        profilePicture: "/placeholder.svg?height=100&width=100",
      },
    ]
  })

  // Memoized filtered users for better performance
  const filteredUsers = useMemo(() => {
    return users.filter((user) => {
      const matchesTab = selectedTab === "all" || user.role === selectedTab
      const matchesSearch =
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.phone.includes(searchTerm)
      return matchesTab && matchesSearch
    })
  }, [users, selectedTab, searchTerm])

  // Memoized stats calculation
  const stats = useMemo(
    () => ({
      total: users.length,
      active: users.filter((u) => u.status === "active").length,
      pending: users.filter((u) => u.status === "pending").length,
      caregivers: users.filter((u) => u.role === "caregiver").length,
      clients: users.filter((u) => u.role === "client").length,
      admins: users.filter((u) => u.role === "admin").length,
    }),
    [users],
  )

  // Optimized icon functions with memoization
  const getRoleIcon = useCallback((role: string) => {
    switch (role) {
      case "admin":
        return <Shield className="h-4 w-4 text-blue-600" />
      case "caregiver":
        return <Heart className="h-4 w-4 text-orange-600" />
      case "client":
        return <Users className="h-4 w-4 text-green-600" />
      default:
        return <Users className="h-4 w-4 text-gray-600" />
    }
  }, [])

  const getRoleBadgeColor = useCallback((role: string) => {
    switch (role) {
      case "admin":
        return "bg-blue-100 text-blue-800"
      case "caregiver":
        return "bg-orange-100 text-orange-800"
      case "client":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }, [])

  const getStatusBadgeColor = useCallback((status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "inactive":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }, [])

  // Optimized handlers with useCallback
  const handleAddUser = useCallback(
    (formData: any) => {
      setIsLoading(true)
      startTransition(() => {
        // Check for duplicate username
        const existingUser = users.find((u) => u.username === formData.username)
        if (existingUser) {
          alert("Username already exists! Please choose a different username.")
          setIsLoading(false)
          return
        }

        const newUser = {
          id: Date.now(), // Use timestamp for unique ID
          ...formData,
          joinDate: new Date().toISOString().split("T")[0],
          lastLogin: "Never",
          status: "pending",
          assignedClients: 0,
          hoursWorked: 0,
        }

        const updatedUsers = [...users, newUser]
        setUsers(updatedUsers)

        // Save to localStorage
        localStorage.setItem("allUsers", JSON.stringify(updatedUsers))

        // Also save user credentials for login
        localStorage.setItem(
          `user_${formData.username}`,
          JSON.stringify({
            username: formData.username,
            password: formData.password,
            email: formData.email,
            role: formData.role,
            name: formData.name,
          }),
        )

        setShowAddDialog(false)
        setIsLoading(false)
        alert(`User ${formData.name} created successfully! Username: ${formData.username}`)
      })
    },
    [users],
  )

  const handleEditUser = useCallback(
    (formData: any) => {
      setIsLoading(true)
      startTransition(() => {
        const updatedUsers = users.map((user) => (user.id === selectedUser?.id ? { ...user, ...formData } : user))
        setUsers(updatedUsers)

        // Save to localStorage
        localStorage.setItem("allUsers", JSON.stringify(updatedUsers))

        setShowEditDialog(false)
        setSelectedUser(null)
        setIsLoading(false)
        alert("User updated successfully!")
      })
    },
    [selectedUser, users],
  )

  const handleDeleteUser = useCallback((userId: number) => {
    setIsLoading(true)
    startTransition(() => {
      setUsers((prev) => prev.filter((user) => user.id !== userId))
      setIsLoading(false)
    })
  }, [])

  const handleStatusChange = useCallback((userId: number, newStatus: string) => {
    setIsLoading(true)
    startTransition(() => {
      setUsers((prev) => prev.map((user) => (user.id === userId ? { ...user, status: newStatus } : user)))
      setIsLoading(false)
    })
  }, [])

  const handleViewUser = useCallback((user: any) => {
    setSelectedUser(user)
    setShowViewDialog(true)
  }, [])

  const handleSearchChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value)
  }, [])

  const handleTabChange = useCallback((value: string) => {
    setSelectedTab(value)
  }, [])

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("allUsers", JSON.stringify(users))
    }
  }, [users])

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <AdminSidebar open={sidebarOpen} onOpenChange={setSidebarOpen} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col lg:ml-64">
        {/* Top Bar */}
        <AdminTopBar userInfo={userInfo} onMenuClick={() => setSidebarOpen(!sidebarOpen)} />

        {/* Page Content */}
        <main className="flex-1 p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Header */}
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">User Management</h1>
                <p className="text-gray-600">Manage caregivers, clients, and administrators</p>
              </div>
              <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-blue-500 hover:bg-blue-600" disabled={isLoading || isPending}>
                    {isLoading || isPending ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Plus className="h-4 w-4 mr-2" />
                    )}
                    Add New User
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add New User</DialogTitle>
                    <DialogDescription>Create a new user account in the system</DialogDescription>
                  </DialogHeader>
                  <UserForm onSubmit={handleAddUser} onCancel={() => setShowAddDialog(false)} isLoading={isLoading} />
                </DialogContent>
              </Dialog>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {Object.entries(stats).map(([key, value]) => (
                <Card key={key}>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-gray-900">{value}</div>
                    <div className="text-sm text-gray-600 capitalize">{key.replace(/([A-Z])/g, " $1")}</div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Filters and Search */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Search users by name, email, or phone..."
                        value={searchTerm}
                        onChange={handleSearchChange}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Select value={selectedTab} onValueChange={handleTabChange}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Users</SelectItem>
                        <SelectItem value="admin">Administrators</SelectItem>
                        <SelectItem value="caregiver">Caregivers</SelectItem>
                        <SelectItem value="client">Clients</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Users Table */}
            <Card>
              <CardHeader>
                <CardTitle>Users ({filteredUsers.length})</CardTitle>
                <CardDescription>Manage all system users and their permissions</CardDescription>
              </CardHeader>
              <CardContent>
                {isPending && (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                    <span className="ml-2 text-gray-600">Loading users...</span>
                  </div>
                )}
                <div className="space-y-4">
                  {filteredUsers.map((user) => (
                    <UserCard
                      key={user.id}
                      user={user}
                      getRoleIcon={getRoleIcon}
                      getRoleBadgeColor={getRoleBadgeColor}
                      getStatusBadgeColor={getStatusBadgeColor}
                      onView={handleViewUser}
                      onEdit={(user) => {
                        setSelectedUser(user)
                        setShowEditDialog(true)
                      }}
                      onStatusChange={handleStatusChange}
                      onDelete={handleDeleteUser}
                      isLoading={isLoading}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>

      {/* View User Dialog */}
      <Dialog open={showViewDialog} onOpenChange={setShowViewDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>User Details</DialogTitle>
            <DialogDescription>View complete user information</DialogDescription>
          </DialogHeader>
          {selectedUser && (
            <UserDetails
              user={selectedUser}
              getRoleIcon={getRoleIcon}
              getRoleBadgeColor={getRoleBadgeColor}
              getStatusBadgeColor={getStatusBadgeColor}
            />
          )}
          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button variant="outline" onClick={() => setShowViewDialog(false)}>
              Close
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setShowViewDialog(false)
                setShowEditDialog(true)
              }}
            >
              <Edit className="h-4 w-4 mr-2" />
              Edit User
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
            <DialogDescription>Update user information and settings</DialogDescription>
          </DialogHeader>
          {selectedUser && (
            <UserForm
              user={selectedUser}
              onSubmit={handleEditUser}
              onCancel={() => {
                setShowEditDialog(false)
                setSelectedUser(null)
              }}
              isLoading={isLoading}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Optimized User Card Component
const UserCard = React.memo(
  ({
    user,
    getRoleIcon,
    getRoleBadgeColor,
    getStatusBadgeColor,
    onView,
    onEdit,
    onStatusChange,
    onDelete,
    isLoading,
  }: {
    user: any
    getRoleIcon: (role: string) => ReactNode
    getRoleBadgeColor: (role: string) => string
    getStatusBadgeColor: (status: string) => string
    onView: (user: any) => void
    onEdit: (user: any) => void
    onStatusChange: (id: number, status: string) => void
    onDelete: (id: number) => void
    isLoading: boolean
  }) => {
    return (
      <div className="p-4 border rounded-lg hover:shadow-md transition-shadow">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={user.profilePicture || "/placeholder.svg"} alt={user.name} />
              <AvatarFallback className="bg-gray-200 text-gray-700 text-lg">
                {user.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h3 className="font-semibold text-lg">{user.name}</h3>
                {getRoleIcon(user.role)}
                <Badge className={getRoleBadgeColor(user.role)}>{user.role}</Badge>
                <Badge className={getStatusBadgeColor(user.status)}>{user.status}</Badge>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm text-gray-600">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    <span>{user.email}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4" />
                    <span>{user.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4" />
                    <span>{user.address}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    <span>Joined: {user.joinDate}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Eye className="h-4 w-4" />
                    <span>Last login: {user.lastLogin}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  {user.role === "caregiver" && (
                    <>
                      <div>Clients: {user.assignedClients}</div>
                      <div>Hours: {user.hoursWorked}</div>
                      <div className="flex flex-wrap gap-1">
                        {user.specialties?.map((specialty, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {specialty}
                          </Badge>
                        ))}
                      </div>
                    </>
                  )}
                  {user.role === "client" && (
                    <>
                      <div>Caregiver: {user.caregiver}</div>
                      <div>Emergency: {user.emergencyContact}</div>
                      <div>Services: {user.servicesPlan}</div>
                    </>
                  )}
                  {user.role === "admin" && (
                    <div className="flex flex-wrap gap-1">
                      {user.permissions?.map((permission, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {permission}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <Button variant="outline" size="sm" onClick={() => onView(user)} disabled={isLoading}>
              <Eye className="h-4 w-4 mr-2" />
              View
            </Button>
            <Button variant="outline" size="sm" onClick={() => onEdit(user)} disabled={isLoading}>
              {isLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Edit className="h-4 w-4 mr-2" />}
              Edit
            </Button>

            {user.status === "active" ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onStatusChange(user.id, "inactive")}
                className="text-yellow-600 hover:text-yellow-700"
                disabled={isLoading}
              >
                <UserX className="h-4 w-4 mr-2" />
                Deactivate
              </Button>
            ) : (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onStatusChange(user.id, "active")}
                className="text-green-600 hover:text-green-700"
                disabled={isLoading}
              >
                <UserCheck className="h-4 w-4 mr-2" />
                Activate
              </Button>
            )}

            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700" disabled={isLoading}>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete User</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to delete {user.name}? This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={() => onDelete(user.id)} className="bg-red-600 hover:bg-red-700">
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>
    )
  },
)

// Optimized User Details Component
const UserDetails = React.memo(
  ({
    user,
    getRoleIcon,
    getRoleBadgeColor,
    getStatusBadgeColor,
  }: {
    user: any
    getRoleIcon: (role: string) => ReactNode
    getRoleBadgeColor: (role: string) => string
    getStatusBadgeColor: (status: string) => string
  }) => {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Avatar className="h-20 w-20">
            <AvatarImage src={user.profilePicture || "/placeholder.svg"} alt={user.name} />
            <AvatarFallback className="bg-gray-200 text-gray-700 text-xl">
              {user.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </AvatarFallback>
          </Avatar>
          <div>
            <h2 className="text-2xl font-bold">{user.name}</h2>
            <div className="flex items-center gap-2 mt-1">
              {getRoleIcon(user.role)}
              <Badge className={getRoleBadgeColor(user.role)}>{user.role}</Badge>
              <Badge className={getStatusBadgeColor(user.status)}>{user.status}</Badge>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-sm text-gray-500">Email</Label>
            <p>{user.email}</p>
          </div>
          <div className="space-y-2">
            <Label className="text-sm text-gray-500">Phone</Label>
            <p>{user.phone}</p>
          </div>
          <div className="space-y-2">
            <Label className="text-sm text-gray-500">Address</Label>
            <p>{user.address}</p>
          </div>
          <div className="space-y-2">
            <Label className="text-sm text-gray-500">Join Date</Label>
            <p>{user.joinDate}</p>
          </div>
        </div>

        {user.role === "caregiver" && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm text-gray-500">Assigned Clients</Label>
                <p>{user.assignedClients}</p>
              </div>
              <div className="space-y-2">
                <Label className="text-sm text-gray-500">Hours Worked</Label>
                <p>{user.hoursWorked}</p>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm text-gray-500">Specialties</Label>
              <div className="flex flex-wrap gap-1">
                {user.specialties?.map((specialty, index) => (
                  <Badge key={index} variant="outline">
                    {specialty}
                  </Badge>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm text-gray-500">Certifications</Label>
              <div className="flex flex-wrap gap-1">
                {user.certifications?.map((cert, index) => (
                  <Badge key={index} variant="outline">
                    {cert}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        )}

        {user.role === "client" && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-sm text-gray-500">Assigned Caregiver</Label>
              <p>{user.caregiver}</p>
            </div>
            <div className="space-y-2">
              <Label className="text-sm text-gray-500">Emergency Contact</Label>
              <p>{user.emergencyContact}</p>
            </div>
            <div className="space-y-2">
              <Label className="text-sm text-gray-500">Services Plan</Label>
              <p>{user.servicesPlan}</p>
            </div>
          </div>
        )}

        {user.role === "admin" && (
          <div className="space-y-2">
            <Label className="text-sm text-gray-500">Permissions</Label>
            <div className="flex flex-wrap gap-1">
              {user.permissions?.map((permission, index) => (
                <Badge key={index} variant="outline">
                  {permission}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </div>
    )
  },
)

// Updated User Form Component with loading states
function UserForm({
  user = null,
  onSubmit,
  onCancel,
  isLoading = false,
}: { user?: any; onSubmit: (data: any) => void; onCancel: () => void; isLoading?: boolean }) {
  const [formData, setFormData] = useState({
    name: user?.name || "",
    username: user?.username || "",
    email: user?.email || "",
    password: user ? "" : "", // Only for new users
    confirmPassword: user ? "" : "", // Only for new users
    phone: user?.phone || "",
    role: user?.role || "",
    address: user?.address || "",
    specialties: user?.specialties?.join(", ") || "",
    certifications: user?.certifications?.join(", ") || "",
    emergencyContact: user?.emergencyContact || "",
    servicesPlan: user?.servicesPlan || "",
    profilePicture: user?.profilePicture || "",
  })

  const handleSubmit = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault()

      // Validation for new users
      if (!user) {
        if (formData.password !== formData.confirmPassword) {
          alert("Passwords do not match!")
          return
        }
        if (formData.password.length < 8) {
          alert("Password must be at least 8 characters long!")
          return
        }
      }

      const processedData = {
        ...formData,
        specialties: formData.specialties ? formData.specialties.split(", ") : [],
        certifications: formData.certifications ? formData.certifications.split(", ") : [],
      }
      onSubmit(processedData)
    },
    [formData, onSubmit, user],
  )

  const handleProfilePictureChange = useCallback((imageUrl: string) => {
    setFormData((prev) => ({ ...prev, profilePicture: imageUrl }))
  }, [])

  const handleInputChange = useCallback((field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }, [])

  return (
    <form onSubmit={handleSubmit} className="space-y-4 overflow-y-auto pr-1">
      {/* Profile Picture Upload */}
      <div className="flex justify-center">
        <ProfilePictureUpload
          currentImage={formData.profilePicture}
          userName={formData.name || "New User"}
          onImageChange={handleProfilePictureChange}
          size="lg"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Full Name</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => handleInputChange("name", e.target.value)}
            required
            disabled={isLoading}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => handleInputChange("email", e.target.value)}
            required
            disabled={isLoading}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="username">Username</Label>
        <Input
          id="username"
          value={formData.username}
          onChange={(e) => handleInputChange("username", e.target.value)}
          required
          disabled={isLoading}
          placeholder="Enter username for login"
        />
      </div>

      {!user && (
        <>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={formData.password}
              onChange={(e) => handleInputChange("password", e.target.value)}
              required
              disabled={isLoading}
              placeholder="Enter password (min 8 characters)"
              minLength={8}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="confirmPassword">Confirm Password</Label>
            <Input
              id="confirmPassword"
              type="password"
              value={formData.confirmPassword}
              onChange={(e) => handleInputChange("confirmPassword", e.target.value)}
              required
              disabled={isLoading}
              placeholder="Confirm password"
            />
          </div>
        </>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="phone">Phone</Label>
          <Input
            id="phone"
            value={formData.phone}
            onChange={(e) => handleInputChange("phone", e.target.value)}
            required
            disabled={isLoading}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="role">Role</Label>
          <Select
            value={formData.role}
            onValueChange={(value) => handleInputChange("role", value)}
            disabled={isLoading}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="admin">Administrator</SelectItem>
              <SelectItem value="caregiver">Caregiver</SelectItem>
              <SelectItem value="client">Client/Family</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="address">Address</Label>
        <Input
          id="address"
          value={formData.address}
          onChange={(e) => handleInputChange("address", e.target.value)}
          disabled={isLoading}
        />
      </div>

      {formData.role === "caregiver" && (
        <>
          <div className="space-y-2">
            <Label htmlFor="specialties">Specialties (comma-separated)</Label>
            <Input
              id="specialties"
              value={formData.specialties}
              onChange={(e) => handleInputChange("specialties", e.target.value)}
              placeholder="e.g., Elderly Care, Dementia Support"
              disabled={isLoading}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="certifications">Certifications (comma-separated)</Label>
            <Input
              id="certifications"
              value={formData.certifications}
              onChange={(e) => handleInputChange("certifications", e.target.value)}
              placeholder="e.g., CNA, CPR, First Aid"
              disabled={isLoading}
            />
          </div>
        </>
      )}

      {formData.role === "client" && (
        <>
          <div className="space-y-2">
            <Label htmlFor="emergencyContact">Emergency Contact</Label>
            <Input
              id="emergencyContact"
              value={formData.emergencyContact}
              onChange={(e) => handleInputChange("emergencyContact", e.target.value)}
              placeholder="Name - Phone Number"
              disabled={isLoading}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="servicesPlan">Services Plan</Label>
            <Textarea
              id="servicesPlan"
              value={formData.servicesPlan}
              onChange={(e) => handleInputChange("servicesPlan", e.target.value)}
              placeholder="Describe the services needed"
              rows={3}
              disabled={isLoading}
            />
          </div>
        </>
      )}

      {/* Sticky action buttons */}
      <div className="sticky bottom-0 bg-white pt-4 border-t flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isLoading}>
          Cancel
        </Button>
        <Button type="submit" className="bg-blue-500 hover:bg-blue-600" disabled={isLoading}>
          {isLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
          {user ? "Update User" : "Create User"}
        </Button>
      </div>
    </form>
  )
}
