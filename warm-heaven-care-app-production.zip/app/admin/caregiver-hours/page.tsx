"use client"

import { useState } from "react"
import { AdminSidebar } from "@/components/admin-sidebar"
import { AdminTopBar } from "@/components/admin-top-bar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Clock,
  Download,
  Users,
  Filter,
  RefreshCw,
  BarChart3,
  AlertTriangle,
  CheckCircle,
  Eye,
  Edit,
  Search,
  FileText,
  Save,
} from "lucide-react"
import { Textarea } from "@/components/ui/textarea"

interface CaregiverHours {
  id: string
  name: string
  email: string
  currentStatus: "clocked-in" | "clocked-out" | "scheduled" | "off-duty"
  currentShift?: "day" | "night"
  clockInTime?: string
  clockOutTime?: string
  todayHours: number
  weeklyHours: number
  monthlyHours: number
  overtimeHours: number
  lastActivity: string
  weeklySchedule: {
    monday: number
    tuesday: number
    wednesday: number
    thursday: number
    friday: number
    saturday: number
    sunday: number
  }
  payrollStatus: "approved" | "pending" | "review"
}

interface TimeEntry {
  id: string
  caregiverId: string
  caregiverName: string
  date: string
  clockIn: string
  clockOut: string | null
  totalHours: number
  shiftType: "day" | "night"
  status: "active" | "completed" | "pending-approval"
  notes?: string
}

interface TimeCorrection {
  id: string
  caregiverId: string
  caregiverName: string
  originalEntry: TimeEntry
  correctedEntry: TimeEntry
  reason: string
  requestedBy: "caregiver" | "admin"
  requestedAt: string
  status: "pending" | "approved" | "rejected"
  reviewedBy?: string
  reviewedAt?: string
  adminNotes?: string
}

interface EditTimeEntry {
  id: string
  caregiverId: string
  caregiverName: string
  date: string
  clockIn: string
  clockOut: string | null
  totalHours: number
  shiftType: "day" | "night"
  status: "active" | "completed" | "pending-approval"
  notes?: string
  isEditing?: boolean
}

export default function CaregiverHours() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [userInfo, setUserInfo] = useState({ name: "Administrator", email: "admin@warmheaven.com" })
  const [selectedPeriod, setSelectedPeriod] = useState("week")
  const [selectedCaregiver, setSelectedCaregiver] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState("overview")
  const [editingEntry, setEditingEntry] = useState<EditTimeEntry | null>(null)
  const [showEditModal, setShowEditModal] = useState(false)
  const [showCorrectionModal, setShowCorrectionModal] = useState(false)
  const [correctionReason, setCorrectionReason] = useState("")
  const [adminNotes, setAdminNotes] = useState("")

  // Mock data for caregiver hours
  const caregivers: CaregiverHours[] = [
    {
      id: "1",
      name: "Sarah Wilson",
      email: "sarah.wilson@warmheaven.com",
      currentStatus: "clocked-in",
      currentShift: "day",
      clockInTime: "8:00 AM",
      todayHours: 6.5,
      weeklyHours: 38.5,
      monthlyHours: 156.2,
      overtimeHours: 2.5,
      lastActivity: "2 minutes ago",
      weeklySchedule: {
        monday: 8,
        tuesday: 8,
        wednesday: 8,
        thursday: 8,
        friday: 6.5,
        saturday: 0,
        sunday: 0,
      },
      payrollStatus: "approved",
    },
    {
      id: "2",
      name: "Mike Davis",
      email: "mike.davis@warmheaven.com",
      currentStatus: "clocked-out",
      currentShift: "day",
      clockOutTime: "4:00 PM",
      todayHours: 8.0,
      weeklyHours: 40.0,
      monthlyHours: 160.0,
      overtimeHours: 0,
      lastActivity: "1 hour ago",
      weeklySchedule: {
        monday: 8,
        tuesday: 8,
        wednesday: 8,
        thursday: 8,
        friday: 8,
        saturday: 0,
        sunday: 0,
      },
      payrollStatus: "approved",
    },
    {
      id: "3",
      name: "Lisa Chen",
      email: "lisa.chen@warmheaven.com",
      currentStatus: "clocked-in",
      currentShift: "night",
      clockInTime: "8:00 PM",
      todayHours: 4.2,
      weeklyHours: 36.8,
      monthlyHours: 148.5,
      overtimeHours: 0,
      lastActivity: "5 minutes ago",
      weeklySchedule: {
        monday: 0,
        tuesday: 12,
        wednesday: 12,
        thursday: 12,
        friday: 0.8,
        saturday: 0,
        sunday: 0,
      },
      payrollStatus: "pending",
    },
    {
      id: "4",
      name: "John Smith",
      email: "john.smith@warmheaven.com",
      currentStatus: "scheduled",
      currentShift: "night",
      clockInTime: "11:00 PM",
      todayHours: 0,
      weeklyHours: 35.5,
      monthlyHours: 142.0,
      overtimeHours: 0,
      lastActivity: "Yesterday",
      weeklySchedule: {
        monday: 0,
        tuesday: 0,
        wednesday: 12,
        thursday: 12,
        friday: 11.5,
        saturday: 0,
        sunday: 0,
      },
      payrollStatus: "review",
    },
    {
      id: "5",
      name: "Emily Johnson",
      email: "emily.johnson@warmheaven.com",
      currentStatus: "off-duty",
      todayHours: 0,
      weeklyHours: 32.0,
      monthlyHours: 128.0,
      overtimeHours: 0,
      lastActivity: "2 days ago",
      weeklySchedule: {
        monday: 8,
        tuesday: 8,
        wednesday: 8,
        thursday: 8,
        friday: 0,
        saturday: 0,
        sunday: 0,
      },
      payrollStatus: "approved",
    },
  ]

  const timeEntries: TimeEntry[] = [
    {
      id: "1",
      caregiverId: "1",
      caregiverName: "Sarah Wilson",
      date: "2024-01-22",
      clockIn: "8:00 AM",
      clockOut: null,
      totalHours: 6.5,
      shiftType: "day",
      status: "active",
    },
    {
      id: "2",
      caregiverId: "2",
      caregiverName: "Mike Davis",
      date: "2024-01-22",
      clockIn: "8:00 AM",
      clockOut: "4:00 PM",
      totalHours: 8.0,
      shiftType: "day",
      status: "completed",
    },
    {
      id: "3",
      caregiverId: "3",
      caregiverName: "Lisa Chen",
      date: "2024-01-22",
      clockIn: "8:00 PM",
      clockOut: null,
      totalHours: 4.2,
      shiftType: "night",
      status: "active",
    },
    {
      id: "4",
      caregiverId: "1",
      caregiverName: "Sarah Wilson",
      date: "2024-01-21",
      clockIn: "8:00 AM",
      clockOut: "4:00 PM",
      totalHours: 8.0,
      shiftType: "day",
      status: "completed",
    },
    {
      id: "5",
      caregiverId: "2",
      caregiverName: "Mike Davis",
      date: "2024-01-21",
      clockIn: "8:00 AM",
      clockOut: "4:00 PM",
      totalHours: 8.0,
      shiftType: "day",
      status: "completed",
    },
  ]

  const timeCorrections: TimeCorrection[] = [
    {
      id: "1",
      caregiverId: "1",
      caregiverName: "Sarah Wilson",
      originalEntry: {
        id: "1",
        caregiverId: "1",
        caregiverName: "Sarah Wilson",
        date: "2024-01-21",
        clockIn: "8:00 AM",
        clockOut: "4:00 PM",
        totalHours: 8.0,
        shiftType: "day",
        status: "completed",
      },
      correctedEntry: {
        id: "1",
        caregiverId: "1",
        caregiverName: "Sarah Wilson",
        date: "2024-01-21",
        clockIn: "8:15 AM",
        clockOut: "4:15 PM",
        totalHours: 8.0,
        shiftType: "day",
        status: "completed",
      },
      reason: "Forgot to clock in on time due to traffic",
      requestedBy: "caregiver",
      requestedAt: "2024-01-22 09:30 AM",
      status: "pending",
    },
    {
      id: "2",
      caregiverId: "2",
      caregiverName: "Mike Davis",
      originalEntry: {
        id: "2",
        caregiverId: "2",
        caregiverName: "Mike Davis",
        date: "2024-01-20",
        clockIn: "8:00 AM",
        clockOut: "3:00 PM",
        totalHours: 7.0,
        shiftType: "day",
        status: "completed",
      },
      correctedEntry: {
        id: "2",
        caregiverId: "2",
        caregiverName: "Mike Davis",
        date: "2024-01-20",
        clockIn: "8:00 AM",
        clockOut: "4:00 PM",
        totalHours: 8.0,
        shiftType: "day",
        status: "completed",
      },
      reason: "System error - forgot to clock out properly",
      requestedBy: "caregiver",
      requestedAt: "2024-01-21 08:15 AM",
      status: "approved",
      reviewedBy: "Administrator",
      reviewedAt: "2024-01-21 10:30 AM",
      adminNotes: "Verified with client visit logs. Correction approved.",
    },
  ]

  const filteredCaregivers = caregivers.filter(
    (caregiver) =>
      caregiver.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      caregiver.email.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const totalHoursThisWeek = caregivers.reduce((sum, caregiver) => sum + caregiver.weeklyHours, 0)
  const totalOvertimeHours = caregivers.reduce((sum, caregiver) => sum + caregiver.overtimeHours, 0)
  const activeCaregivers = caregivers.filter((c) => c.currentStatus === "clocked-in").length
  const avgHoursPerCaregiver = totalHoursThisWeek / caregivers.length

  const formatHours = (hours: number) => {
    const h = Math.floor(hours)
    const m = Math.floor((hours - h) * 60)
    return `${h}h ${m}m`
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "clocked-in":
        return "bg-green-100 text-green-800"
      case "clocked-out":
        return "bg-gray-100 text-gray-800"
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      case "off-duty":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPayrollStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "review":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const exportHours = (format: string) => {
    // Simulate export functionality
    const fileName = `caregiver_hours_${selectedPeriod}_${new Date().toISOString().split("T")[0]}.${format.toLowerCase()}`
    alert(`Exporting ${fileName}...`)
  }

  const openEditModal = (entry: TimeEntry) => {
    setEditingEntry({
      ...entry,
      isEditing: true,
    })
    setShowEditModal(true)
  }

  const closeEditModal = () => {
    setEditingEntry(null)
    setShowEditModal(false)
    setCorrectionReason("")
    setAdminNotes("")
  }

  const saveTimeEdit = () => {
    if (!editingEntry) return

    // Calculate new total hours
    const clockInTime = new Date(`${editingEntry.date} ${editingEntry.clockIn}`)
    const clockOutTime = editingEntry.clockOut ? new Date(`${editingEntry.date} ${editingEntry.clockOut}`) : new Date()
    const totalHours = (clockOutTime.getTime() - clockInTime.getTime()) / (1000 * 60 * 60)

    // Update the entry (in real app, this would be an API call)
    console.log("Saving time edit:", {
      ...editingEntry,
      totalHours: Math.round(totalHours * 100) / 100,
      reason: correctionReason,
      adminNotes: adminNotes,
    })

    alert("Time entry updated successfully!")
    closeEditModal()
  }

  const approveCorrection = (correctionId: string) => {
    const correction = timeCorrections.find((c) => c.id === correctionId)
    if (correction) {
      correction.status = "approved"
      correction.reviewedBy = "Administrator"
      correction.reviewedAt = new Date().toLocaleString()
      alert("Time correction approved!")
    }
  }

  const rejectCorrection = (correctionId: string, reason: string) => {
    const correction = timeCorrections.find((c) => c.id === correctionId)
    if (correction) {
      correction.status = "rejected"
      correction.reviewedBy = "Administrator"
      correction.reviewedAt = new Date().toLocaleString()
      correction.adminNotes = reason
      alert("Time correction rejected!")
    }
  }

  const bulkApproveHours = (caregiverId: string, period: string) => {
    alert(`Bulk approving hours for caregiver ${caregiverId} for ${period}`)
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <AdminSidebar open={sidebarOpen} onOpenChange={setSidebarOpen} />

      <div className="flex-1 flex flex-col lg:ml-64">
        <AdminTopBar userInfo={userInfo} onMenuClick={() => setSidebarOpen(!sidebarOpen)} />

        <main className="flex-1 p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Header */}
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Caregiver Hours Management</h1>
              <p className="text-gray-600">Monitor and manage caregiver work hours, overtime, and payroll.</p>
            </div>

            {/* Summary Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Total Hours This Week</p>
                      <p className="text-2xl font-bold">{formatHours(totalHoursThisWeek)}</p>
                      <p className="text-sm text-green-600">+3% from last week</p>
                    </div>
                    <Clock className="h-8 w-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Active Caregivers</p>
                      <p className="text-2xl font-bold">{activeCaregivers}</p>
                      <p className="text-sm text-blue-600">Currently clocked in</p>
                    </div>
                    <Users className="h-8 w-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Overtime Hours</p>
                      <p className="text-2xl font-bold">{formatHours(totalOvertimeHours)}</p>
                      <p className="text-sm text-orange-600">This week</p>
                    </div>
                    <AlertTriangle className="h-8 w-8 text-orange-500" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Avg Hours/Caregiver</p>
                      <p className="text-2xl font-bold">{formatHours(avgHoursPerCaregiver)}</p>
                      <p className="text-sm text-purple-600">This week</p>
                    </div>
                    <BarChart3 className="h-8 w-8 text-purple-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="detailed">Detailed Hours</TabsTrigger>
                <TabsTrigger value="time-entries">Time Entries</TabsTrigger>
                <TabsTrigger value="corrections">Corrections</TabsTrigger>
                <TabsTrigger value="payroll">Payroll</TabsTrigger>
              </TabsList>

              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-6">
                {/* Filters */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Filter className="h-5 w-5" />
                      Filters & Search
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="space-y-2">
                        <Label>Search Caregiver</Label>
                        <div className="relative">
                          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                          <Input
                            placeholder="Search by name or email..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10"
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Time Period</Label>
                        <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="today">Today</SelectItem>
                            <SelectItem value="week">This Week</SelectItem>
                            <SelectItem value="month">This Month</SelectItem>
                            <SelectItem value="quarter">This Quarter</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Caregiver</Label>
                        <Select value={selectedCaregiver} onValueChange={setSelectedCaregiver}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Caregivers</SelectItem>
                            {caregivers.map((caregiver) => (
                              <SelectItem key={caregiver.id} value={caregiver.id}>
                                {caregiver.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Export</Label>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" onClick={() => exportHours("Excel")}>
                            <Download className="h-4 w-4 mr-1" />
                            Excel
                          </Button>
                          <Button variant="outline" size="sm" onClick={() => exportHours("PDF")}>
                            <FileText className="h-4 w-4 mr-1" />
                            PDF
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Caregiver Hours Grid */}
                <div className="grid gap-6">
                  {filteredCaregivers.map((caregiver) => (
                    <Card key={caregiver.id}>
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-4">
                            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-orange-500 rounded-full flex items-center justify-center text-white font-semibold text-lg">
                              {caregiver.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <h3 className="text-xl font-semibold">{caregiver.name}</h3>
                                <Badge className={getStatusColor(caregiver.currentStatus)}>
                                  {caregiver.currentStatus === "clocked-in" && "🟢 Clocked In"}
                                  {caregiver.currentStatus === "clocked-out" && "⚫ Clocked Out"}
                                  {caregiver.currentStatus === "scheduled" && "⏰ Scheduled"}
                                  {caregiver.currentStatus === "off-duty" && "🔴 Off Duty"}
                                </Badge>
                                {caregiver.overtimeHours > 0 && (
                                  <Badge variant="destructive">OT: {formatHours(caregiver.overtimeHours)}</Badge>
                                )}
                              </div>
                              <p className="text-gray-600 mb-4">{caregiver.email}</p>

                              <div className="grid md:grid-cols-4 gap-4 text-sm">
                                <div className="space-y-1">
                                  <p className="text-gray-600">Today</p>
                                  <p className="font-semibold text-lg">{formatHours(caregiver.todayHours)}</p>
                                  {caregiver.currentStatus === "clocked-in" && caregiver.clockInTime && (
                                    <p className="text-xs text-green-600">Since {caregiver.clockInTime}</p>
                                  )}
                                  {caregiver.currentStatus === "clocked-out" && caregiver.clockOutTime && (
                                    <p className="text-xs text-gray-500">Until {caregiver.clockOutTime}</p>
                                  )}
                                </div>
                                <div className="space-y-1">
                                  <p className="text-gray-600">This Week</p>
                                  <p className="font-semibold text-lg">{formatHours(caregiver.weeklyHours)}</p>
                                  <p className="text-xs text-gray-500">of 40h scheduled</p>
                                </div>
                                <div className="space-y-1">
                                  <p className="text-gray-600">This Month</p>
                                  <p className="font-semibold text-lg">{formatHours(caregiver.monthlyHours)}</p>
                                  <p className="text-xs text-gray-500">Last activity: {caregiver.lastActivity}</p>
                                </div>
                                <div className="space-y-1">
                                  <p className="text-gray-600">Payroll Status</p>
                                  <Badge className={getPayrollStatusColor(caregiver.payrollStatus)}>
                                    {caregiver.payrollStatus === "approved" && "✅ Approved"}
                                    {caregiver.payrollStatus === "pending" && "⏳ Pending"}
                                    {caregiver.payrollStatus === "review" && "⚠️ Review"}
                                  </Badge>
                                </div>
                              </div>

                              {/* Weekly Schedule */}
                              <div className="mt-4">
                                <p className="text-sm font-medium text-gray-700 mb-2">Weekly Schedule</p>
                                <div className="grid grid-cols-7 gap-2">
                                  {Object.entries(caregiver.weeklySchedule).map(([day, hours]) => (
                                    <div
                                      key={day}
                                      className={`p-2 rounded text-center text-xs ${
                                        hours > 0 ? "bg-blue-100 text-blue-800" : "bg-gray-100 text-gray-500"
                                      }`}
                                    >
                                      <div className="font-medium">{day.slice(0, 3).toUpperCase()}</div>
                                      <div>{hours > 0 ? formatHours(hours) : "Off"}</div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() =>
                                openEditModal({
                                  id: caregiver.id + "_edit",
                                  caregiverId: caregiver.id,
                                  caregiverName: caregiver.name,
                                  date: new Date().toISOString().split("T")[0],
                                  clockIn: "08:00",
                                  clockOut: "16:00",
                                  totalHours: 8,
                                  shiftType: "day",
                                  status: "completed",
                                })
                              }
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="default"
                              onClick={() => bulkApproveHours(caregiver.id, selectedPeriod)}
                            >
                              Approve
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* Detailed Hours Tab */}
              <TabsContent value="detailed" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Detailed Hour Breakdown</CardTitle>
                    <CardDescription>Comprehensive view of all caregiver hours</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left p-3">Caregiver</th>
                            <th className="text-left p-3">Status</th>
                            <th className="text-left p-3">Today</th>
                            <th className="text-left p-3">Week</th>
                            <th className="text-left p-3">Month</th>
                            <th className="text-left p-3">Overtime</th>
                            <th className="text-left p-3">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredCaregivers.map((caregiver) => (
                            <tr key={caregiver.id} className="border-b hover:bg-gray-50">
                              <td className="p-3">
                                <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-orange-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                                    {caregiver.name
                                      .split(" ")
                                      .map((n) => n[0])
                                      .join("")}
                                  </div>
                                  <div>
                                    <p className="font-medium">{caregiver.name}</p>
                                    <p className="text-sm text-gray-600">{caregiver.email}</p>
                                  </div>
                                </div>
                              </td>
                              <td className="p-3">
                                <Badge className={getStatusColor(caregiver.currentStatus)}>
                                  {caregiver.currentStatus.replace("-", " ")}
                                </Badge>
                              </td>
                              <td className="p-3 font-semibold">{formatHours(caregiver.todayHours)}</td>
                              <td className="p-3 font-semibold">{formatHours(caregiver.weeklyHours)}</td>
                              <td className="p-3 font-semibold">{formatHours(caregiver.monthlyHours)}</td>
                              <td className="p-3">
                                {caregiver.overtimeHours > 0 ? (
                                  <span className="font-semibold text-orange-600">
                                    {formatHours(caregiver.overtimeHours)}
                                  </span>
                                ) : (
                                  <span className="text-gray-400">None</span>
                                )}
                              </td>
                              <td className="p-3">
                                <div className="flex gap-1">
                                  <Button size="sm" variant="outline">
                                    <Eye className="h-3 w-3" />
                                  </Button>
                                  <Button size="sm" variant="outline">
                                    <Edit className="h-3 w-3" />
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Time Entries Tab */}
              <TabsContent value="time-entries" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Time Entries</CardTitle>
                    <CardDescription>Clock in/out records and time tracking</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {timeEntries.map((entry) => (
                        <div key={entry.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-orange-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                              {entry.caregiverName
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </div>
                            <div>
                              <h4 className="font-medium">{entry.caregiverName}</h4>
                              <p className="text-sm text-gray-600">{entry.date}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-6">
                            <div className="text-center">
                              <p className="text-xs text-gray-500">Clock In</p>
                              <p className="font-medium">{entry.clockIn}</p>
                            </div>
                            <div className="text-center">
                              <p className="text-xs text-gray-500">Clock Out</p>
                              <p className="font-medium">{entry.clockOut || "Active"}</p>
                            </div>
                            <div className="text-center">
                              <p className="text-xs text-gray-500">Total Hours</p>
                              <p className="font-medium">{formatHours(entry.totalHours)}</p>
                            </div>
                            <div className="text-center">
                              <p className="text-xs text-gray-500">Shift</p>
                              <Badge variant="outline">{entry.shiftType}</Badge>
                            </div>
                            <div className="text-center">
                              <p className="text-xs text-gray-500">Status</p>
                              <Badge
                                variant={
                                  entry.status === "active"
                                    ? "default"
                                    : entry.status === "completed"
                                      ? "secondary"
                                      : "outline"
                                }
                              >
                                {entry.status === "active" && <RefreshCw className="h-3 w-3 mr-1" />}
                                {entry.status === "completed" && <CheckCircle className="h-3 w-3 mr-1" />}
                                {entry.status}
                              </Badge>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" onClick={() => openEditModal(entry)}>
                              <Edit className="h-3 w-3" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Eye className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Corrections Tab */}
              <TabsContent value="corrections" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Time Corrections & Requests</CardTitle>
                    <CardDescription>Review and manage caregiver time correction requests</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {timeCorrections.map((correction) => (
                        <div key={correction.id} className="border rounded-lg p-4 space-y-4">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-4">
                              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-orange-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                                {correction.caregiverName
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </div>
                              <div>
                                <h4 className="font-medium">{correction.caregiverName}</h4>
                                <p className="text-sm text-gray-600">{correction.date}</p>
                                <p className="text-xs text-gray-500">
                                  Requested by {correction.requestedBy} on {correction.requestedAt}
                                </p>
                              </div>
                            </div>
                            <Badge
                              variant={
                                correction.status === "approved"
                                  ? "default"
                                  : correction.status === "rejected"
                                    ? "destructive"
                                    : "secondary"
                              }
                            >
                              {correction.status}
                            </Badge>
                          </div>

                          <div className="grid md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <h5 className="font-medium text-red-600">Original Entry</h5>
                              <div className="bg-red-50 p-3 rounded border">
                                <div className="grid grid-cols-2 gap-2 text-sm">
                                  <div>Clock In: {correction.originalEntry.clockIn}</div>
                                  <div>Clock Out: {correction.originalEntry.clockOut}</div>
                                  <div>Total: {formatHours(correction.originalEntry.totalHours)}</div>
                                  <div>Shift: {correction.originalEntry.shiftType}</div>
                                </div>
                              </div>
                            </div>
                            <div className="space-y-2">
                              <h5 className="font-medium text-green-600">Requested Correction</h5>
                              <div className="bg-green-50 p-3 rounded border">
                                <div className="grid grid-cols-2 gap-2 text-sm">
                                  <div>Clock In: {correction.correctedEntry.clockIn}</div>
                                  <div>Clock Out: {correction.correctedEntry.clockOut}</div>
                                  <div>Total: {formatHours(correction.correctedEntry.totalHours)}</div>
                                  <div>Shift: {correction.correctedEntry.shiftType}</div>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <h5 className="font-medium">Reason for Correction</h5>
                            <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded">{correction.reason}</p>
                          </div>

                          {correction.adminNotes && (
                            <div className="space-y-2">
                              <h5 className="font-medium">Admin Notes</h5>
                              <p className="text-sm text-gray-700 bg-blue-50 p-3 rounded">{correction.adminNotes}</p>
                            </div>
                          )}

                          {correction.status === "pending" && (
                            <div className="flex gap-2 pt-2">
                              <Button
                                size="sm"
                                onClick={() => approveCorrection(correction.id)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Approve
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => {
                                  const reason = prompt("Reason for rejection:")
                                  if (reason) rejectCorrection(correction.id, reason)
                                }}
                              >
                                <AlertTriangle className="h-4 w-4 mr-1" />
                                Reject
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => openEditModal(correction.originalEntry)}
                              >
                                <Edit className="h-4 w-4 mr-1" />
                                Edit Manually
                              </Button>
                            </div>
                          )}

                          {correction.status !== "pending" && (
                            <div className="text-sm text-gray-600 pt-2">
                              {correction.status === "approved" ? "✅" : "❌"} {correction.status} by{" "}
                              {correction.reviewedBy} on {correction.reviewedAt}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Payroll Tab */}
              <TabsContent value="payroll" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Payroll Management</CardTitle>
                    <CardDescription>Review and approve caregiver hours for payroll</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {caregivers.map((caregiver) => (
                        <div key={caregiver.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-orange-500 rounded-full flex items-center justify-center text-white font-semibold">
                              {caregiver.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </div>
                            <div>
                              <h4 className="font-medium">{caregiver.name}</h4>
                              <p className="text-sm text-gray-600">{caregiver.email}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-6">
                            <div className="text-center">
                              <p className="text-xs text-gray-500">Regular Hours</p>
                              <p className="font-medium">
                                {formatHours(caregiver.weeklyHours - caregiver.overtimeHours)}
                              </p>
                            </div>
                            <div className="text-center">
                              <p className="text-xs text-gray-500">Overtime Hours</p>
                              <p className="font-medium text-orange-600">{formatHours(caregiver.overtimeHours)}</p>
                            </div>
                            <div className="text-center">
                              <p className="text-xs text-gray-500">Total Hours</p>
                              <p className="font-semibold">{formatHours(caregiver.weeklyHours)}</p>
                            </div>
                            <div className="text-center">
                              <p className="text-xs text-gray-500">Status</p>
                              <Badge className={getPayrollStatusColor(caregiver.payrollStatus)}>
                                {caregiver.payrollStatus}
                              </Badge>
                            </div>
                            <div className="flex gap-2">
                              {caregiver.payrollStatus === "pending" && (
                                <Button size="sm" variant="default">
                                  Approve
                                </Button>
                              )}
                              {caregiver.payrollStatus === "review" && (
                                <Button size="sm" variant="destructive">
                                  Review
                                </Button>
                              )}
                              <Button size="sm" variant="outline">
                                <Eye className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>

      {/* Edit Time Entry Modal */}
      {showEditModal && editingEntry && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Edit Time Entry</h3>
              <Button variant="ghost" size="sm" onClick={closeEditModal}>
                ✕
              </Button>
            </div>

            <div className="space-y-4">
              <div>
                <Label>Caregiver</Label>
                <Input value={editingEntry.caregiverName} disabled />
              </div>

              <div>
                <Label>Date</Label>
                <Input
                  type="date"
                  value={editingEntry.date}
                  onChange={(e) => setEditingEntry({ ...editingEntry, date: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Clock In Time</Label>
                  <Input
                    type="time"
                    value={editingEntry.clockIn}
                    onChange={(e) => setEditingEntry({ ...editingEntry, clockIn: e.target.value })}
                  />
                </div>
                <div>
                  <Label>Clock Out Time</Label>
                  <Input
                    type="time"
                    value={editingEntry.clockOut || ""}
                    onChange={(e) => setEditingEntry({ ...editingEntry, clockOut: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label>Shift Type</Label>
                <Select
                  value={editingEntry.shiftType}
                  onValueChange={(value: "day" | "night") => setEditingEntry({ ...editingEntry, shiftType: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="day">Day Shift</SelectItem>
                    <SelectItem value="night">Night Shift</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Reason for Change</Label>
                <Textarea
                  placeholder="Explain why this time entry is being modified..."
                  value={correctionReason}
                  onChange={(e) => setCorrectionReason(e.target.value)}
                  rows={3}
                />
              </div>

              <div>
                <Label>Admin Notes (Optional)</Label>
                <Textarea
                  placeholder="Additional notes for this correction..."
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  rows={2}
                />
              </div>

              <div className="flex gap-2 pt-4">
                <Button onClick={saveTimeEdit} className="flex-1">
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </Button>
                <Button variant="outline" onClick={closeEditModal}>
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
