"use client"

import { useState, useEffect } from "react"
import { AdminSidebar } from "@/components/admin-sidebar"
import { AdminTopBar } from "@/components/admin-top-bar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Users, Calendar, MessageSquare, FileText, AlertCircle, TrendingUp, Clock, Heart, Shield } from "lucide-react"

export default function AdminDashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [userInfo, setUserInfo] = useState({ name: "", email: "" })
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
    const email = localStorage.getItem("userEmail") || ""
    const name = localStorage.getItem("userName") || ""
    setUserInfo({ name, email })

    // Check if user is authorized to access this page
    const userRole = localStorage.getItem("userRole")
    if (userRole !== "admin") {
      window.location.href = "/"
    }
  }, [])

  // Mock data for dashboard
  const stats = [
    {
      title: "Total Users",
      value: "247",
      change: "+12%",
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
    },
    {
      title: "Active Caregivers",
      value: "89",
      change: "+5%",
      icon: Heart,
      color: "text-orange-600",
      bgColor: "bg-orange-100",
    },
    {
      title: "Today's Appointments",
      value: "156",
      change: "+8%",
      icon: Calendar,
      color: "text-green-600",
      bgColor: "bg-green-100",
    },
    {
      title: "Pending Requests",
      value: "23",
      change: "-15%",
      icon: AlertCircle,
      color: "text-red-600",
      bgColor: "bg-red-100",
    },
    {
      title: "Total Hours This Week",
      value: "1,247",
      change: "+3%",
      icon: Clock,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
    },
  ]

  const recentActivities = [
    {
      id: 1,
      type: "user",
      message: "New caregiver Sarah Johnson registered",
      time: "5 minutes ago",
      status: "success",
    },
    {
      id: 2,
      type: "appointment",
      message: "Appointment scheduled for Miller family",
      time: "15 minutes ago",
      status: "info",
    },
    {
      id: 3,
      type: "request",
      message: "Service request submitted by Davis family",
      time: "1 hour ago",
      status: "warning",
    },
    {
      id: 4,
      type: "message",
      message: "New message from caregiver to admin",
      time: "2 hours ago",
      status: "info",
    },
  ]

  const upcomingAppointments = [
    {
      id: 1,
      client: "Margaret Johnson",
      caregiver: "Sarah Wilson",
      time: "9:00 AM",
      service: "Personal Care",
      status: "confirmed",
    },
    {
      id: 2,
      client: "Robert Miller",
      caregiver: "Mike Davis",
      time: "11:30 AM",
      service: "Physical Therapy",
      status: "confirmed",
    },
    {
      id: 3,
      client: "Eleanor Brown",
      caregiver: "Lisa Chen",
      time: "2:00 PM",
      service: "Companionship",
      status: "pending",
    },
  ]

  if (!isClient) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="bg-blue-500 p-4 rounded-full shadow-lg mx-auto mb-4 w-16 h-16 flex items-center justify-center">
            <Shield className="h-8 w-8 text-white" />
          </div>
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <AdminSidebar open={sidebarOpen} onOpenChange={setSidebarOpen} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col lg:ml-64">
        {/* Top Bar */}
        <AdminTopBar userInfo={userInfo} onMenuClick={() => setSidebarOpen(!sidebarOpen)} />

        {/* Dashboard Content */}
        <main className="flex-1 p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Welcome Section */}
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Welcome back, {userInfo.name || "Administrator"}
              </h1>
              <p className="text-gray-600">Here's what's happening with your care management system today.</p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                        <p className="text-3xl font-bold text-gray-900 mt-2">{stat.value}</p>
                        <p
                          className={`text-sm mt-1 ${stat.change.startsWith("+") ? "text-green-600" : "text-red-600"}`}
                        >
                          {stat.change} from last month
                        </p>
                      </div>
                      <div className={`${stat.bgColor} p-3 rounded-full`}>
                        <stat.icon className={`h-6 w-6 ${stat.color}`} />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Main Dashboard Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Recent Activities */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5" />
                      Recent Activities
                    </CardTitle>
                    <CardDescription>Latest updates across your platform</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentActivities.map((activity) => (
                        <div key={activity.id} className="flex items-start gap-4 p-4 rounded-lg bg-gray-50">
                          <div
                            className={`w-2 h-2 rounded-full mt-2 ${
                              activity.status === "success"
                                ? "bg-green-500"
                                : activity.status === "warning"
                                  ? "bg-yellow-500"
                                  : "bg-blue-500"
                            }`}
                          />
                          <div className="flex-1">
                            <p className="text-sm font-medium text-gray-900">{activity.message}</p>
                            <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Upcoming Appointments */}
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="h-5 w-5" />
                      Today's Schedule
                    </CardTitle>
                    <CardDescription>Upcoming appointments</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {upcomingAppointments.map((appointment) => (
                        <div key={appointment.id} className="p-3 border rounded-lg">
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-medium text-sm">{appointment.client}</h4>
                            <Badge variant={appointment.status === "confirmed" ? "default" : "secondary"}>
                              {appointment.status}
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-600 mb-1">{appointment.caregiver}</p>
                          <div className="flex justify-between items-center">
                            <span className="text-xs text-gray-500">{appointment.time}</span>
                            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                              {appointment.service}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                    <Button variant="outline" className="w-full mt-4">
                      View All Appointments
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Caregiver Hours Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Caregiver Hours Today
                </CardTitle>
                <CardDescription>Current shift status and hours</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "Sarah Wilson", status: "clocked-in", hours: "6.5h", shift: "Day", clockIn: "8:00 AM" },
                    { name: "Mike Davis", status: "clocked-out", hours: "8.0h", shift: "Day", clockOut: "4:00 PM" },
                    { name: "Lisa Chen", status: "clocked-in", hours: "4.2h", shift: "Night", clockIn: "8:00 PM" },
                    { name: "John Smith", status: "scheduled", hours: "0h", shift: "Night", clockIn: "11:00 PM" },
                  ].map((caregiver, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-orange-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                          {caregiver.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </div>
                        <div>
                          <h4 className="font-medium text-sm">{caregiver.name}</h4>
                          <p className="text-xs text-gray-600">{caregiver.shift} Shift</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center gap-2">
                          <Badge
                            variant={
                              caregiver.status === "clocked-in"
                                ? "default"
                                : caregiver.status === "clocked-out"
                                  ? "secondary"
                                  : "outline"
                            }
                            className="text-xs"
                          >
                            {caregiver.status === "clocked-in" && "🟢 Active"}
                            {caregiver.status === "clocked-out" && "⚫ Complete"}
                            {caregiver.status === "scheduled" && "⏰ Scheduled"}
                          </Badge>
                        </div>
                        <p className="text-sm font-semibold">{caregiver.hours}</p>
                        <p className="text-xs text-gray-500">
                          {caregiver.status === "clocked-in" && `Since ${caregiver.clockIn}`}
                          {caregiver.status === "clocked-out" && `Until ${caregiver.clockOut}`}
                          {caregiver.status === "scheduled" && `Starts ${caregiver.clockIn}`}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                <Button
                  variant="outline"
                  className="w-full mt-4"
                  onClick={() => (window.location.href = "/admin/caregiver-hours")}
                >
                  View All Caregiver Hours
                </Button>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Common administrative tasks</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <Button
                    className="h-20 flex flex-col gap-2 bg-blue-500 hover:bg-blue-600"
                    onClick={() => (window.location.href = "/admin/users")}
                  >
                    <Users className="h-6 w-6" />
                    Manage Users
                  </Button>
                  <Button
                    variant="outline"
                    className="h-20 flex flex-col gap-2"
                    onClick={() => (window.location.href = "/appointments")}
                  >
                    <Calendar className="h-6 w-6" />
                    Schedule Appointment
                  </Button>
                  <Button
                    variant="outline"
                    className="h-20 flex flex-col gap-2"
                    onClick={() => (window.location.href = "/messaging")}
                  >
                    <MessageSquare className="h-6 w-6" />
                    Send Message
                  </Button>
                  <Button
                    variant="outline"
                    className="h-20 flex flex-col gap-2"
                    onClick={() => (window.location.href = "/admin/reports")}
                  >
                    <FileText className="h-6 w-6" />
                    Generate Report
                  </Button>
                  <Button
                    variant="outline"
                    className="h-20 flex flex-col gap-2"
                    onClick={() => (window.location.href = "/admin/caregiver-hours")}
                  >
                    <Clock className="h-6 w-6" />
                    Caregiver Hours
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
