"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Heart, Shield, Users, Phone, Mail, Eye, EyeOff } from "lucide-react"
import Link from "next/link"

export default function LoginPage() {
  // Use null as initial state to indicate "not yet hydrated"
  const [isClient, setIsClient] = useState<boolean | null>(null)
  const [formData, setFormData] = useState({
    username: "", // Can be username or email
    password: "",
    role: "",
  })
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [loginError, setLoginError] = useState("")

  // Fix hydration mismatch by ensuring client-side only rendering
  useEffect(() => {
    // Only set isClient to true after hydration is complete
    setIsClient(true)
  }, [])

  // Initialize default admin account
  useEffect(() => {
    if (typeof window !== "undefined") {
      // Check if admin account exists
      const adminExists =
        localStorage.getItem("user_admin") || localStorage.getItem("user_saad@warmheavenenterprise.com")

      if (!adminExists) {
        // Create default admin account
        const adminUser = {
          id: 1,
          name: "Administrator",
          username: "admin",
          email: "saad@warmheavenenterprise.com",
          password: "Warm2025@",
          phone: "888-404-9276",
          role: "admin",
          status: "active",
          joinDate: "2023-01-01",
          lastLogin: new Date().toLocaleString(),
          address: "Warm Heaven Enterprise HQ",
          permissions: ["Full Access", "User Management", "System Settings"],
          profilePicture: "/placeholder.svg?height=100&width=100",
        }

        // Save admin credentials
        localStorage.setItem(
          "user_admin",
          JSON.stringify({
            username: "admin",
            password: "Warm2025@",
            email: "saad@warmheavenenterprise.com",
            role: "admin",
            name: "Administrator",
          }),
        )

        // Also save with email as key for email login
        localStorage.setItem(
          "user_saad@warmheavenenterprise.com",
          JSON.stringify({
            username: "admin",
            password: "Warm2025@",
            email: "saad@warmheavenenterprise.com",
            role: "admin",
            name: "Administrator",
          }),
        )

        // Add to all users
        const allUsers = JSON.parse(localStorage.getItem("allUsers") || "[]")
        if (!allUsers.some((u) => u.username === "admin")) {
          allUsers.push(adminUser)
          localStorage.setItem("allUsers", JSON.stringify(allUsers))
        }
      }
    }
  }, [isClient])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setLoginError("")

    // Simulate login process
    setTimeout(() => {
      if (formData.username && formData.password && formData.role) {
        if (typeof window !== "undefined") {
          // Special case for admin login
          const isAdminLogin =
            (formData.username === "admin" || formData.username === "saad@warmheavenenterprise.com") &&
            formData.password === "Warm2025@" &&
            formData.role === "admin"

          if (isAdminLogin) {
            // Admin login success
            localStorage.setItem("userRole", "admin")
            localStorage.setItem("userEmail", "saad@warmheavenenterprise.com")
            localStorage.setItem("userName", "Administrator")
            localStorage.setItem("userUsername", "admin")
            window.location.href = "/admin-dashboard"
            return
          }

          // Check user credentials - try both username and email
          let userCredentials = localStorage.getItem(`user_${formData.username}`)

          // If not found by username, try to find by email among all users
          if (!userCredentials && formData.username.includes("@")) {
            const allUsers = JSON.parse(localStorage.getItem("allUsers") || "[]")
            const userByEmail = allUsers.find((u) => u.email === formData.username)
            if (userByEmail) {
              userCredentials = localStorage.getItem(`user_${userByEmail.username}`)
            }
          }

          if (!userCredentials) {
            setLoginError("Invalid username or email! User not found.")
            setIsLoading(false)
            return
          }

          try {
            const userData = JSON.parse(userCredentials)

            // Verify password and role
            if (userData.password !== formData.password) {
              setLoginError("Invalid password!")
              setIsLoading(false)
              return
            }

            if (userData.role !== formData.role) {
              setLoginError(`Invalid role! This user is registered as ${userData.role}.`)
              setIsLoading(false)
              return
            }

            // Successful login
            localStorage.setItem("userRole", userData.role)
            localStorage.setItem("userEmail", userData.email)
            localStorage.setItem("userName", userData.name)
            localStorage.setItem("userUsername", userData.username)

            // Update last login time
            const allUsers = JSON.parse(localStorage.getItem("allUsers") || "[]")
            const updatedUsers = allUsers.map((user) =>
              user.username === userData.username ? { ...user, lastLogin: new Date().toLocaleString() } : user,
            )
            localStorage.setItem("allUsers", JSON.stringify(updatedUsers))

            // Redirect based on role
            switch (userData.role) {
              case "admin":
                window.location.href = "/admin-dashboard"
                break
              case "caregiver":
                window.location.href = "/caregiver-dashboard"
                break
              case "client":
                window.location.href = "/client-dashboard"
                break
            }
          } catch (error) {
            console.error("Error parsing user data:", error)
            setLoginError("Login error. Please try again.")
            setIsLoading(false)
          }
        }
      } else {
        setLoginError("Please fill in all fields!")
        setIsLoading(false)
      }
    }, 1000)
  }

  // Show loading state during hydration
  if (isClient === null) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-orange-50 flex items-center justify-center">
        <div className="text-center">
          <div className="bg-gradient-to-r from-blue-500 to-orange-500 p-4 rounded-full shadow-lg mx-auto mb-4 w-16 h-16 flex items-center justify-center">
            <Heart className="h-8 w-8 text-white" />
          </div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-orange-50 flex flex-col">
      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-6">
              <div className="bg-gradient-to-r from-blue-500 to-orange-500 p-4 rounded-full shadow-lg">
                <Heart className="h-10 w-10 text-white" />
              </div>
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-3">Warm Heaven Enterprise</h1>
            <p className="text-lg text-gray-600 mb-2">Compassionate Care Management</p>
            <p className="text-sm text-gray-500">Connecting hearts, delivering care</p>
          </div>

          {/* Login Card */}
          <Card className="shadow-xl border-0">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-2xl font-semibold text-gray-900">Welcome Back</CardTitle>
              <CardDescription className="text-gray-600">
                Sign in to access your care management dashboard
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-6">
                {/* Role Selection */}
                <div className="space-y-2">
                  <Label htmlFor="role" className="text-sm font-medium text-gray-700">
                    Select Your Role
                  </Label>
                  <Select value={formData.role} onValueChange={(value) => setFormData({ ...formData, role: value })}>
                    <SelectTrigger className="h-12 text-base">
                      <SelectValue placeholder="Choose your role to continue" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin" className="py-3">
                        <div className="flex items-center gap-3">
                          <div className="bg-blue-100 p-2 rounded-full">
                            <Shield className="h-4 w-4 text-blue-600" />
                          </div>
                          <div>
                            <div className="font-medium">Administrator</div>
                            <div className="text-sm text-gray-500">Full system access</div>
                          </div>
                        </div>
                      </SelectItem>
                      <SelectItem value="caregiver" className="py-3">
                        <div className="flex items-center gap-3">
                          <div className="bg-orange-100 p-2 rounded-full">
                            <Heart className="h-4 w-4 text-orange-600" />
                          </div>
                          <div>
                            <div className="font-medium">Caregiver</div>
                            <div className="text-sm text-gray-500">Care provider access</div>
                          </div>
                        </div>
                      </SelectItem>
                      <SelectItem value="client" className="py-3">
                        <div className="flex items-center gap-3">
                          <div className="bg-green-100 p-2 rounded-full">
                            <Users className="h-4 w-4 text-green-600" />
                          </div>
                          <div>
                            <div className="font-medium">Client/Family</div>
                            <div className="text-sm text-gray-500">Care recipient access</div>
                          </div>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Username/Email Field */}
                <div className="space-y-2">
                  <Label htmlFor="username" className="text-sm font-medium text-gray-700">
                    Username or Email
                  </Label>
                  <Input
                    id="username"
                    type="text"
                    placeholder="Enter your username or email"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    className="h-12 text-base"
                    required
                  />
                </div>

                {/* Password Field */}
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium text-gray-700">
                    Password
                  </Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      className="h-12 text-base pr-12"
                      required
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 p-0"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                {/* Error Message */}
                {loginError && <div className="bg-red-50 text-red-600 p-3 rounded-md text-sm">{loginError}</div>}

                {/* Login Button */}
                <Button
                  type="submit"
                  className="w-full h-12 text-base font-medium bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 transition-all duration-200"
                  disabled={isLoading}
                >
                  {isLoading ? "Signing In..." : "Sign In"}
                </Button>

                {/* Forgot Password */}
                <div className="text-center">
                  <Link
                    href="/forgot-password"
                    className="text-sm text-blue-600 hover:text-blue-700 font-medium hover:underline"
                  >
                    Forgot your password?
                  </Link>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-6">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="bg-gradient-to-r from-blue-500 to-orange-500 p-2 rounded-full">
                <Heart className="h-5 w-5 text-white" />
              </div>
              <span className="font-semibold text-gray-900">Warm Heaven Enterprise Inc.</span>
            </div>
            <div className="flex flex-col md:flex-row items-center gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span className="font-medium">888-404-9276</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <span>Saad@warmheavenenterprise.com</span>
              </div>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-gray-100 text-center text-xs text-gray-500">
            © {new Date().getFullYear()} Warm Heaven Enterprise Inc. All rights reserved. | Providing compassionate care
            with professional excellence.
          </div>
        </div>
      </footer>
    </div>
  )
}
