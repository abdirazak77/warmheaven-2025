"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProfilePictureUpload } from "@/components/profile-picture-upload"
import { Navigation } from "@/components/navigation"
import { Save, User, Shield, Heart, Users, Phone, Mail, MapPin, Calendar } from "lucide-react"

export default function ProfilePage() {
  const [userInfo, setUserInfo] = useState({
    name: "",
    email: "",
    role: "",
    profilePicture: "",
  })

  const [profileData, setProfileData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    dateOfBirth: "",
    emergencyContact: "",
    bio: "",
    specialties: "",
    certifications: "",
    experience: "",
    profilePicture: "",
  })

  const [isSaving, setIsSaving] = useState(false)

  useEffect(() => {
    // Load user data from localStorage
    const email = localStorage.getItem("userEmail") || ""
    const name = localStorage.getItem("userName") || ""
    const role = localStorage.getItem("userRole") || ""
    const profilePicture = localStorage.getItem("userProfilePicture") || ""

    setUserInfo({ name, email, role, profilePicture })

    // Load existing profile data (in real app, this would come from API)
    const existingProfile = localStorage.getItem("userProfile")
    if (existingProfile) {
      setProfileData(JSON.parse(existingProfile))
    } else {
      // Set default values
      const [firstName, lastName] = name.split(" ")
      setProfileData({
        firstName: firstName || "",
        lastName: lastName || "",
        email,
        phone: "",
        address: "",
        dateOfBirth: "",
        emergencyContact: "",
        bio: "",
        specialties: "",
        certifications: "",
        experience: "",
        profilePicture,
      })
    }
  }, [])

  const handleSave = async () => {
    setIsSaving(true)

    // Simulate API call
    setTimeout(() => {
      // Save to localStorage (in real app, this would be an API call)
      localStorage.setItem("userProfile", JSON.stringify(profileData))
      localStorage.setItem("userProfilePicture", profileData.profilePicture)
      localStorage.setItem("userName", `${profileData.firstName} ${profileData.lastName}`)

      setIsSaving(false)
      alert("Profile updated successfully!")
    }, 1000)
  }

  const handleLogout = () => {
    localStorage.clear()
    window.location.href = "/"
  }

  const handleProfilePictureChange = (imageUrl: string) => {
    setProfileData({ ...profileData, profilePicture: imageUrl })
  }

  const getRoleIcon = () => {
    switch (userInfo.role) {
      case "admin":
        return <Shield className="h-5 w-5 text-blue-600" />
      case "caregiver":
        return <Heart className="h-5 w-5 text-orange-600" />
      case "client":
        return <Users className="h-5 w-5 text-green-600" />
      default:
        return <User className="h-5 w-5 text-gray-600" />
    }
  }

  const getRoleTitle = () => {
    switch (userInfo.role) {
      case "admin":
        return "Administrator"
      case "caregiver":
        return "Caregiver"
      case "client":
        return "Client/Family"
      default:
        return "User"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation userRole={userInfo.role} userEmail={userInfo.email} onLogout={handleLogout} />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">My Profile</h1>
          <p className="text-gray-600">Manage your account information and preferences</p>
        </div>

        <Tabs defaultValue="general" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="professional">Professional</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {getRoleIcon()}
                  Personal Information
                </CardTitle>
                <CardDescription>Update your personal details and contact information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Profile Picture Section */}
                <div className="flex flex-col items-center space-y-4 pb-6 border-b">
                  <ProfilePictureUpload
                    currentImage={profileData.profilePicture}
                    userName={`${profileData.firstName} ${profileData.lastName}` || userInfo.name}
                    onImageChange={handleProfilePictureChange}
                    size="xl"
                  />
                  <div className="text-center">
                    <h3 className="font-semibold text-lg">
                      {`${profileData.firstName} ${profileData.lastName}` || userInfo.name}
                    </h3>
                    <p className="text-gray-600 flex items-center justify-center gap-2">
                      {getRoleIcon()}
                      {getRoleTitle()}
                    </p>
                  </div>
                </div>

                {/* Personal Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      value={profileData.firstName}
                      onChange={(e) => setProfileData({ ...profileData, firstName: e.target.value })}
                      placeholder="Enter your first name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      value={profileData.lastName}
                      onChange={(e) => setProfileData({ ...profileData, lastName: e.target.value })}
                      placeholder="Enter your last name"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="email"
                        type="email"
                        value={profileData.email}
                        onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                        className="pl-10"
                        placeholder="Enter your email"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="phone"
                        value={profileData.phone}
                        onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                        className="pl-10"
                        placeholder="Enter your phone number"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Textarea
                      id="address"
                      value={profileData.address}
                      onChange={(e) => setProfileData({ ...profileData, address: e.target.value })}
                      className="pl-10"
                      placeholder="Enter your full address"
                      rows={2}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="dateOfBirth">Date of Birth</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="dateOfBirth"
                        type="date"
                        value={profileData.dateOfBirth}
                        onChange={(e) => setProfileData({ ...profileData, dateOfBirth: e.target.value })}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="emergencyContact">Emergency Contact</Label>
                    <Input
                      id="emergencyContact"
                      value={profileData.emergencyContact}
                      onChange={(e) => setProfileData({ ...profileData, emergencyContact: e.target.value })}
                      placeholder="Name - Phone Number"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea
                    id="bio"
                    value={profileData.bio}
                    onChange={(e) => setProfileData({ ...profileData, bio: e.target.value })}
                    placeholder="Tell us about yourself..."
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="professional" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Professional Information</CardTitle>
                <CardDescription>
                  {userInfo.role === "caregiver"
                    ? "Update your professional qualifications and experience"
                    : userInfo.role === "client"
                      ? "Update your care preferences and requirements"
                      : "Update your administrative information"}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {userInfo.role === "caregiver" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="specialties">Specialties</Label>
                      <Textarea
                        id="specialties"
                        value={profileData.specialties}
                        onChange={(e) => setProfileData({ ...profileData, specialties: e.target.value })}
                        placeholder="e.g., Elderly Care, Dementia Support, Physical Therapy"
                        rows={2}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="certifications">Certifications</Label>
                      <Textarea
                        id="certifications"
                        value={profileData.certifications}
                        onChange={(e) => setProfileData({ ...profileData, certifications: e.target.value })}
                        placeholder="e.g., CNA, CPR, First Aid"
                        rows={2}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="experience">Experience</Label>
                      <Textarea
                        id="experience"
                        value={profileData.experience}
                        onChange={(e) => setProfileData({ ...profileData, experience: e.target.value })}
                        placeholder="Describe your professional experience..."
                        rows={3}
                      />
                    </div>
                  </>
                )}

                {userInfo.role === "client" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="careNeeds">Care Needs</Label>
                      <Textarea
                        id="careNeeds"
                        value={profileData.specialties}
                        onChange={(e) => setProfileData({ ...profileData, specialties: e.target.value })}
                        placeholder="Describe your care needs and preferences..."
                        rows={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="medicalInfo">Medical Information</Label>
                      <Textarea
                        id="medicalInfo"
                        value={profileData.certifications}
                        onChange={(e) => setProfileData({ ...profileData, certifications: e.target.value })}
                        placeholder="Any relevant medical information..."
                        rows={3}
                      />
                    </div>
                  </>
                )}

                {userInfo.role === "admin" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="department">Department</Label>
                      <Input
                        id="department"
                        value={profileData.specialties}
                        onChange={(e) => setProfileData({ ...profileData, specialties: e.target.value })}
                        placeholder="e.g., Operations, HR, IT"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="responsibilities">Responsibilities</Label>
                      <Textarea
                        id="responsibilities"
                        value={profileData.experience}
                        onChange={(e) => setProfileData({ ...profileData, experience: e.target.value })}
                        placeholder="Describe your administrative responsibilities..."
                        rows={3}
                      />
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Security Settings</CardTitle>
                <CardDescription>Manage your account security and privacy settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium mb-2">Change Password</h4>
                    <p className="text-sm text-gray-600 mb-4">Update your account password for better security</p>
                    <Button variant="outline">Change Password</Button>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium mb-2">Two-Factor Authentication</h4>
                    <p className="text-sm text-gray-600 mb-4">Add an extra layer of security to your account</p>
                    <Button variant="outline">Enable 2FA</Button>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium mb-2">Privacy Settings</h4>
                    <p className="text-sm text-gray-600 mb-4">Control who can see your profile information</p>
                    <Select defaultValue="team">
                      <SelectTrigger className="w-48">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="public">Public</SelectItem>
                        <SelectItem value="team">Team Only</SelectItem>
                        <SelectItem value="private">Private</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Save Button */}
        <div className="flex justify-end">
          <Button onClick={handleSave} disabled={isSaving} className="bg-blue-500 hover:bg-blue-600">
            <Save className="h-4 w-4 mr-2" />
            {isSaving ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </div>
    </div>
  )
}
