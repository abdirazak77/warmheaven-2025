"use client"

import React from "react"

import { useState, useCallback, useMemo, useTransition } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Calendar, Clock, User, MapPin, Plus, Edit, Trash2, Search, Save, Phone, Mail, Loader2 } from "lucide-react"

interface Appointment {
  id: number
  client: {
    name: string
    email: string
    phone: string
    address: string
  }
  caregiver: {
    name: string
    email: string
    phone: string
    specialties: string[]
  }
  date: string
  startTime: string
  endTime: string
  duration: number
  services: string[]
  status: "confirmed" | "pending" | "cancelled" | "completed"
  notes: string
  recurringType?: "none" | "daily" | "weekly" | "monthly"
  priority: "low" | "medium" | "high" | "urgent"
  location: string
  cost: number
}

export default function AppointmentsPage() {
  const [filterBy, setFilterBy] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null)
  const [activeTab, setActiveTab] = useState("calendar")
  const [isLoading, setIsLoading] = useState(false)
  const [isPending, startTransition] = useTransition()

  // Mock appointments data
  const [appointments, setAppointments] = useState<Appointment[]>([
    {
      id: 1,
      client: {
        name: "Margaret Johnson",
        email: "margaret.j@email.com",
        phone: "555-0124",
        address: "123 Oak Street, Springfield",
      },
      caregiver: {
        name: "Sarah Wilson",
        email: "sarah.wilson@warmheaven.com",
        phone: "555-0123",
        specialties: ["Personal Care", "Elderly Care"],
      },
      date: "2024-01-22",
      startTime: "09:00",
      endTime: "13:00",
      duration: 4,
      services: ["Personal Care", "Meal Preparation"],
      status: "confirmed",
      notes: "Client prefers morning appointments",
      recurringType: "weekly",
      priority: "medium",
      location: "Client's Home",
      cost: 160,
    },
    {
      id: 2,
      client: {
        name: "Robert Miller",
        email: "robert.m@email.com",
        phone: "555-0127",
        address: "456 Pine Avenue, Springfield",
      },
      caregiver: {
        name: "Mike Davis",
        email: "mike.davis@warmheaven.com",
        phone: "555-0125",
        specialties: ["Physical Therapy", "Mobility Support"],
      },
      date: "2024-01-22",
      startTime: "14:00",
      endTime: "18:00",
      duration: 4,
      services: ["Physical Therapy", "Companionship"],
      status: "confirmed",
      notes: "Requires mobility assistance",
      recurringType: "weekly",
      priority: "high",
      location: "Client's Home",
      cost: 180,
    },
    {
      id: 3,
      client: {
        name: "Eleanor Brown",
        email: "eleanor.b@email.com",
        phone: "555-0128",
        address: "789 Maple Drive, Springfield",
      },
      caregiver: {
        name: "Lisa Chen",
        email: "lisa.chen@warmheaven.com",
        phone: "555-0126",
        specialties: ["Dementia Care", "Specialized Care"],
      },
      date: "2024-01-23",
      startTime: "10:00",
      endTime: "14:00",
      duration: 4,
      services: ["Dementia Care", "Personal Care"],
      status: "pending",
      notes: "Family will be present",
      recurringType: "none",
      priority: "urgent",
      location: "Client's Home",
      cost: 200,
    },
  ])

  const [appointmentForm, setAppointmentForm] = useState<Partial<Appointment>>({
    client: { name: "", email: "", phone: "", address: "" },
    caregiver: { name: "", email: "", phone: "", specialties: [] },
    date: "",
    startTime: "",
    endTime: "",
    duration: 0,
    services: [],
    status: "pending",
    notes: "",
    recurringType: "none",
    priority: "medium",
    location: "Client's Home",
    cost: 0,
  })

  const caregivers = [
    { id: 1, name: "Sarah Wilson", specialties: ["Personal Care", "Elderly Care"], hourlyRate: 40 },
    { id: 2, name: "Mike Davis", specialties: ["Physical Therapy", "Mobility Support"], hourlyRate: 45 },
    { id: 3, name: "Lisa Chen", specialties: ["Dementia Care", "Specialized Care"], hourlyRate: 50 },
    { id: 4, name: "John Smith", specialties: ["Post-Surgery Care", "Medication Management"], hourlyRate: 45 },
    { id: 5, name: "Emily Johnson", specialties: ["Companionship", "Light Housekeeping"], hourlyRate: 35 },
  ]

  const clients = [
    { id: 1, name: "Margaret Johnson", address: "123 Oak Street", email: "margaret.j@email.com", phone: "555-0124" },
    { id: 2, name: "Robert Miller", address: "456 Pine Avenue", email: "robert.m@email.com", phone: "555-0127" },
    { id: 3, name: "Eleanor Brown", address: "789 Maple Drive", email: "eleanor.b@email.com", phone: "555-0128" },
    { id: 4, name: "James Wilson", address: "321 Elm Street", email: "james.w@email.com", phone: "555-0129" },
    { id: 5, name: "Dorothy Smith", address: "654 Cedar Lane", email: "dorothy.s@email.com", phone: "555-0130" },
  ]

  const services = [
    { name: "Personal Care", rate: 40 },
    { name: "Meal Preparation", rate: 35 },
    { name: "Companionship", rate: 30 },
    { name: "Physical Therapy", rate: 50 },
    { name: "Medication Management", rate: 45 },
    { name: "Light Housekeeping", rate: 30 },
    { name: "Dementia Care", rate: 55 },
    { name: "Post-Surgery Care", rate: 50 },
  ]

  // Memoized filtered appointments
  const filteredAppointments = useMemo(() => {
    return appointments.filter((appointment) => {
      const matchesFilter = filterBy === "all" || appointment.status === filterBy
      const matchesSearch =
        appointment.client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        appointment.caregiver.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        appointment.services.some((service) => service.toLowerCase().includes(searchTerm.toLowerCase()))
      return matchesFilter && matchesSearch
    })
  }, [appointments, filterBy, searchTerm])

  // Memoized stats
  const stats = useMemo(
    () => ({
      total: appointments.length,
      confirmed: appointments.filter((a) => a.status === "confirmed").length,
      pending: appointments.filter((a) => a.status === "pending").length,
      completed: appointments.filter((a) => a.status === "completed").length,
      totalRevenue: appointments.reduce((sum, apt) => sum + apt.cost, 0),
    }),
    [appointments],
  )

  // Optimized color functions
  const getStatusColor = useCallback((status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      case "completed":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }, [])

  const getPriorityColor = useCallback((priority: string) => {
    switch (priority) {
      case "urgent":
        return "bg-red-100 text-red-800"
      case "high":
        return "bg-orange-100 text-orange-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }, [])

  const calculateDuration = useCallback((startTime: string, endTime: string) => {
    if (!startTime || !endTime) return 0
    const start = new Date(`2000-01-01T${startTime}:00`)
    const end = new Date(`2000-01-01T${endTime}:00`)
    return (end.getTime() - start.getTime()) / (1000 * 60 * 60)
  }, [])

  const calculateCost = useCallback((duration: number, services: string[]) => {
    const serviceRates = services.map(() => 40) // Simplified rate calculation
    const avgRate = serviceRates.length > 0 ? serviceRates.reduce((a, b) => a + b, 0) / serviceRates.length : 40
    return Math.round(duration * avgRate)
  }, [])

  // Optimized handlers
  const handleSaveAppointment = useCallback(() => {
    if (!appointmentForm.client?.name || !appointmentForm.caregiver?.name || !appointmentForm.date) {
      alert("Please fill in all required fields")
      return
    }

    setIsLoading(true)
    startTransition(() => {
      const duration = calculateDuration(appointmentForm.startTime || "", appointmentForm.endTime || "")
      const cost = calculateCost(duration, appointmentForm.services || [])

      if (selectedAppointment) {
        // Edit existing appointment
        setAppointments((prev) =>
          prev.map((apt) =>
            apt.id === selectedAppointment.id
              ? { ...apt, ...appointmentForm, duration, cost, id: selectedAppointment.id }
              : apt,
          ),
        )
        setShowEditDialog(false)
      } else {
        // Add new appointment
        const newAppointment: Appointment = {
          ...appointmentForm,
          id: Math.max(...appointments.map((a) => a.id)) + 1,
          duration,
          cost,
        } as Appointment

        setAppointments((prev) => [...prev, newAppointment])
        setShowAddDialog(false)
      }

      // Reset form
      setAppointmentForm({
        client: { name: "", email: "", phone: "", address: "" },
        caregiver: { name: "", email: "", phone: "", specialties: [] },
        date: "",
        startTime: "",
        endTime: "",
        duration: 0,
        services: [],
        status: "pending",
        notes: "",
        recurringType: "none",
        priority: "medium",
        location: "Client's Home",
        cost: 0,
      })
      setSelectedAppointment(null)
      setIsLoading(false)
    })
  }, [appointmentForm, selectedAppointment, appointments, calculateDuration, calculateCost])

  const handleEditAppointment = useCallback((appointment: Appointment) => {
    setSelectedAppointment(appointment)
    setAppointmentForm(appointment)
    setShowEditDialog(true)
  }, [])

  const handleDeleteAppointment = useCallback((appointmentId: number) => {
    setIsLoading(true)
    startTransition(() => {
      setAppointments((prev) => prev.filter((apt) => apt.id !== appointmentId))
      setIsLoading(false)
    })
  }, [])

  const handleStatusChange = useCallback((appointmentId: number, newStatus: string) => {
    setIsLoading(true)
    startTransition(() => {
      setAppointments((prev) =>
        prev.map((apt) => (apt.id === appointmentId ? { ...apt, status: newStatus as any } : apt)),
      )
      setIsLoading(false)
    })
  }, [])

  const handleSearchChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value)
  }, [])

  const handleFilterChange = useCallback((value: string) => {
    setFilterBy(value)
  }, [])

  const handleTabChange = useCallback((value: string) => {
    setActiveTab(value)
  }, [])

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Appointment Management</h1>
              <p className="text-sm text-gray-500">Schedule and manage caregiver appointments</p>
            </div>
            <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
              <DialogTrigger asChild>
                <Button className="bg-blue-500 hover:bg-blue-600" disabled={isLoading || isPending}>
                  {isLoading || isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Plus className="h-4 w-4 mr-2" />
                  )}
                  Schedule Appointment
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Schedule New Appointment</DialogTitle>
                  <DialogDescription>Create a new care appointment by filling out the details below.</DialogDescription>
                </DialogHeader>
                <AppointmentForm
                  appointment={appointmentForm}
                  setAppointment={setAppointmentForm}
                  clients={clients}
                  caregivers={caregivers}
                  services={services}
                  onSave={handleSaveAppointment}
                  onCancel={() => setShowAddDialog(false)}
                  calculateDuration={calculateDuration}
                  calculateCost={calculateCost}
                  isLoading={isLoading}
                />
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="calendar">Calendar View</TabsTrigger>
            <TabsTrigger value="list">List View</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="calendar" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {Object.entries(stats).map(([key, value]) => (
                <Card key={key}>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-gray-900">{value}</div>
                    <div className="text-sm text-gray-600 capitalize">{key.replace(/([A-Z])/g, " $1")}</div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Filters */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Search appointments by client, caregiver, or service..."
                        value={searchTerm}
                        onChange={handleSearchChange}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Select value={filterBy} onValueChange={handleFilterChange}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="confirmed">Confirmed</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Loading State */}
            {isPending && (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                <span className="ml-2 text-gray-600">Loading appointments...</span>
              </div>
            )}

            {/* Appointments Grid */}
            <div className="grid gap-6">
              {filteredAppointments.map((appointment) => (
                <AppointmentCard
                  key={appointment.id}
                  appointment={appointment}
                  getStatusColor={getStatusColor}
                  getPriorityColor={getPriorityColor}
                  onEdit={handleEditAppointment}
                  onStatusChange={handleStatusChange}
                  onDelete={handleDeleteAppointment}
                  isLoading={isLoading}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="list" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>All Appointments</CardTitle>
                <CardDescription>Comprehensive list of all scheduled appointments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3">Client</th>
                        <th className="text-left p-3">Caregiver</th>
                        <th className="text-left p-3">Date & Time</th>
                        <th className="text-left p-3">Services</th>
                        <th className="text-left p-3">Status</th>
                        <th className="text-left p-3">Cost</th>
                        <th className="text-left p-3">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredAppointments.map((appointment) => (
                        <tr key={appointment.id} className="border-b hover:bg-gray-50">
                          <td className="p-3">
                            <div>
                              <p className="font-medium">{appointment.client.name}</p>
                              <p className="text-sm text-gray-600">{appointment.client.phone}</p>
                            </div>
                          </td>
                          <td className="p-3">
                            <div>
                              <p className="font-medium">{appointment.caregiver.name}</p>
                              <p className="text-sm text-gray-600">{appointment.caregiver.specialties.join(", ")}</p>
                            </div>
                          </td>
                          <td className="p-3">
                            <div>
                              <p className="font-medium">{appointment.date}</p>
                              <p className="text-sm text-gray-600">
                                {appointment.startTime} - {appointment.endTime}
                              </p>
                            </div>
                          </td>
                          <td className="p-3">
                            <div className="flex flex-wrap gap-1">
                              {appointment.services.map((service, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {service}
                                </Badge>
                              ))}
                            </div>
                          </td>
                          <td className="p-3">
                            <Badge className={getStatusColor(appointment.status)}>{appointment.status}</Badge>
                          </td>
                          <td className="p-3">
                            <span className="font-semibold text-green-600">${appointment.cost}</span>
                          </td>
                          <td className="p-3">
                            <div className="flex gap-1">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleEditAppointment(appointment)}
                                disabled={isLoading}
                              >
                                {isLoading ? (
                                  <Loader2 className="h-3 w-3 animate-spin" />
                                ) : (
                                  <Edit className="h-3 w-3" />
                                )}
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button size="sm" variant="outline" className="text-red-600" disabled={isLoading}>
                                    <Trash2 className="h-3 w-3" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Delete Appointment</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Are you sure you want to delete this appointment?
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => handleDeleteAppointment(appointment.id)}
                                      className="bg-red-600 hover:bg-red-700"
                                    >
                                      Delete
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {Object.entries(stats).map(([key, value]) => (
                <Card key={key}>
                  <CardHeader>
                    <CardTitle className="text-lg capitalize">{key.replace(/([A-Z])/g, " $1")}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-blue-600">{value}</div>
                    <p className="text-sm text-gray-600">
                      {key === "totalRevenue" ? "From all appointments" : "All time"}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Edit Appointment Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Appointment</DialogTitle>
            <DialogDescription>Update appointment details and settings.</DialogDescription>
          </DialogHeader>
          <AppointmentForm
            appointment={appointmentForm}
            setAppointment={setAppointmentForm}
            clients={clients}
            caregivers={caregivers}
            services={services}
            onSave={handleSaveAppointment}
            onCancel={() => {
              setShowEditDialog(false)
              setSelectedAppointment(null)
            }}
            calculateDuration={calculateDuration}
            calculateCost={calculateCost}
            isLoading={isLoading}
          />
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Optimized Appointment Card Component
const AppointmentCard = React.memo(
  ({
    appointment,
    getStatusColor,
    getPriorityColor,
    onEdit,
    onStatusChange,
    onDelete,
    isLoading,
  }: {
    appointment: Appointment
    getStatusColor: (status: string) => string
    getPriorityColor: (priority: string) => string
    onEdit: (appointment: Appointment) => void
    onStatusChange: (id: number, status: string) => void
    onDelete: (id: number) => void
    isLoading: boolean
  }) => {
    return (
      <Card className="hover:shadow-lg transition-shadow">
        <CardContent className="p-6">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-4 flex-1">
              <Avatar className="h-12 w-12">
                <AvatarFallback className="bg-blue-100 text-blue-600">
                  {appointment.client.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <h3 className="font-semibold text-lg">{appointment.client.name}</h3>
                  <Badge className={getStatusColor(appointment.status)}>{appointment.status}</Badge>
                  <Badge className={getPriorityColor(appointment.priority)}>{appointment.priority}</Badge>
                  {appointment.recurringType !== "none" && (
                    <Badge variant="outline">Recurring: {appointment.recurringType}</Badge>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      <span>Caregiver: {appointment.caregiver.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      <span>{appointment.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      <span>
                        {appointment.startTime} - {appointment.endTime} ({appointment.duration}h)
                      </span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      <span>{appointment.location}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4" />
                      <span>{appointment.client.phone}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4" />
                      <span>{appointment.client.email}</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <p className="font-medium mb-1">Services:</p>
                      <div className="flex flex-wrap gap-1">
                        {appointment.services.map((service, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {service}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <span className="font-medium">Cost: </span>
                      <span className="text-green-600 font-semibold">${appointment.cost}</span>
                    </div>
                  </div>
                </div>

                {appointment.notes && (
                  <div className="mt-3 p-2 bg-gray-50 rounded text-sm">
                    <span className="font-medium">Notes: </span>
                    {appointment.notes}
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-col gap-2 ml-4">
              <Button variant="outline" size="sm" onClick={() => onEdit(appointment)} disabled={isLoading}>
                {isLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Edit className="h-4 w-4 mr-2" />}
                Edit
              </Button>
              {appointment.status === "pending" && (
                <Button
                  size="sm"
                  onClick={() => onStatusChange(appointment.id, "confirmed")}
                  className="bg-green-600 hover:bg-green-700"
                  disabled={isLoading}
                >
                  Confirm
                </Button>
              )}
              {appointment.status === "confirmed" && (
                <Button
                  size="sm"
                  onClick={() => onStatusChange(appointment.id, "completed")}
                  className="bg-blue-600 hover:bg-blue-700"
                  disabled={isLoading}
                >
                  Complete
                </Button>
              )}
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700" disabled={isLoading}>
                    <Trash2 className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Cancel Appointment</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to cancel this appointment? This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Keep Appointment</AlertDialogCancel>
                    <AlertDialogAction onClick={() => onDelete(appointment.id)} className="bg-red-600 hover:bg-red-700">
                      Cancel Appointment
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  },
)

// Optimized Appointment Form Component
function AppointmentForm({
  appointment,
  setAppointment,
  clients,
  caregivers,
  services,
  onSave,
  onCancel,
  calculateDuration,
  calculateCost,
  isLoading = false,
}: {
  appointment: Partial<Appointment>
  setAppointment: (apt: Partial<Appointment>) => void
  clients: any[]
  caregivers: any[]
  services: any[]
  onSave: () => void
  onCancel: () => void
  calculateDuration: (start: string, end: string) => number
  calculateCost: (duration: number, services: string[]) => number
  isLoading?: boolean
}) {
  const handleClientChange = useCallback(
    (clientName: string) => {
      const client = clients.find((c) => c.name === clientName)
      if (client) {
        setAppointment({
          ...appointment,
          client: {
            name: client.name,
            email: client.email,
            phone: client.phone,
            address: client.address,
          },
        })
      }
    },
    [clients, appointment, setAppointment],
  )

  const handleCaregiverChange = useCallback(
    (caregiverName: string) => {
      const caregiver = caregivers.find((c) => c.name === caregiverName)
      if (caregiver) {
        setAppointment({
          ...appointment,
          caregiver: {
            name: caregiver.name,
            email: `${caregiver.name.toLowerCase().replace(" ", ".")}@warmheaven.com`,
            phone: "555-0123",
            specialties: caregiver.specialties,
          },
        })
      }
    },
    [caregivers, appointment, setAppointment],
  )

  const handleTimeChange = useCallback(() => {
    if (appointment.startTime && appointment.endTime) {
      const duration = calculateDuration(appointment.startTime, appointment.endTime)
      const cost = calculateCost(duration, appointment.services || [])
      setAppointment({ ...appointment, duration, cost })
    }
  }, [appointment, calculateDuration, calculateCost, setAppointment])

  const handleServiceChange = useCallback(
    (serviceName: string, checked: boolean) => {
      const currentServices = appointment.services || []
      const newServices = checked ? [...currentServices, serviceName] : currentServices.filter((s) => s !== serviceName)

      const duration = appointment.duration || 0
      const cost = calculateCost(duration, newServices)
      setAppointment({ ...appointment, services: newServices, cost })
    },
    [appointment, calculateCost, setAppointment],
  )

  const handleInputChange = useCallback(
    (field: string, value: any) => {
      setAppointment({ ...appointment, [field]: value })
    },
    [appointment, setAppointment],
  )

  return (
    <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
      {/* Client Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Client</Label>
          <Select value={appointment.client?.name || ""} onValueChange={handleClientChange} disabled={isLoading}>
            <SelectTrigger>
              <SelectValue placeholder="Select client" />
            </SelectTrigger>
            <SelectContent>
              {clients.map((client) => (
                <SelectItem key={client.id} value={client.name}>
                  {client.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Caregiver</Label>
          <Select value={appointment.caregiver?.name || ""} onValueChange={handleCaregiverChange} disabled={isLoading}>
            <SelectTrigger>
              <SelectValue placeholder="Select caregiver" />
            </SelectTrigger>
            <SelectContent>
              {caregivers.map((caregiver) => (
                <SelectItem key={caregiver.id} value={caregiver.name}>
                  {caregiver.name} - {caregiver.specialties.join(", ")}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Date and Time */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label>Date</Label>
          <Input
            type="date"
            value={appointment.date || ""}
            onChange={(e) => handleInputChange("date", e.target.value)}
            disabled={isLoading}
          />
        </div>
        <div className="space-y-2">
          <Label>Start Time</Label>
          <Input
            type="time"
            value={appointment.startTime || ""}
            onChange={(e) => {
              handleInputChange("startTime", e.target.value)
              setTimeout(handleTimeChange, 100)
            }}
            disabled={isLoading}
          />
        </div>
        <div className="space-y-2">
          <Label>End Time</Label>
          <Input
            type="time"
            value={appointment.endTime || ""}
            onChange={(e) => {
              handleInputChange("endTime", e.target.value)
              setTimeout(handleTimeChange, 100)
            }}
            disabled={isLoading}
          />
        </div>
      </div>

      {/* Services */}
      <div className="space-y-2">
        <Label>Services Required</Label>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {services.map((service) => (
            <div key={service.name} className="flex items-center space-x-2">
              <input
                type="checkbox"
                id={service.name}
                checked={appointment.services?.includes(service.name) || false}
                onChange={(e) => handleServiceChange(service.name, e.target.checked)}
                className="rounded"
                disabled={isLoading}
              />
              <Label htmlFor={service.name} className="text-sm">
                {service.name}
              </Label>
            </div>
          ))}
        </div>
      </div>

      {/* Status and Priority */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label>Status</Label>
          <Select
            value={appointment.status || "pending"}
            onValueChange={(value) => handleInputChange("status", value)}
            disabled={isLoading}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="confirmed">Confirmed</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Priority</Label>
          <Select
            value={appointment.priority || "medium"}
            onValueChange={(value) => handleInputChange("priority", value)}
            disabled={isLoading}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="urgent">Urgent</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Recurring</Label>
          <Select
            value={appointment.recurringType || "none"}
            onValueChange={(value) => handleInputChange("recurringType", value)}
            disabled={isLoading}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">One-time</SelectItem>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Location and Notes */}
      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Location</Label>
          <Input
            value={appointment.location || ""}
            onChange={(e) => handleInputChange("location", e.target.value)}
            placeholder="e.g., Client's Home, Care Facility"
            disabled={isLoading}
          />
        </div>

        <div className="space-y-2">
          <Label>Notes</Label>
          <Textarea
            value={appointment.notes || ""}
            onChange={(e) => handleInputChange("notes", e.target.value)}
            placeholder="Special instructions or notes..."
            rows={3}
            disabled={isLoading}
          />
        </div>
      </div>

      {/* Cost Summary */}
      {appointment.duration && appointment.duration > 0 && (
        <div className="p-4 bg-gray-50 rounded-lg">
          <div className="flex justify-between items-center">
            <span>Duration: {appointment.duration} hours</span>
            <span className="font-semibold text-green-600">Total Cost: ${appointment.cost || 0}</span>
          </div>
        </div>
      )}

      {/* Sticky Action Buttons */}
      <div className="sticky bottom-0 bg-white pt-4 border-t flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isLoading}>
          Cancel
        </Button>
        <Button onClick={onSave} className="bg-blue-500 hover:bg-blue-600" disabled={isLoading}>
          {isLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
          Save Appointment
        </Button>
      </div>
    </div>
  )
}
