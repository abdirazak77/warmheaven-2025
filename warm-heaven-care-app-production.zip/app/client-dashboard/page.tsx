"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Users, Calendar, Heart, MessageSquare, FileText, Phone, Mail, Star, Clock, LogOut, Plus } from "lucide-react"

export default function ClientDashboard() {
  const [userInfo, setUserInfo] = useState({ name: "", email: "", profilePicture: "" })

  useEffect(() => {
    const email = localStorage.getItem("userEmail") || ""
    const name = localStorage.getItem("userName") || ""
    const profilePicture = localStorage.getItem("userProfilePicture") || ""
    setUserInfo({ name, email, profilePicture })
  }, [])

  const handleLogout = () => {
    localStorage.clear()
    window.location.href = "/"
  }

  const handleProfileClick = () => {
    window.location.href = "/profile"
  }

  // Mock data
  const upcomingVisits = [
    {
      id: 1,
      caregiver: "Sarah Johnson",
      date: "Today",
      time: "9:00 AM - 1:00 PM",
      services: ["Personal Care", "Meal Preparation", "Companionship"],
      status: "confirmed",
      caregiverPhoto: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 2,
      caregiver: "Sarah Johnson",
      date: "Tomorrow",
      time: "9:00 AM - 1:00 PM",
      services: ["Personal Care", "Light Housekeeping"],
      status: "confirmed",
      caregiverPhoto: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 3,
      caregiver: "Mike Davis",
      date: "Friday",
      time: "2:00 PM - 6:00 PM",
      services: ["Physical Therapy", "Companionship"],
      status: "pending",
      caregiverPhoto: "/placeholder.svg?height=100&width=100",
    },
  ]

  const caregiverProfile = {
    name: "Sarah Johnson",
    rating: 4.9,
    experience: "5 years",
    specialties: ["Elderly Care", "Dementia Support", "Physical Therapy"],
    phone: "555-0123",
    email: "sarah.johnson@warmheaven.com",
    bio: "Dedicated caregiver with extensive experience in elderly care and dementia support. Passionate about providing compassionate, personalized care.",
    profilePicture: "/placeholder.svg?height=100&width=100",
  }

  const recentMessages = [
    {
      id: 1,
      from: "Sarah Johnson",
      message: "Good morning! I'll be arriving at 9 AM as scheduled. Looking forward to our session today.",
      time: "2 hours ago",
      unread: true,
      avatar: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 2,
      from: "Administration",
      message: "Your care plan has been updated. Please review the changes in your dashboard.",
      time: "1 day ago",
      unread: false,
      avatar: "",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-2 rounded-lg">
                <Users className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">Client Dashboard</h1>
                <p className="text-sm text-gray-500">Welcome, {userInfo.name || "Client"}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {/* Profile Avatar */}
              <Button variant="ghost" onClick={handleProfileClick} className="p-1">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={userInfo.profilePicture || "/placeholder.svg"} alt={userInfo.name} />
                  <AvatarFallback className="bg-blue-100 text-blue-600">
                    {(userInfo.name || "C")
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
              </Button>

              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="visits">Visits</TabsTrigger>
            <TabsTrigger value="caregivers">Caregivers</TabsTrigger>
            <TabsTrigger value="requests">Requests</TabsTrigger>
            <TabsTrigger value="messages">Messages</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Welcome Section */}
            <Card className="bg-gradient-to-r from-blue-50 to-orange-50 border-0">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-2">Welcome to Your Care Dashboard</h2>
                    <p className="text-gray-600 mb-4">Stay connected with your care team and manage your services</p>
                    <div className="flex items-center gap-6 text-sm">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-blue-600" />
                        <span>Next visit: Today at 9:00 AM</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Heart className="h-4 w-4 text-orange-600" />
                        <span>Caregiver: Sarah Johnson</span>
                      </div>
                    </div>
                  </div>
                  <div className="hidden md:block">
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">4.9</div>
                        <div className="text-sm text-gray-500">Care Rating</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6 text-center">
                  <Calendar className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                  <div className="text-2xl font-bold text-gray-900">3</div>
                  <div className="text-sm text-gray-600">Upcoming Visits</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <MessageSquare className="h-8 w-8 text-orange-600 mx-auto mb-3" />
                  <div className="text-2xl font-bold text-gray-900">2</div>
                  <div className="text-sm text-gray-600">New Messages</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <FileText className="h-8 w-8 text-green-600 mx-auto mb-3" />
                  <div className="text-2xl font-bold text-gray-900">1</div>
                  <div className="text-sm text-gray-600">Care Summary</div>
                </CardContent>
              </Card>
            </div>

            {/* Upcoming Visits Preview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Next Visits
                </CardTitle>
                <CardDescription>Your upcoming care appointments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingVisits.slice(0, 2).map((visit) => (
                    <div key={visit.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-4">
                        <Avatar>
                          <AvatarImage src={visit.caregiverPhoto || "/placeholder.svg"} alt={visit.caregiver} />
                          <AvatarFallback className="bg-blue-100 text-blue-600">
                            {visit.caregiver
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold">{visit.caregiver}</h3>
                          <p className="text-sm text-gray-600">
                            {visit.date} • {visit.time}
                          </p>
                          <div className="flex gap-1 mt-1">
                            {visit.services.slice(0, 2).map((service, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {service}
                              </Badge>
                            ))}
                            {visit.services.length > 2 && (
                              <Badge variant="outline" className="text-xs">
                                +{visit.services.length - 2} more
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      <Badge variant={visit.status === "confirmed" ? "default" : "secondary"}>{visit.status}</Badge>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  View All Visits
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="visits" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Care Schedule</h2>
              <Button className="bg-blue-500 hover:bg-blue-600">
                <Plus className="h-4 w-4 mr-2" />
                Request Visit
              </Button>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Upcoming Visits</CardTitle>
                <CardDescription>Your scheduled care appointments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingVisits.map((visit) => (
                    <div key={visit.id} className="p-4 border rounded-lg hover:bg-gray-50">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-4">
                          <Avatar className="h-12 w-12">
                            <AvatarImage src={visit.caregiverPhoto || "/placeholder.svg"} alt={visit.caregiver} />
                            <AvatarFallback className="bg-blue-100 text-blue-600">
                              {visit.caregiver
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-semibold text-lg">{visit.caregiver}</h3>
                            <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
                              <Calendar className="h-4 w-4" />
                              <span>
                                {visit.date} • {visit.time}
                              </span>
                            </div>
                            <div className="mt-3">
                              <p className="text-sm font-medium text-gray-700 mb-2">Services:</p>
                              <div className="flex flex-wrap gap-2">
                                {visit.services.map((service, index) => (
                                  <Badge key={index} variant="outline">
                                    {service}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2">
                          <Badge variant={visit.status === "confirmed" ? "default" : "secondary"}>{visit.status}</Badge>
                          <Button variant="outline" size="sm">
                            <MessageSquare className="h-4 w-4 mr-2" />
                            Message
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="caregivers" className="space-y-6">
            <h2 className="text-2xl font-bold">Your Care Team</h2>

            <Card>
              <CardHeader>
                <CardTitle>Primary Caregiver</CardTitle>
                <CardDescription>Your assigned care professional</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-start gap-6">
                  <Avatar className="h-20 w-20">
                    <AvatarImage
                      src={caregiverProfile.profilePicture || "/placeholder.svg"}
                      alt={caregiverProfile.name}
                    />
                    <AvatarFallback className="bg-blue-100 text-blue-600 text-xl">
                      {caregiverProfile.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-xl font-semibold">{caregiverProfile.name}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <div className="flex items-center">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${
                                  i < Math.floor(caregiverProfile.rating)
                                    ? "text-yellow-400 fill-current"
                                    : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-sm text-gray-600">
                            {caregiverProfile.rating} • {caregiverProfile.experience} experience
                          </span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Phone className="h-4 w-4 mr-2" />
                          Call
                        </Button>
                        <Button size="sm" className="bg-blue-500 hover:bg-blue-600">
                          <MessageSquare className="h-4 w-4 mr-2" />
                          Message
                        </Button>
                      </div>
                    </div>

                    <p className="text-gray-600 mt-3">{caregiverProfile.bio}</p>

                    <div className="mt-4 space-y-3">
                      <div>
                        <h4 className="font-medium text-gray-900 mb-2">Specialties</h4>
                        <div className="flex flex-wrap gap-2">
                          {caregiverProfile.specialties.map((specialty, index) => (
                            <Badge key={index} variant="outline">
                              {specialty}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                        <div className="flex items-center gap-2 text-sm">
                          <Phone className="h-4 w-4 text-gray-500" />
                          <span>{caregiverProfile.phone}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Mail className="h-4 w-4 text-gray-500" />
                          <span>{caregiverProfile.email}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="requests" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Service Requests</h2>
              <Button className="bg-blue-500 hover:bg-blue-600">
                <Plus className="h-4 w-4 mr-2" />
                New Request
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Submit New Request</CardTitle>
                  <CardDescription>Request additional services or changes to your care plan</CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="request-type">Request Type</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select request type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="additional-hours">Additional Care Hours</SelectItem>
                          <SelectItem value="schedule-change">Schedule Change</SelectItem>
                          <SelectItem value="service-addition">Add New Service</SelectItem>
                          <SelectItem value="caregiver-change">Caregiver Change Request</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="priority">Priority Level</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="urgent">Urgent</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="preferred-date">Preferred Date</Label>
                      <Input type="date" />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="details">Request Details</Label>
                      <Textarea placeholder="Please provide detailed information about your request..." rows={4} />
                    </div>

                    <Button type="submit" className="w-full bg-blue-500 hover:bg-blue-600">
                      Submit Request
                    </Button>
                  </form>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Requests</CardTitle>
                  <CardDescription>Track the status of your submitted requests</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium">Additional Evening Care</h4>
                        <Badge variant="secondary">Pending</Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">
                        Requested additional 2 hours of evening care on weekends
                      </p>
                      <p className="text-xs text-gray-500">Submitted 2 days ago</p>
                    </div>

                    <div className="p-4 border rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium">Schedule Change</h4>
                        <Badge>Approved</Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">Changed Tuesday appointment from 9 AM to 11 AM</p>
                      <p className="text-xs text-gray-500">Submitted 1 week ago</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="messages" className="space-y-6">
            <h2 className="text-2xl font-bold">Messages</h2>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Messages</CardTitle>
                  <CardDescription>Communications from your care team</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentMessages.map((message) => (
                      <div
                        key={message.id}
                        className={`p-4 rounded-lg border ${
                          message.unread ? "bg-blue-50 border-blue-200" : "bg-gray-50"
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={message.avatar || "/placeholder.svg"} alt={message.from} />
                            <AvatarFallback className="bg-gray-200 text-gray-700 text-sm">
                              {message.from
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex justify-between items-start mb-2">
                              <h4 className="font-medium">{message.from}</h4>
                              <div className="flex items-center gap-2">
                                {message.unread && <div className="w-2 h-2 bg-blue-500 rounded-full"></div>}
                                <span className="text-xs text-gray-500">{message.time}</span>
                              </div>
                            </div>
                            <p className="text-sm text-gray-700">{message.message}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Send Message</CardTitle>
                  <CardDescription>Contact your caregiver or administration</CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="recipient">To</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select recipient" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sarah">Sarah Johnson (Caregiver)</SelectItem>
                          <SelectItem value="admin">Administration</SelectItem>
                          <SelectItem value="emergency">Emergency Contact</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="subject">Subject</Label>
                      <Input placeholder="Message subject" />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message">Message</Label>
                      <Textarea placeholder="Type your message here..." rows={4} />
                    </div>

                    <Button type="submit" className="w-full bg-blue-500 hover:bg-blue-600">
                      Send Message
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Emergency Contact */}
            <Card className="border-red-200 bg-red-50">
              <CardHeader>
                <CardTitle className="text-red-700 flex items-center gap-2">
                  <Phone className="h-5 w-5" />
                  Emergency Contact
                </CardTitle>
                <CardDescription className="text-red-600">For urgent care needs or emergencies</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-red-700">Warm Heaven Enterprise</p>
                    <p className="text-sm text-red-600">24/7 Emergency Hotline</p>
                  </div>
                  <Button className="bg-red-600 hover:bg-red-700">
                    <Phone className="h-4 w-4 mr-2" />
                    Call 888-404-9276
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
