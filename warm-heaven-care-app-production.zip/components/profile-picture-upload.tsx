"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Label } from "@/components/ui/label"
import { Camera, Upload, X, User } from "lucide-react"
import { cn } from "@/lib/utils"

interface ProfilePictureUploadProps {
  currentImage?: string
  userName: string
  onImageChange: (imageUrl: string) => void
  size?: "sm" | "md" | "lg" | "xl"
  className?: string
  showLabel?: boolean
}

export function ProfilePictureUpload({
  currentImage,
  userName,
  onImageChange,
  size = "lg",
  className,
  showLabel = true,
}: ProfilePictureUploadProps) {
  const [previewImage, setPreviewImage] = useState(currentImage || "")
  const [isUploading, setIsUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const sizeClasses = {
    sm: "h-12 w-12",
    md: "h-16 w-16",
    lg: "h-24 w-24",
    xl: "h-32 w-32",
  }

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      // Validate file type
      if (!file.type.startsWith("image/")) {
        alert("Please select an image file")
        return
      }

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert("File size must be less than 5MB")
        return
      }

      setIsUploading(true)

      // Create preview URL
      const reader = new FileReader()
      reader.onload = (e) => {
        const imageUrl = e.target?.result as string
        setPreviewImage(imageUrl)
        onImageChange(imageUrl)
        setIsUploading(false)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleRemoveImage = () => {
    setPreviewImage("")
    onImageChange("")
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const triggerFileSelect = () => {
    fileInputRef.current?.click()
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  return (
    <div className={cn("flex flex-col items-center space-y-4", className)}>
      {showLabel && <Label className="text-sm font-medium text-gray-700">Profile Picture</Label>}

      <div className="relative group">
        <Avatar className={cn(sizeClasses[size], "border-2 border-gray-200")}>
          <AvatarImage src={previewImage || "/placeholder.svg"} alt={userName} />
          <AvatarFallback className="bg-gray-100 text-gray-600 text-lg font-medium">
            {previewImage ? <User className="h-6 w-6" /> : getInitials(userName)}
          </AvatarFallback>
        </Avatar>

        {/* Upload overlay */}
        <div className="absolute inset-0 bg-black bg-opacity-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer">
          <Camera className="h-6 w-6 text-white" />
        </div>

        {/* Upload button overlay */}
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={triggerFileSelect}
          disabled={isUploading}
        >
          <span className="sr-only">Upload profile picture</span>
        </Button>

        {/* Remove button */}
        {previewImage && (
          <Button
            type="button"
            variant="destructive"
            size="sm"
            className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
            onClick={handleRemoveImage}
          >
            <X className="h-3 w-3" />
          </Button>
        )}
      </div>

      {/* Upload controls */}
      <div className="flex flex-col items-center space-y-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={triggerFileSelect}
          disabled={isUploading}
          className="flex items-center gap-2"
        >
          <Upload className="h-4 w-4" />
          {isUploading ? "Uploading..." : previewImage ? "Change Photo" : "Upload Photo"}
        </Button>

        {previewImage && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={handleRemoveImage}
            className="text-red-600 hover:text-red-700"
          >
            Remove Photo
          </Button>
        )}
      </div>

      {/* Hidden file input */}
      <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileSelect} className="hidden" />

      <p className="text-xs text-gray-500 text-center max-w-xs">Upload a photo (JPG, PNG, GIF up to 5MB)</p>
    </div>
  )
}
