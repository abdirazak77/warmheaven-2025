"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Heart, Shield, Users, Menu, X } from "lucide-react"

interface NavigationProps {
  userRole: string
  userEmail: string
  onLogout: () => void
}

export function Navigation({ userRole, userEmail, onLogout }: NavigationProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  // Use null as initial state to indicate "not yet hydrated"
  const [mounted, setMounted] = useState<boolean | null>(null)

  // Fix hydration mismatch by ensuring client-side only rendering
  useEffect(() => {
    setMounted(true)
  }, [])

  const getRoleIcon = () => {
    switch (userRole) {
      case "admin":
        return <Shield className="h-6 w-6 text-white" />
      case "caregiver":
        return <Heart className="h-6 w-6 text-white" />
      case "client":
        return <Users className="h-6 w-6 text-white" />
      default:
        return <Heart className="h-6 w-6 text-white" />
    }
  }

  const getRoleColor = () => {
    switch (userRole) {
      case "admin":
        return "bg-blue-500"
      case "caregiver":
        return "bg-orange-500"
      case "client":
        return "bg-blue-500"
      default:
        return "bg-blue-500"
    }
  }

  const getRoleTitle = () => {
    switch (userRole) {
      case "admin":
        return "Administrator Dashboard"
      case "caregiver":
        return "Caregiver Dashboard"
      case "client":
        return "Client Dashboard"
      default:
        return "Dashboard"
    }
  }

  // Show a simple placeholder during hydration
  if (mounted === null) {
    return (
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="bg-gray-200 p-2 rounded-lg">
                <div className="h-6 w-6"></div>
              </div>
              <div className="ml-3">
                <div className="h-6 w-32 bg-gray-200 rounded"></div>
                <div className="h-4 w-24 bg-gray-100 rounded mt-1"></div>
              </div>
            </div>
          </div>
        </div>
      </header>
    )
  }

  return (
    <header className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className={`${getRoleColor()} p-2 rounded-lg`}>{getRoleIcon()}</div>
            <div className="ml-3">
              <h1 className="text-xl font-semibold text-gray-900">{getRoleTitle()}</h1>
              <p className="text-sm text-gray-500">Warm Heaven Enterprise</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-4">
            <span className="text-sm text-gray-600">{userEmail}</span>
            <Button variant="outline" size="sm" onClick={onLogout}>
              Logout
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button variant="ghost" size="sm" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <div className="space-y-2">
              <p className="text-sm text-gray-600 px-2">{userEmail}</p>
              <Button variant="outline" size="sm" onClick={onLogout} className="w-full">
                Logout
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
