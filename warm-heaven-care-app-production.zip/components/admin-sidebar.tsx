import { Bell, Calendar, ClipboardList, FileText, Home, MessageSquare, Settings, Users, Clock } from "lucide-react"

const navigation = [
  { name: "Dashboard Home", href: "/admin-dashboard", icon: Home },
  { name: "Manage Users", href: "/admin/users", icon: Users },
  { name: "Caregiver Hours", href: "/admin/caregiver-hours", icon: Clock },
  { name: "Appointments", href: "/appointments", icon: Calendar },
  { name: "Messaging", href: "/messaging", icon: MessageSquare },
  { name: "Care Plans", href: "/care-plans", icon: FileText },
  { name: "Service Requests", href: "/admin/requests", icon: ClipboardList },
  { name: "Reports", href: "/admin/reports", icon: FileText },
  { name: "Notifications", href: "/admin/notifications", icon: Bell },
  { name: "Settings", href: "/admin/settings", icon: Settings },
]

export function AdminSidebar() {
  return (
    <div className="flex flex-col w-64 bg-gray-100 h-screen">
      <div className="px-4 py-6">
        <h1 className="text-2xl font-semibold">Admin Panel</h1>
      </div>
      <nav className="flex-1 px-2 space-y-1">
        {navigation.map((item) => (
          <a
            key={item.name}
            href={item.href}
            className="group flex items-center px-3 py-2 text-sm font-medium rounded-md hover:bg-gray-200 hover:text-gray-900"
          >
            <item.icon className="w-5 h-5 mr-3 text-gray-500 group-hover:text-gray-600" />
            {item.name}
          </a>
        ))}
      </nav>
    </div>
  )
}
